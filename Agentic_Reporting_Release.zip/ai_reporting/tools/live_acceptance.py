"""Run synthetic example through the real provider; never include credentials in evidence."""
import io
import json
import os
from pathlib import Path
import sys
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from dotenv import load_dotenv
load_dotenv(ROOT / '.env')
if not os.getenv('ANTHROPIC_API_KEY'):
    raise SystemExit('Configure ANTHROPIC_API_KEY in .env first.')
OUT = ROOT / 'verification' / 'live-acceptance'
OUT.mkdir(parents=True, exist_ok=True)
os.environ['DATA_ROOT'] = str(OUT / 'runtime')
from api.server import app

evidence = {'started_at': datetime.now(timezone.utc).isoformat(),
            'provider': 'Anthropic', 'data': 'synthetic examples only',
            'status': 'Running', 'steps': [], 'dax_execution': 'Not checked'}
app.config['SESSION_COOKIE_SECURE'] = False
client = app.test_client()

def call(method, path, **kwargs):
    response = client.open(path, method=method, **kwargs)
    if response.status_code != 200:
        raise RuntimeError(f'{path}: HTTP {response.status_code}')
    return response

try:
    if app.config['APP_PASSWORD']:
        call('POST', '/api/login', json={'password': app.config['APP_PASSWORD']})
    sid = call('POST', '/api/session').json['session_id']
    evidence['session_id'] = sid
    def chat(message):
        result = call('POST', f'/api/chat/{sid}', json={'message': message}).json
        evidence['steps'].append(result['state'])
        print(result['state'], flush=True)
        return result
    chat('Live AI Acceptance')
    for name in ('sales.csv', 'customers.csv'):
        call('POST', f'/api/chat/{sid}', data={'file': (io.BytesIO((ROOT / 'examples' / name).read_bytes()), name)})
        chat('done')
    chat((ROOT / 'examples' / 'protocol.md').read_text(encoding='utf-8'))
    review = call('GET', f'/api/review/{sid}').json
    (OUT / 'review.json').write_text(json.dumps(review, indent=2), encoding='utf-8')
    names = {m['display_name'].casefold() for m in review['measures']}
    expected = {'revenue', 'orders', 'units', 'average order value'}
    if not expected.issubset(names) or any(m['needs_clarification'] for m in review['measures']):
        raise RuntimeError('AI definitions require review; inspect review.json before continuing.')
    for message, state in [('confirm all', 'MODEL_BUILD'), ('build', 'EXPORT'), ('all', 'COMPLETE')]:
        if chat(message)['state'] != state:
            raise RuntimeError('Workflow needs review; no automatic correction was applied.')
    for kind, extension in [('powerbi', 'zip'), ('excel', 'xlsx'), ('report', 'pdf'), ('tmdl', 'json'), ('audit', 'audit.json')]:
        (OUT / ('report.' + extension)).write_bytes(call('GET', f'/api/export/{sid}/{kind}').data)
    (OUT / 'review.json').write_text(json.dumps(call('GET', f'/api/review/{sid}').json, indent=2), encoding='utf-8')
    evidence['status'] = 'Passed generation and exports; business acceptance pending'
except Exception as exc:
    evidence['status'] = 'Needs attention'
    evidence['error'] = str(exc)
    raise
finally:
    (OUT / 'result.json').write_text(json.dumps(evidence, indent=2), encoding='utf-8')

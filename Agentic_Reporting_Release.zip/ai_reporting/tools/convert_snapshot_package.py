"""Convert this app's CSV snapshot ZIP to Excel snapshots without replanning."""
import hashlib
import io
import json
from pathlib import Path
import sys
import zipfile

import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from core.models import FileMeta, ColumnMeta
from core.pbi_exporter import _write_excel_snapshot, _build_file_path_partition


def convert(source, destination):
    import tempfile
    with zipfile.ZipFile(source) as archive:
        if archive.testzip():
            raise ValueError('Source ZIP is damaged')
        payload = {n: archive.read(n) for n in archive.namelist()}
    manifest = json.loads(payload['validation_manifest.json'])
    bim_names = [n for n in payload if n.endswith('model.bim')]
    reference = json.loads(payload[bim_names[0]])
    tables = {t['name']:t for t in reference['model']['tables']}
    updated = {}
    with tempfile.TemporaryDirectory() as temporary:
        for entry in manifest['tables']:
            source_name = entry['file']
            if not source_name.endswith('.csv'):
                raise ValueError('Expected CSV snapshot package')
            table = tables[entry['table']]
            types = {c['name']:c['dataType'] for c in table['columns']}
            frame = pd.read_csv(io.BytesIO(payload[source_name]), dtype=str, keep_default_na=False)
            for column, kind in types.items():
                if kind == 'dateTime':
                    frame[column] = pd.to_datetime(frame[column].replace('', None))
                elif kind in ('int64','double','decimal'):
                    frame[column] = pd.to_numeric(frame[column].replace('', None))
                elif kind == 'boolean':
                    frame[column] = frame[column].map({'True':True,'False':False,'true':True,'false':False,'':None})
            path = Path(temporary) / (Path(source_name).stem + '.xlsx')
            _write_excel_snapshot(frame, path)
            restored = pd.read_excel(path, dtype={c:str for c,k in types.items() if k=='string'}, keep_default_na=False)
            for column, kind in types.items():
                if kind == 'dateTime':
                    restored[column] = pd.to_datetime(restored[column].replace('', None))
                elif kind in ('int64','double','decimal'):
                    restored[column] = pd.to_numeric(restored[column].replace('', None))
            pd.testing.assert_frame_equal(frame, restored, check_dtype=False, check_exact=False, rtol=1e-12, atol=1e-12)
            columns = [ColumnMeta(name=c, dtype=str(frame[c].dtype), null_count=0, null_pct=0,
                                  unique_count=0, cardinality_pct=0, sample_values=[],
                                  is_date=types[c]=='dateTime') for c in frame.columns]
            meta = FileMeta(table_name=entry['table'], columns=columns, sheet_name='Sheet1')
            updated[entry['table']] = _build_file_path_partition(meta, str(path))
            del payload[source_name]
            entry['file'] = 'source_data/' + path.name
            payload[entry['file']] = path.read_bytes()
            entry['sha256'] = hashlib.sha256(payload[entry['file']]).hexdigest()
        for name in bim_names:
            bim = json.loads(payload[name])
            for table in bim['model']['tables']:
                if table['name'] in updated:
                    table['partitions'] = [updated[table['name']]]
            payload[name] = json.dumps(bim, indent=2).encode()
    manifest['snapshot_format'] = 'xlsx'
    manifest['conversion'] = 'CSV snapshots converted to Excel; values compared locally. Model measures, relationships and visuals preserved. Native Desktop acceptance not yet verified.'
    payload['validation_manifest.json'] = json.dumps(manifest, indent=2).encode()
    payload['README_IMPORT.txt'] += b'\nEXCEL COMPATIBILITY COPY: Set SourceDataFolder to this extracted source_data directory. Do not point it at the old CSV package.\n'
    destination = Path(destination)
    if destination.resolve() == Path(source).resolve():
        raise ValueError('Use a separate destination ZIP')
    destination.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(destination, 'w', zipfile.ZIP_DEFLATED) as archive:
        for name, content in payload.items():
            archive.writestr(name, content)
    print(json.dumps({'output':str(destination), 'tables_compared':len(updated),
                      'rows':sum(e['rows'] for e in manifest['tables'])}))


if __name__ == '__main__':
    convert(sys.argv[1], sys.argv[2])

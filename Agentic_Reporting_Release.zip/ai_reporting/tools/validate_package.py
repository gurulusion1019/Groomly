"""Validate generated PBIR against its declared public Microsoft schemas.

Run: python tools/validate_package.py path/to/export.zip
Only public schemas are downloaded; the report and source data remain local.
"""
import hashlib
import json
from pathlib import Path
import sys
from urllib.parse import urljoin, urldefrag
import zipfile
import requests
from jsonschema import validators
from referencing import Registry, Resource

ROOT = Path(__file__).resolve().parents[1]
CACHE = ROOT / 'tests' / 'schemas'

def validate(path):
    CACHE.mkdir(parents=True, exist_ok=True)
    retrieved = {}
    def load(uri):
        uri = urldefrag(uri)[0]
        if uri in retrieved:
            return retrieved[uri]
        if not uri.startswith('https://developer.microsoft.com/json-schemas/'):
            raise ValueError(f'Unexpected external schema: {uri}')
        cached = CACHE / (hashlib.sha256(uri.encode()).hexdigest()+'.json')
        if cached.exists():
            schema = json.loads(cached.read_text(encoding='utf-8'))
        else:
            response = requests.get(uri,timeout=45)
            response.raise_for_status()
            schema = response.json()
            cached.write_text(json.dumps(schema,indent=2),encoding='utf-8')
        retrieved[uri] = schema
        return schema
    registry = Registry(retrieve=lambda uri: Resource.from_contents(load(uri)))
    findings=[]
    with zipfile.ZipFile(path) as zf:
        for name in zf.namelist():
            if not name.endswith(('.json','.pbip','.pbir','.pbism')):
                continue
            instance=json.loads(zf.read(name))
            uri=instance.get('$schema')
            if not uri:
                continue
            schema=load(uri)
            # Resolve relative refs from the declared schema URL.
            schema = dict(schema)
            schema.setdefault('$id',uri)
            validator=validators.validator_for(schema)(schema,registry=registry)
            errors=[f'{list(e.path)}: {e.message}' for e in validator.iter_errors(instance)]
            findings.append({'file':name,'schema':uri,'status':'Failed' if errors else 'Passed','errors':errors})
    (CACHE/'sources.json').write_text(json.dumps({hashlib.sha256(k.encode()).hexdigest()+'.json':k for k in retrieved},indent=2),encoding='utf-8')
    return findings

if __name__=='__main__':
    findings=validate(sys.argv[1])
    output=Path(sys.argv[1]).with_suffix('.schema-check.json')
    output.write_text(json.dumps(findings,indent=2),encoding='utf-8')
    failed=[f for f in findings if f['status']=='Failed']
    print(json.dumps({'checked_files':len(findings),'failed_files':len(failed),'results':str(output),'failures':failed},indent=2))
    raise SystemExit(bool(failed))

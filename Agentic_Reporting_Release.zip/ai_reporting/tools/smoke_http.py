"""Exercise the running production server using synthetic files only."""
from pathlib import Path
import json
import sys
import requests

ROOT=Path(__file__).resolve().parents[1]
base=(sys.argv[1] if len(sys.argv)>1 else 'http://127.0.0.1:5055').rstrip('/')
http=requests.Session()
def call(method,path,**kwargs):
    response=http.request(method,base+path,timeout=240,**kwargs)
    if response.status_code!=200:
        raise RuntimeError(f'{path}: {response.status_code} {response.text[:1000]}')
    return response

assert call('GET','/api/health').json()['status']=='ok'
sid=call('POST','/api/session').json()['session_id']
def chat(message):
    result=call('POST',f'/api/chat/{sid}',json={'message':message}).json()
    print(result['state'],flush=True)
    return result
chat('Deployment Smoke Test')
for name in ('sales.csv','customers.csv'):
    call('POST',f'/api/chat/{sid}',files={'file':(name,(ROOT/'examples'/name).read_bytes())},data={'message':'Synthetic test data'})
    chat('done')
chat('generate')
assert chat('confirm all')['state']=='MODEL_BUILD'
assert chat('build')['state']=='EXPORT'
assert chat('all')['state']=='COMPLETE'
out=ROOT/'verification'
out.mkdir(exist_ok=True)
for kind,extension in [('powerbi','zip'),('excel','xlsx'),('report','pdf'),('tmdl','summary.json'),('audit','audit.json')]:
    response=call('GET',f'/api/export/{sid}/{kind}')
    (out/f'smoke.{extension}').write_bytes(response.content)
    print(f'{kind}: {len(response.content)} bytes',flush=True)
(out/'http-smoke.json').write_text(json.dumps({'status':'Passed','session_id':sid,'server':base,'data':'synthetic examples','exports':['powerbi','excel','report','tmdl','audit']},indent=2))

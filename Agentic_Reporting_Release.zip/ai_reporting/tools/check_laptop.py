"""Offline installation check. Uses isolated temporary projects, never live data."""
import os
from pathlib import Path
import sys
import tempfile
import json

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

def main():
    with tempfile.TemporaryDirectory(prefix='reporting_laptop_check_') as temporary:
        os.environ.update(DATA_ROOT=temporary, ANTHROPIC_API_KEY='', APP_PASSWORD='', COOKIE_SECURE='false')
        from api.server import app, SESSIONS
        from core.project_store import ProjectStore
        first, second = app.test_client(), app.test_client()
        assert first.get('/api/health').status_code == 200
        assert first.get('/').status_code == 200, 'Built frontend is missing.'
        sid = first.post('/api/session').get_json()['session_id']
        assert first.post(f'/api/chat/{sid}', json={'message':'Laptop installation check'}).status_code == 200
        assert first.get(f'/api/session/{sid}').get_json()['project_name'] == 'Laptop installation check'
        assert second.get(f'/api/session/{sid}').status_code in (403,404)
        assert not second.get('/api/sessions').get_json()['sessions']
        recovered = ProjectStore(SESSIONS.path)[sid]
        assert recovered.project_name == 'Laptop installation check'
        print(json.dumps({'status':'Passed','checks':['Frontend available','API available','Project write/read','Separate browser ownership','SQLite recovery'],'ai_calls':0},indent=2))

if __name__ == '__main__':
    main()

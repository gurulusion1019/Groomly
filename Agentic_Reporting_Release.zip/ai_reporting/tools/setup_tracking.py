"""Initialize tracking schema, recover interrupted runs, and sync queued metadata."""
from pathlib import Path
import re
import sys
from contextlib import closing
from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
load_dotenv(ROOT / '.env')
load_dotenv(ROOT / '.env.tracking')
from core.tracking import sql_connection

if __name__ == '__main__':
    with closing(sql_connection()) as connection:
        for statement in re.split(r'^GO\s*$', (ROOT/'database/tracking.sql').read_text(), flags=re.MULTILINE):
            if statement.strip():
                connection.cursor().execute(statement)
        connection.commit()
    print('SQL Server tracking schema is ready. No existing project data was migrated.')

"""Real SQL acceptance using synthetic data and a separate local runtime."""
from contextlib import closing
import io
import json
import os
from pathlib import Path
import sys
import tempfile

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))


def main():
    with tempfile.TemporaryDirectory(prefix='tracking_sql_acceptance_') as temporary:
        os.environ.update(DATA_ROOT=temporary, ANTHROPIC_API_KEY='', APP_PASSWORD='', TRACKING_SQL_ENABLED='false')
        from api.server import app, TRACKER
        from core.tracking import TrackingStore, sql_connection
        client=app.test_client()
        sid=client.post('/api/session').json['session_id']
        def chat(message):
            response=client.post('/api/chat/'+sid,json={'message':message})
            assert response.status_code==200,response.status_code
            return response.json
        chat('SQL Tracking Acceptance')
        for name, data in [('facts.csv',b'id,amount\na,10\nb,20\n'),('lookup.csv',b'id,label\na,First\nb,Second\n')]:
            assert client.post('/api/chat/'+sid,data={'file':(io.BytesIO(data),name)},content_type='multipart/form-data').status_code==200
            chat('done')
        chat('generate');chat('confirm all')
        assert chat('build')['state']=='EXPORT'
        assert chat('all')['state']=='COMPLETE'
        assert client.get('/api/export/'+sid+'/powerbi').status_code==200
        before=client.get('/api/tracking').json
        assert before['totals']['upload_events']==2 and before['totals']['completed_projects']==1
        owner=before['runs'][0]['owner_id']
        event_count=len(TRACKER.records(owner))
        def unavailable():
            raise ConnectionError('Synthetic outage')
        assert TRACKER.flush(unavailable)==0
        assert TRACKER.history(owner)['pending_events']==event_count
        assert TRACKER.flush()==event_count
        restored=TrackingStore(TRACKER.path)
        assert restored.history(owner)['pending_events']==0
        # Replay a committed batch, simulating a crash before local acknowledgement.
        with closing(restored.connect()) as local,local:
            local.execute('UPDATE tracking_events SET delivered=0')
        assert restored.flush()==event_count
        with closing(sql_connection()) as remote:
            stored=remote.cursor().execute('SELECT COUNT(*) FROM reporting.Events WHERE owner_id=?',owner).fetchone()[0]
            runs=remote.cursor().execute('SELECT COUNT(*) FROM reporting.ProcessingRuns WHERE owner_id=?',owner).fetchone()[0]
            uploads=remote.cursor().execute("SELECT COUNT(*) FROM reporting.UploadHistory WHERE owner_id=? AND outcome='Succeeded'",owner).fetchone()[0]
            completed=remote.cursor().execute("SELECT COUNT(*) FROM reporting.ProjectStatus WHERE owner_id=? AND state_after='COMPLETE'",owner).fetchone()[0]
        assert stored==event_count and runs==before['total'] and uploads==2 and completed==1
        evidence=dict(status='Passed',events=stored,runs=runs,uploads=uploads,completed_projects=completed,
                      checks=['Offline upload/build/export','SQL metadata writes','Outage queue retention','Replay without duplicates','Local restart persistence','SQL reporting views'],
                      note='Synthetic SQL Tracking Acceptance records retained in AgenticReporting. No user project data was migrated.')
        (ROOT/'verification/tracking-sql-check.json').write_text(json.dumps(evidence,indent=2))
        print(json.dumps(evidence,indent=2))


if __name__=='__main__':
    main()

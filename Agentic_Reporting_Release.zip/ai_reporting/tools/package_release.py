"""Create an allowlisted release archive without keys, runtime data or environments."""
from pathlib import Path
import hashlib
import json
import zipfile
from dotenv import dotenv_values

ROOT=Path(__file__).resolve().parents[1]
OUTPUT=ROOT.parent/'Agentic_Reporting_Release.zip'
if dotenv_values(ROOT / '.env.example').get('ANTHROPIC_API_KEY'):
    raise ValueError('Remove the API key from .env.example before packaging.')
files=[]
for name in ['README.md','COMPANY_LAPTOP_SETUP.md','requirements.txt','.env.example','.gitignore','run_server.py','setup.ps1','start.ps1']:
    files.append(ROOT/name)
for folder in ['api','core','examples']:
    files.extend(p for p in (ROOT/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts)
for folder in ['frontend/src','frontend/public','frontend/build','tests']:
    files.extend(p for p in (ROOT/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts and '.pytest_cache' not in p.parts)
files.extend(ROOT/'frontend'/name for name in ['package.json','package-lock.json'])
files.extend(ROOT/'tools'/name for name in ['smoke_http.py','validate_package.py','package_release.py','live_acceptance.py','check_release_archive.py','check_laptop.py'])
for name in ['TEST_REPORT.md','powerbi-refresh-followup.md','sqlserver-readiness.md','http-smoke.json','smoke.schema-check.json','smoke.zip','backend-tests.xml','frontend-tests.json','browser-checks.json','browser-preview.png']:
    path=ROOT/'verification'/name
    if path.exists():
        files.append(path)
for name in ['result.json', 'review.json', 'report.zip', 'report.schema-check.json']:
    path = ROOT/'verification'/'live-acceptance'/name
    if path.exists():
        files.append(path)
manifest=[]
with zipfile.ZipFile(OUTPUT,'w',zipfile.ZIP_DEFLATED) as zf:
    for file in sorted(set(files)):
        relative=file.relative_to(ROOT).as_posix()
        if file.name == '.env' or any(p in ('runtime','runtime-browser-test','node_modules','.venv') for p in file.relative_to(ROOT).parts):
            raise ValueError('Forbidden release path: '+relative)
        payload=file.read_bytes()
        manifest.append({'path':relative,'bytes':len(payload),'sha256':hashlib.sha256(payload).hexdigest()})
        zf.writestr('ai_reporting/'+relative,payload)
    zf.writestr('ai_reporting/RELEASE_MANIFEST.json',json.dumps(manifest,indent=2))
print(json.dumps({'archive':str(OUTPUT),'files':len(files),'bytes':OUTPUT.stat().st_size,'sha256':hashlib.sha256(OUTPUT.read_bytes()).hexdigest()},indent=2))

"""Check archive integrity and start the extracted app with isolated runtime data."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import tempfile
import zipfile

ROOT=Path(__file__).resolve().parents[1]
archive=ROOT.parent/'Agentic_Reporting_Release.zip'
verification=ROOT/'verification'
with tempfile.TemporaryDirectory(prefix='release_check_',dir=verification) as temporary:
    target=Path(temporary).resolve()
    assert target.is_relative_to(verification.resolve())
    with zipfile.ZipFile(archive) as zf:
        assert zf.testzip() is None
        for member in zf.infolist():
            path=(target/member.filename).resolve()
            assert path.is_relative_to(target)
            assert not any(part in ('.venv','node_modules','runtime','runtime-browser-test','__pycache__') for part in path.relative_to(target).parts)
            assert path.name not in ('.env','.env.tracking','session.key','projects.sqlite3','tracking.sqlite3')
        manifest=json.loads(zf.read('ai_reporting/RELEASE_MANIFEST.json'))
        for item in manifest:
            assert hashlib.sha256(zf.read('ai_reporting/'+item['path'])).hexdigest()==item['sha256']
        zf.extractall(target)
    environment=os.environ.copy()
    environment.update(DATA_ROOT=str(target/'runtime'),ANTHROPIC_API_KEY='',APP_PASSWORD='',PYTHONDONTWRITEBYTECODE='1')
    code="""
import json
from pathlib import Path
from api.server import app
client=app.test_client()
assert client.get('/').status_code==200
assets=json.loads(Path('frontend/build/asset-manifest.json').read_text())
for asset in assets['entrypoints']:
    assert client.get('/'+asset).status_code==200
assert client.get('/api/health').json['status']=='ok'
result=client.post('/api/session')
assert result.status_code==200
sid=result.json['session_id']
assert client.post('/api/chat/'+sid,json={'message':'Extracted package check'}).json['state']=='RAW_DATA'
print('Extracted application and static assets passed.')
"""
    result=subprocess.run([sys.executable,'-c',code],cwd=target/'ai_reporting',env=environment,capture_output=True,text=True,timeout=240)
    if result.returncode:
        print(result.stdout,result.stderr)
        raise SystemExit(result.returncode)
    evidence={'status':'Passed','archive':archive.name,'checked_files':len(manifest),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),
              'checks':['ZIP integrity','Manifest hashes','No environments/runtime/secrets','Extracted app imports','Static frontend assets served','Session and project creation']}
    (verification/'release-archive-check.json').write_text(json.dumps(evidence,indent=2),encoding='utf-8')
    print(json.dumps(evidence,indent=2))

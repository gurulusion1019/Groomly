# SQL Server tracking

Launch remains `python -m api.app`. Existing project storage stays in SQLite.
Tracking metadata is recorded in DATA_ROOT/tracking.sqlite3, then delivered to
the dedicated AgenticReporting database. The report source data is not copied to
SQL Server by this feature. Direct SQL table inputs are not implemented here.

## Company setup

1. Install updated requirements, including pyodbc, and an approved 64-bit SQL
   Server ODBC driver.
2. Set these values in the company's local .env (the laptop-specific .env.tracking
   is excluded from the release):

   ```dotenv
   TRACKING_SQL_ENABLED=true
   TRACKING_SQL_SERVER=YOUR_APPROVED_SERVER
   TRACKING_SQL_DATABASE=AgenticReporting
   TRACKING_SQL_DRIVER=ODBC Driver 17 for SQL Server
   TRACKING_SQL_AUTH=windows
   TRACKING_SQL_TRUST_CERTIFICATE=no
   ```

3. Have the DBA run database/tracking.sql against AgenticReporting, or run
   `python tools/setup_tracking.py` using an account allowed to create the schema.
   It is additive and repeatable; it does not migrate or delete saved projects.
4. Run `python -m api.app`. The sync worker runs in that process every 10 seconds,
   in batches of 200 events. Failed batches remain on disk and retry. Imports by
   another WSGI host require explicitly starting TRACKER.start_worker once.
5. Open Processing & login history on the start page or in a project's sidebar.
   Refresh to see SQL delivery status. The UI always reads the local durable
   journal so SQL outages do not prevent viewing history.

The local laptop uses Windows authentication and the same trusted local server
certificate setting previously used in SSMS. Use a valid trusted certificate and
the company-approved settings on the company server. SQL-password authentication
is optional: set TRACKING_SQL_AUTH=sql and supply TRACKING_SQL_USER and
TRACKING_SQL_PASSWORD locally. Never include passwords in a release or logs.

The schema-setup account needs DDL permission. The running application only needs
SELECT and INSERT on reporting.Events. A DBA can grant administrators SELECT on
the reporting views. Do not use the source business database as the tracking DB.

## What is recorded

- Start and finish of each processing request, with a stable request ID and UTC
  timestamps. Repeated build attempts get separate IDs; HTTP success with a
  blocked model build is recorded as Blocked.
- Project name and session ID; before/after workflow state; available outputs.
- Uploaded file name, role, extension, byte length, SHA-256 and (after successful
  ingestion) loaded row and column counts. Replacements count as new upload
  events, while active file counts remain the current project counts.
- Fact, mapping and protocol active counts; fact rows included/excluded/quarantined.
- Login attempts and logout events. Passwords, API keys, chat text and source
  cell values are not recorded. Error details are deliberately generic; project
  and server logs remain the place for the underlying exception.
- Processing mode records whether AI was configured, not proof every stage made
  an AI call. Token usage and per-AI-call timing are outside this implementation.

Processing time is the duration of the server action from tracking start to
response preparation. It excludes response transmission and the SQL background
sync. Upload transfer before the server handles the request is not measured.
Waiting-before time is the gap between workflow actions when the previous state
required user input; it includes time away from the app and is not active labor.
A request that stops without a finish record is marked Interrupted at the next
single-process server startup. Its unknown duration is represented as zero and
must not be interpreted as a completed zero-second operation.

## Identity and access

The existing app uses browser ownership and optional shared-password access.
Records identify the browser owner ID and identity type. They do not establish
an employee's name, Windows identity or email. SQL Windows authentication identifies
the server process account, not the person using the browser. Named employee
identity requires a later authenticated account/SSO integration.

UI history is restricted to the current owner, even if another project ID is
supplied. Administrators use the SQL views for organization-wide reporting:

```sql
SELECT * FROM reporting.ProjectStatus ORDER BY occurred_at DESC;
SELECT * FROM reporting.ProcessingRuns ORDER BY occurred_at DESC;
SELECT * FROM reporting.UploadHistory ORDER BY occurred_at DESC;
SELECT * FROM reporting.LoginHistory ORDER BY occurred_at DESC;
```

The start page history covers this browser's projects; project-side history
filters to that project. The newest 50 actions are shown per page. Active file
counts are snapshots, not values to sum across actions. Upload-event counts may
be summed. Old activity from before tracking was enabled is not reconstructed.

## Recovery and limits

SQL delivery uses unique event IDs and transactional inserts so replay after a
crash does not duplicate committed events. The local journal is still required;
back up the full stopped runtime folder with projects.sqlite3, session.key,
tracking.sqlite3 and uploads. The UI reports queued delivery and journal-write
errors. A full disk can prevent audit capture; report processing is not rolled
back solely for an audit failure. No claim of regulatory-grade audit is made.

Audit history is retained after project deletion. There is no automatic retention
purge yet; agree a retention/backup policy before company-wide use. The current
UI aggregates one owner's local history in memory, intended for this pilot's
volume. Multi-server project ownership and retention automation are future work.

Run `python tools/check_tracking_sql.py` for real SQL acceptance. It uses synthetic
data and a temporary local runtime, exercises outage/replay/restart behavior,
and retains clearly named SQL Tracking Acceptance records in AgenticReporting.

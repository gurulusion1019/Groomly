# Power BI refresh follow-up — 16 September 2026

The original Retail Acceptance Test opened with populated visuals. Applying pending queries removed the pending-query banner. A subsequent explicit refresh reported errors in five loaded queries: the visible rows included orders (100 loaded, 100 errors), customers (2,000 loaded, 2,000 errors), and date (1,461 loaded, 1,461 errors). Channels loaded 8 rows without an error indicator.

The exported CSV represents dates as ISO timestamps, while the original generated M query converted those strings directly to `type date`. The exporter now parses ISO timestamps as datetime before projecting to date, restores blank typed values as null, and uses an explicit en-US numeric conversion culture. Text codes such as N/A and leading-zero identifiers remain text.

Backend regression suite: 66 tests passed. This verifies generated query structure and application regressions, not native M execution. A separate corrected project is prepared under retail-acceptance/Refresh_Fix; the original exported package and report have not been overwritten.

Native acceptance of the corrected project subsequently passed: Power BI Desktop refreshed the corrected queries successfully. The DAX query in `retail-acceptance/Refresh_Fix/acceptance.dax` compared 21 metrics to independent baselines: 21 passed, largest difference 0, and 100 fact rows loaded. Selecting Call Center filtered the overview to net revenue $2,562, 3 orders and gross profit $1,109; clearing the selection restored the totals. These are observed native application results from the acceptance session.

This establishes core numerical acceptance for this retail test report. The remaining measures, date contexts and every page/visual interaction have not been exhaustively compared. The original report's explicit refresh failed; use newly generated exports with the corrected exporter. Existing saved downloads need rebuilding to incorporate the fix.

# Release verification

## Outcome

The private/single-server release passed the automated checks listed below.
Earlier live Anthropic generation and all five exports passed. Subsequent native
testing found and fixed CSV date conversion errors. The corrected Retail Refresh
Verification project refreshed successfully in Power BI Desktop: 21/21 baseline
metrics matched exactly, with 100 fact rows loaded. A Call Center slicer check
passed. Remaining measures, date contexts and all page interactions have not been
exhaustively verified. See powerbi-refresh-followup.md for the acceptance scope.
Treat this as an implementation and test release for local acceptance, not a
certification of every generated report or a public-cloud deployment.

| Check | Result | Evidence and scope |
|---|---|---|
| Backend suite | Passed: 66 tests | Latest local pytest run; includes CSV refresh conversion, batch clarification, workflow summary, and eight concurrent isolated browser sessions. Older XML files cover earlier runs. |
| Company launch compatibility | Passed: 2 additional tests | Real HTTP startup with `python -m api.app` and `python run_server.py` on configured temporary ports. Both use the same launcher. Windows process cleanup passed outside the restricted sandbox. |
| Frontend suite | Passed: 17 tests | Local React tests cover workflow actions, multi-answer submission, saving groups, warning summaries, downloads above other sidebar content, and the no-files state. Older JSON files cover earlier runs. |
| Production frontend build | Passed | `CI=true npm run build`, including warnings-as-errors |
| Python dependency consistency | Passed | `python -m pip check` |
| Running-server workflow | Passed | `http-smoke.json`; real HTTP calls to Waitress from creation through all five exports |
| Microsoft report JSON schemas | Passed: 10 files | `smoke.schema-check.json`; checked declared schemas, including referenced schemas |
| Browser workflow | Passed through generation | Create project, upload fact/lookup CSVs, generate, edit measure, confirm, build, export, reload |
| Browser download event | Not confirmed | Link click did not produce the automation download event within 15 seconds. No browser console errors were observed. HTTP ZIP download passed. |
| Desktop open/render/refresh | Core retail acceptance passed | Corrected report refreshed, 21 metrics matched exactly, 100 fact rows loaded and channel filtering worked. Remaining measures/date contexts and exhaustive visual acceptance remain unverified. |
| Live AI provider | Passed generation and exports | `live-acceptance/result.json`; real Anthropic extraction, DAX generation and visual planning using synthetic examples |
| Live report schemas | Passed: 15 files | `live-acceptance/report.schema-check.json` |
| Business acceptance of arbitrary reports | Not checked | Requires approved definitions and result comparisons in the loaded model |

## Regression coverage

Current workflow: Next steps provides Review complete, Build / retry report,
and Generate all downloads. Individual download links appear when ready.
Downloads & completion report now appears first in the sidebar, including an
explicit empty state when no exports exist. The PDF link is labeled Project
completion report. Browser inspection of the saved COMPLETE project confirmed
all five export links existed before the layout change; the original issue was
their position below the review and validation sections.
Clarification questions have answer fields and one batch-submit action. The
validation summary shows included/excluded/quarantined rows, failed definitions,
warnings and unchecked results, with recovery guidance. Save confirmations point
to the workflow buttons. Browser inspection confirmed the existing retail review
project's three bulk-save controls and its 92 included / 8 excluded row summary.
These older saved projects retain their prior unresolved definitions; they are
separate from the corrected 100-row numerical acceptance fixture.

- No-protocol flow from project creation through Excel, PBIP ZIP, model-summary
  JSON, audit JSON and PDF downloads.
- Protocol flow with a controlled provider response. Missing provider and
  oversized protocol are explicit failures, preserving the prior project state.
- Literal `N/A` codes, `001` identifiers, CSV/TSV/semicolon delimiters and a
  workbook whose sheet is named Transactions.
- Source dates become date columns in the generated model.
- Duplicate source rows: approved quarantine is preserved and only cleaned data
  is packaged. The approved amount total is 61.50.
- Unmatched-key exclusion removes actual rows and updates metadata; the fixture
  total becomes 30.75.
- Duplicate lookup-key correction, full-data fan-out detection beyond the old
  5,000-row sample, and measured exact-name overlap.
- Replacement uploads update the stored data and invalidate old downloads.
- Relationship edits recheck target fields and unmatched keys.
- Measure edits invalidate exports; rebuilt formulas use the revised definition.
- Invalid field references block export. Typed-filter DAX templates preserve
  strings/numbers and use the requested operators.
- A 10,003-row source is fully included in its exported snapshot.
- Multi-page plans preserve cards, wide matrices and slicers; rectangles stay
  inside page bounds without overlaps. A final targeted check covers slicer overflow.
- Project persistence across store reloads, browser ownership isolation, password
  login, cross-site mutation rejection, invalid inputs and project deletion.
- HTML-like chat content is escaped. Missing exports have no download button.

## Independent sample baselines

For `examples/sales.csv` and `examples/customers.csv`:

| Quantity | Expected |
|---|---:|
| Source/approved fact rows | 3 |
| Distinct line IDs | 3 |
| Distinct orders | 2 |
| Sum of amount | 61.50 |
| Sum of quantity | 7 |
| Revenue / distinct orders | 30.75 |

Python checks compare approved data with packaged snapshot contents and file
hashes. They do not execute DAX. The no-protocol suggestions include a distinct
line count; that is different from the distinct-order metric in the protocol.

## Manual acceptance before business deployment

1. Repeat the live example if provider configuration changes; this run has passed.
2. Review the generated business definitions and filters.
3. Open the extracted PBIP in the installed Power BI Desktop version, set
   SourceDataFolder and refresh.
4. Check the baseline values above, customer filters, date filtering and the
   requested visual coverage.
5. Repeat with representative real data and approved expected results.
6. Choose the actual hosting/access setup. The delivered default is a private
   Windows server; public user-account hosting is outside this release.

See the README for supported inputs, refresh behavior, deployment setup and
limitations. Public schema checks are structural evidence, not Desktop rendering
or DAX-engine evidence.

## Live acceptance follow-up

The live example exposed a dependency-validation bug: internal names such as
`revenue` did not match display names such as `Revenue`. Validation, cycle
detection and dependent-formula invalidation now resolve names ignoring case.
Ambiguous aliases remain blocked. The complete backend suite passed after the fix.

The live output contains SUM(sales.amount), DISTINCTCOUNT(sales.order_id),
SUM(sales.quantity), and DIVIDE([Revenue], [Orders], BLANK()). These formulas
match the sample definitions on inspection; they have not run in the DAX engine.
Nine visuals were generated. All five export endpoints returned files.

Desktop follow-up reached the blank Power BI workspace, but later captures
switched to unrelated windows. Automation stopped; no sample was opened.
The generated import guide now explains the actual PBIP folder structure and
SourceDataFolder parameter, removing outdated alternative import instructions.

The configured key is stored only in local `.env`, excluded from release files.
The package builder rejects an API key in `.env.example`.

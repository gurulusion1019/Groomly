# SQL Server tracking database readiness

Read-only verification on the local laptop succeeded:

- Server: SHASHA_SHAAN.
- Database: AgenticReporting, ONLINE.
- Authentication: Windows integrated authentication.
- Current account has CREATE TABLE permission.
- Existing user tables: 0 at verification.
- ODBC Driver 17 for SQL Server is installed (64-bit available).

The initial read-only check did not create tables. Subsequently, the authorized
tracking implementation created reporting.Events and the ProcessingRuns,
ProjectStatus, UploadHistory and LoginHistory views. Real SQL acceptance passed:
23 events, 12 actions, 2 uploads, 1 completed synthetic project, including outage
queueing and duplicate-free replay. See tracking-sql-check.json. The application
still uses its existing SQLite project store, with a separate tracking journal
delivering metadata to SQL Server.

The existing `python -m api.app` entry point remains supported. Local SQL settings
are in .env.tracking and are excluded from the release. Company setup is described
in TRACKING_SETUP.md. Employee SSO and direct business-database inputs remain
separate future features.

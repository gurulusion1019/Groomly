# SQL Server tracking database readiness

Read-only verification on the local laptop succeeded:

- Server: SHASHA_SHAAN.
- Database: AgenticReporting, ONLINE.
- Authentication: Windows integrated authentication.
- Current account has CREATE TABLE permission.
- Existing user tables: 0 at verification.
- ODBC Driver 17 for SQL Server is installed (64-bit available).

No tables, logins or data were created or modified by this check. The application
still uses its existing SQLite project store. SQL Server tracking integration is
not yet implemented or enabled.

Next implementation scope: versioned tracking schema, configurable SQL Server
connection, processing-run and stage event writes, dataset/file counts, separate
processing and user-wait durations, and tracking dashboard. Verify writes and
restart recovery with isolated test records before enabling it for live projects.
The existing `python -m api.app` entry point remains supported.

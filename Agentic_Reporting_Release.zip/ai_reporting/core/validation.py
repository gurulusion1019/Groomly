"""Deterministic definition checks. This module does not execute DAX."""
import re
import pandas as pd


def dax_filter(condition, table):
    if not table:
        raise ValueError('A filtered measure needs a source table.')
    field = "'" + table.replace("'", "''") + "'[" + condition.column.replace(']', ']]') + "]"
    def literal(value):
        if value is None:
            return 'BLANK()'
        if isinstance(value, bool):
            return 'TRUE()' if value else 'FALSE()'
        if isinstance(value, (int, float)):
            return str(value)
        return '"' + str(value).replace('"', '""') + '"'
    op = condition.operator.upper()
    if op in ('IS NULL', 'IS NOT NULL'):
        return ('' if op == 'IS NULL' else 'NOT ') + f'ISBLANK({field})'
    if op in ('IN', 'NOT IN'):
        if not isinstance(condition.value, list):
            raise ValueError('IN filters require a list of typed values.')
        expr = field + ' IN {' + ', '.join(literal(v) for v in condition.value) + '}'
        return f'NOT ({expr})' if op == 'NOT IN' else expr
    if op not in ('=', '!=', '<>', '>', '<', '>=', '<='):
        raise ValueError(f'Unsupported filter operator: {op}')
    return f"{field} {'<>' if op == '!=' else op} {literal(condition.value)}"


def refresh_metadata(meta, df):
    from .file_processor import _infer_column
    meta.row_count = len(df)
    meta.col_count = len(df.columns)
    meta.columns = [_infer_column(df[c], len(df)) for c in df.columns]
    meta.pk_candidates = [c.name for c in meta.columns if c.is_pk_candidate]


def validate_model(model, dfs):
    checks = []
    def record(scope, status, detail):
        checks.append(dict(scope=scope, status=status, detail=detail))
    schema = {m.table_name: {c.name: c for c in m.columns} for m in model.tables}
    if len(schema) != len(model.tables):
        record('tables', 'Failed', 'Duplicate table names.')
    for table in model.tables:
        df = dfs.get(table.table_name)
        if df is None or df.empty:
            record(table.table_name, 'Failed', 'No usable data loaded.')
    names = [m.display_name or m.name for m in model.measures]
    if len({n.casefold() for n in names}) != len(names):
        record('measures', 'Failed', 'Measure names must be unique ignoring case.')
    for m in model.measures:
        scope = m.display_name or m.name
        before = len(checks)
        if m.needs_clarification:
            record(scope, 'Failed', 'Business definition still needs clarification.')
        if m.base_table and m.base_table not in schema:
            record(scope, 'Failed', f'Unknown source table: {m.base_table}')
        if m.base_column and m.base_column not in schema.get(m.base_table, {}):
            record(scope, 'Failed', f'Unknown source column: {m.base_column}')
        col = schema.get(m.base_table, {}).get(m.base_column)
        if col and m.aggregation.value in ('SUM', 'AVG') and not col.is_numeric:
            record(scope, 'Failed', 'SUM/AVG needs a numeric source column.')
        for dep in m.dependencies:
            matches = [candidate for candidate in model.measures
                       if dep.casefold() in {candidate.name.casefold(), candidate.display_name.casefold()}]
            if not matches:
                record(scope, 'Failed', f'Missing dependent measure: {dep}')
            elif len(matches) > 1:
                record(scope, 'Failed', f'Ambiguous dependent measure: {dep}')
        for f in m.filter_conditions:
            if f.column not in schema.get(m.base_table, {}):
                record(scope, 'Failed', f'Unknown filter column: {f.column}')
            else:
                df = dfs.get(m.base_table)
                if df is not None and f.operator == '=' and not df[f.column].eq(f.value).any():
                    record(scope, 'Needs clarification', f'Filter {f.column} = {f.value!r} matches no current rows.')
        dax = m.dax_formula or ''
        if not dax or 'TODO' in dax or '[value]' in dax:
            record(scope, 'Failed', f'Formula is missing or is an unfinished template for measure "{m.display_name or m.name}".')
        for table, column in re.findall(r"'((?:[^']|'')+)'\[((?:[^\]]|\]\])+)\]", dax):
            table, column = table.replace("''", "'"), column.replace(']]', ']')
            if column not in schema.get(table, {}):
                record(scope, 'Failed', f'Formula references missing field {table}[{column}].')
        if len(checks) == before:
            record(scope, 'Passed', 'Available source fields and basic definition checks passed; DAX has not been executed.')
    from .protocol_parser import detect_dependency_cycles
    if detect_dependency_cycles(model.measures):
        record('measures', 'Failed', 'Measure dependency cycle.')
    graph = {}
    for rel in model.relationships:
        scope = f'{rel.from_table}.{rel.from_column} -> {rel.to_table}.{rel.to_column}'
        left, right = dfs.get(rel.from_table), dfs.get(rel.to_table)
        if left is None or right is None or rel.from_column not in left or rel.to_column not in right:
            record(scope, 'Failed', 'Relationship field does not exist.')
            continue
        keys = right[rel.to_column]
        # VertiPaq text keys are case-insensitive.
        comparable = keys.map(lambda v: str(v).casefold() if isinstance(v, str) else v)
        if comparable.duplicated().any():
            record(scope, 'Failed', 'Lookup keys are not unique (including case-insensitive duplicates).')
        elif keys.isna().any():
            record(scope, 'Failed', 'Lookup key contains null values.')
        else:
            record(scope, 'Passed', 'Lookup key exists and is unique.')
        a = schema[rel.from_table][rel.from_column]
        b = schema[rel.to_table][rel.to_column]
        if (a.is_numeric, a.is_date) != (b.is_numeric, b.is_date):
            record(scope, 'Failed', 'Relationship key types are incompatible.')
        if rel.is_active:
            graph.setdefault(rel.to_table, []).append(rel.from_table)
    def walk(node, path, counts):
        if node in path:
            raise ValueError('Active relationship cycle.')
        counts[node] = counts.get(node, 0) + 1
        if counts[node] > 1:
            raise ValueError('Multiple active filter paths reach the same table.')
        for child in graph.get(node, []):
            walk(child, path | {node}, counts)
    for node in graph:
        try:
            walk(node, set(), {})
        except ValueError as exc:
            record('relationships', 'Failed', str(exc))
            break
    record('DAX engine execution', 'Not checked', 'Open and refresh the project in Power BI Desktop; compare approved expected values.')
    record('Business result acceptance', 'Not checked', 'A successful JSON export does not certify business results.')
    model.validation = checks
    return checks

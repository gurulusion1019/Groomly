"""
core/model_builder.py
Assembles the semantic model from confirmed mappings and measures.
Exports to Excel and JSON (Power BI TMDL stub).
"""
import json
import io
import logging
from datetime import datetime
from typing import Optional
import pandas as pd
import openpyxl
from openpyxl.styles import (
    Font, PatternFill, Alignment, Border, Side, numbers
)
from openpyxl.utils import get_column_letter

from .models import (
    ProjectContext, SemanticModel, FileMeta, MappingDecision,
    MeasureDefinition, Relationship, JoinType,
    DataError, ResolutionMethod
)
from .protocol_parser import generate_dax

logger = logging.getLogger(__name__)

# ── Colour palette for Excel ──────────────────────────────────────────────
NAV  = "0F2D52"
BLU  = "1565C0"
GRN  = "1B5E20"
AMB  = "E65100"
RED  = "B71C1C"
GRY  = "F5F5F5"
WHT  = "FFFFFF"
LBL  = "E3F2FD"
LGN  = "E8F5E9"
MID  = "BDBDBD"


def _hdr_font(bold=True, color=WHT, size=9):
    return Font(bold=bold, color=color, size=size, name='Calibri')

def _cell_font(bold=False, color="212121", size=9):
    return Font(bold=bold, color=color, size=size, name='Calibri')

def _fill(hex_color):
    return PatternFill(fill_type='solid', fgColor=hex_color)

def _border():
    s = Side(style='thin', color=MID)
    return Border(left=s, right=s, top=s, bottom=s)

def _set_hdr(cell, value, bg=NAV, fg=WHT, bold=True):
    cell.value = value
    cell.font = _hdr_font(bold=bold, color=fg)
    cell.fill = _fill(bg)
    cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
    cell.border = _border()

def _set_cell(cell, value, bg=None, bold=False, color="212121", wrap=False, align='left'):
    cell.value = value
    cell.font = _cell_font(bold=bold, color=color)
    if bg:
        cell.fill = _fill(bg)
    cell.alignment = Alignment(horizontal=align, vertical='center', wrap_text=wrap)
    cell.border = _border()

def _auto_width(ws, min_w=10, max_w=50):
    for col in ws.columns:
        max_len = max_w
        col_letter = get_column_letter(col[0].column)
        lengths = [len(str(c.value or '')) for c in col if c.value]
        if lengths:
            max_len = min(max(max(lengths) + 2, min_w), max_w)
        ws.column_dimensions[col_letter].width = max_len


# ── Model assembly ─────────────────────────────────────────────────────────

def assemble_model(ctx: ProjectContext) -> SemanticModel:
    """
    Build the SemanticModel from a completed ProjectContext.
    Generates DAX formulas, validates relationships, assembles metadata.
    """
    model = SemanticModel(
        project_id=ctx.project_id,
        project_name=ctx.project_name,
        tables=ctx.raw_files + ctx.mapping_files,
        mapping_decisions=[d for d in ctx.mapping_decisions if d.user_confirmed],
        errors_resolved=[e for e in ctx.errors
                         if e.resolution_method != ResolutionMethod.PENDING],
        built_at=datetime.now(),
    )

    if ctx.pending_errors():
        raise ValueError('Resolve or explicitly retain pending data issues before building.')
    # Build relationships from confirmed mappings.
    # Power BI/Tabular only allows ONE active relationship between any given
    # pair of tables — additional relationships to the same table pair
    # (e.g. OrderDate, ShipDate, and DeliveryDate all referencing the same
    # Date dimension — a normal "role-playing dimension" pattern) must be
    # marked inactive, or the model fails to load with an
    # "ambiguous paths" error. The first relationship found for a given
    # table pair stays active; later ones to that same pair are inactive
    # (still present in the model, usable in DAX via USERELATIONSHIP()).
    seen_rels = set()
    active_table_pairs = set()
    for d in model.mapping_decisions:
        key = (d.source_table, d.source_column, d.target_table, d.target_column)
        if key in seen_rels:
            continue
        seen_rels.add(key)

        pair = (d.source_table, d.target_table)
        is_first_for_pair = pair not in active_table_pairs
        if is_first_for_pair:
            active_table_pairs.add(pair)

        model.relationships.append(Relationship(
            from_table=d.source_table,
            from_column=d.source_column,
            to_table=d.target_table,
            to_column=d.target_column,
            join_type=d.join_type,
            is_active=is_first_for_pair,
        ))

    # Resolve a missing/unknown source table only when the column is unambiguous.
    for measure in ctx.measures:
        if measure.base_table:
            matches = [t.table_name for t in model.tables if t.table_name.casefold() == measure.base_table.casefold()]
            if len(matches) == 1:
                measure.base_table = matches[0]
        if measure.base_table not in {t.table_name for t in model.tables} and measure.base_column:
            matches = [t.table_name for t in model.tables if measure.base_column in {c.name for c in t.columns}]
            if len(matches) == 1:
                measure.base_table = matches[0]
    # Build table schema for DAX generation
    table_schema: dict[str, list[str]] = {}
    for meta in model.tables:
        table_schema[meta.table_name] = [c.name for c in meta.columns]

    all_measure_names = [m.display_name for m in ctx.measures]

    # Generate DAX for each measure
    warnings = []
    for m in ctx.measures:
        if not m.dax_formula:
            m.dax_formula = generate_dax(m, table_schema, all_measure_names)
        model.measures.append(m)

    from .chat_agent import _get_all_dfs
    from .validation import validate_model, refresh_metadata
    dfs = _get_all_dfs(ctx)
    for meta in model.tables:
        if meta.table_name in dfs:
            refresh_metadata(meta, dfs[meta.table_name])
    checks = validate_model(model, dfs)
    ctx.validation = checks
    failures = [c['detail'] for c in checks if c['status'] == 'Failed']
    if failures:
        raise ValueError('; '.join(failures))
    warnings.extend(c['detail'] for c in checks if c['status'] in ('Not checked', 'Needs clarification'))
    # Total rows
    model.total_rows = sum(f.row_count for f in ctx.raw_files)
    model.build_warnings = warnings

    return model


# ── Excel export ───────────────────────────────────────────────────────────

def export_excel(
    model: SemanticModel,
    dataframes: dict[str, pd.DataFrame],
) -> bytes:
    """
    Build a comprehensive Excel workbook:
    - Sheet per data table (cleaned)
    - Relationships sheet
    - Measures sheet
    - Data Quality Log sheet
    - Model Summary sheet
    """
    wb = openpyxl.Workbook()
    wb.remove(wb.active)  # remove default sheet

    # ── Model Summary ──────────────────────────────────────────────────────
    ws_sum = wb.create_sheet("Model Summary")
    ws_sum.sheet_view.showGridLines = False
    ws_sum.column_dimensions['A'].width = 28
    ws_sum.column_dimensions['B'].width = 45

    rows = [
        ("Project name", model.project_name),
        ("Project ID", model.project_id),
        ("Model ID", model.model_id),
        ("Built at", str(model.built_at)[:19] if model.built_at else ""),
        ("Total rows processed", f"{model.total_rows:,}"),
        ("Tables in model", str(len(model.tables))),
        ("Relationships", str(len(model.relationships))),
        ("Measures", str(len(model.measures))),
        ("Errors resolved", str(len(model.errors_resolved))),
        ("Build warnings", str(len(model.build_warnings))),
    ]
    ws_sum.append(["AI Reporting Automation — Semantic Model"])
    ws_sum['A1'].font = Font(bold=True, size=13, color=NAV, name='Calibri')
    ws_sum.append([])
    for r in rows:
        ws_sum.append(list(r))
    for row in ws_sum.iter_rows(min_row=3, max_row=3 + len(rows) - 1):
        row[0].font = _cell_font(bold=True)
        row[0].fill = _fill(GRY)
        row[0].border = _border()
        if len(row) > 1:
            row[1].border = _border()

    # ── Measures sheet ─────────────────────────────────────────────────────
    ws_m = wb.create_sheet("Measures")
    ws_m.sheet_view.showGridLines = False
    hdrs = ["Name", "Display name", "Description", "Aggregation",
            "Base column", "Format", "KPI", "Time intel", "Confidence", "DAX Formula"]
    for ci, h in enumerate(hdrs, 1):
        _set_hdr(ws_m.cell(1, ci), h)

    for ri, m in enumerate(model.measures, 2):
        bg = LGN if ri % 2 == 0 else WHT
        vals = [
            m.name, m.display_name, m.description,
            m.aggregation.value, m.base_column or "",
            m.format_string, "✓" if m.is_kpi else "",
            m.time_intelligence or "", f"{m.confidence:.0%}",
            m.dax_formula or "",
        ]
        for ci, v in enumerate(vals, 1):
            cell = ws_m.cell(ri, ci)
            is_dax = ci == len(hdrs)
            _set_cell(cell, v, bg=bg, wrap=is_dax)
            if is_dax:
                cell.font = Font(name='Courier New', size=8, color="1A237E")

    _auto_width(ws_m, min_w=12, max_w=60)
    ws_m.freeze_panes = "A2"

    # ── Relationships sheet ────────────────────────────────────────────────
    ws_r = wb.create_sheet("Relationships")
    ws_r.sheet_view.showGridLines = False
    r_hdrs = ["From table", "From column", "To table", "To column",
              "Join type", "Active", "Cross filter"]
    for ci, h in enumerate(r_hdrs, 1):
        _set_hdr(ws_r.cell(1, ci), h)

    for ri, rel in enumerate(model.relationships, 2):
        bg = LBL if ri % 2 == 0 else WHT
        for ci, v in enumerate([
            rel.from_table, rel.from_column,
            rel.to_table, rel.to_column,
            rel.join_type.value, "Yes" if rel.is_active else "No",
            rel.cross_filter,
        ], 1):
            _set_cell(ws_r.cell(ri, ci), v, bg=bg)

    _auto_width(ws_r)
    ws_r.freeze_panes = "A2"

    # ── Mapping decisions sheet ────────────────────────────────────────────
    ws_mp = wb.create_sheet("Column Mappings")
    ws_mp.sheet_view.showGridLines = False
    mp_hdrs = ["Source table", "Source column", "Target table", "Target column",
               "Confidence", "Method", "Confirmed", "AI reasoning"]
    for ci, h in enumerate(mp_hdrs, 1):
        _set_hdr(ws_mp.cell(1, ci), h)

    for ri, d in enumerate(model.mapping_decisions, 2):
        bg = GRY if ri % 2 == 0 else WHT
        conf_color = GRN if d.confidence >= 0.9 else AMB if d.confidence >= 0.7 else RED
        for ci, v in enumerate([
            d.source_table, d.source_column,
            d.target_table, d.target_column,
            f"{d.confidence:.0%}", d.method.value,
            "Yes" if d.user_confirmed else "No",
            d.ai_reasoning or "",
        ], 1):
            cell = ws_mp.cell(ri, ci)
            _set_cell(cell, v, bg=bg)
            if ci == 5:  # confidence column
                cell.font = Font(bold=True, color=conf_color, size=9, name='Calibri')

    _auto_width(ws_mp)
    ws_mp.freeze_panes = "A2"

    # ── Data Quality Log ───────────────────────────────────────────────────
    ws_dq = wb.create_sheet("Data Quality Log")
    ws_dq.sheet_view.showGridLines = False
    dq_hdrs = ["Error ID", "Category", "Sub-type", "Severity", "Table",
               "Column", "Rows affected", "Measure value", "Resolution mode",
               "Decision", "Rows dropped", "Rows quarantined", "Rows modified",
               "Resolved at", "Notes"]
    for ci, h in enumerate(dq_hdrs, 1):
        _set_hdr(ws_dq.cell(1, ci), h)

    for ri, e in enumerate(model.errors_resolved, 2):
        sev_color = (RED if e.severity.value in ('HIGH', 'CRITICAL', 'BLOCKER')
                     else AMB if e.severity.value == 'MEDIUM' else "212121")
        bg = GRY if ri % 2 == 0 else WHT
        chosen = next(
            (o.label for o in e.options if o.option_id == e.chosen_option_id), ""
        ) if e.chosen_option_id else "(auto)"
        for ci, v in enumerate([
            e.error_id, e.category.value, e.sub_type,
            e.severity.value, e.affected_table, e.affected_column,
            e.affected_row_count, f"{e.affected_measure_value:,.0f}" if e.affected_measure_value else "",
            e.resolution_method.value, chosen,
            e.rows_dropped, e.rows_quarantined, e.rows_modified,
            str(e.resolved_at)[:19] if e.resolved_at else "",
            e.resolution_notes,
        ], 1):
            cell = ws_dq.cell(ri, ci)
            _set_cell(cell, v, bg=bg, wrap=(ci == len(dq_hdrs)))
            if ci == 4:
                cell.font = Font(bold=True, color=sev_color, size=9, name='Calibri')

    _auto_width(ws_dq, min_w=10, max_w=40)
    ws_dq.freeze_panes = "A2"

    # ── Data tables ────────────────────────────────────────────────────────
    for table_name, df in dataframes.items():
        if df.empty:
            continue
        # Truncate to 50k rows for Excel compatibility
        df_out = df.head(50000)
        ws_t = wb.create_sheet(table_name[:31])   # Excel tab name limit
        ws_t.sheet_view.showGridLines = False

        for ci, col in enumerate(df_out.columns, 1):
            _set_hdr(ws_t.cell(1, ci), str(col), bg=BLU)

        for ri, row in enumerate(df_out.itertuples(index=False), 2):
            bg = GRY if ri % 2 == 0 else WHT
            for ci, val in enumerate(row, 1):
                v = "" if pd.isna(val) else val
                _set_cell(ws_t.cell(ri, ci), v, bg=bg)

        _auto_width(ws_t)
        ws_t.freeze_panes = "A2"

    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()


# ── JSON / TMDL export ─────────────────────────────────────────────────────

def export_tmdl_json(model: SemanticModel) -> str:
    """
    Export a JSON representation of the semantic model.
    Compatible with Power BI TMDL (Tabular Model Definition Language) structure.
    """
    tables = []
    for meta in model.tables:
        columns = []
        for col in meta.columns:
            columns.append({
                "name": col.name,
                "dataType": _map_dtype(col.dtype),
                "isHidden": False,
                "summarizeBy": "none",
            })
        tables.append({
            "name": meta.table_name,
            "columns": columns,
            "partitions": [{"name": "default", "mode": "import"}],
        })

    measures = []
    for m in model.measures:
        measures.append({
            "name": m.display_name,
            "expression": (m.dax_formula or "").split("=", 1)[-1].strip(),
            "formatString": m.format_string,
            "description": m.description,
            "displayFolder": "KPIs" if m.is_kpi else "Measures",
            "isHidden": False,
        })

    relationships = []
    for rel in model.relationships:
        relationships.append({
            "name": f"{rel.from_table}_{rel.from_column}_to_{rel.to_table}",
            "fromTable": rel.from_table,
            "fromColumn": rel.from_column,
            "toTable": rel.to_table,
            "toColumn": rel.to_column,
            "crossFilteringBehavior": "bothDirections" if rel.cross_filter.upper() in ("BOTH","BOTHDIRECTIONS") else "oneDirection",
            "isActive": rel.is_active,
        })

    tmdl = {
        "model": {
            "name": model.project_name,
            "description": f"Generated by AI Reporting Automation System — {model.built_at}",
            "tables": tables,
            "measures": measures,
            "relationships": relationships,
            "annotations": [
                {"name": "generated_by", "value": "AI Reporting Automation System v1.0"},
                {"name": "model_id", "value": model.model_id},
                {"name": "project_id", "value": model.project_id},
            ],
        }
    }
    return json.dumps(tmdl, indent=2, default=str)


def export_audit_log(model: SemanticModel) -> str:
    """Export the full error resolution audit log as JSON."""
    log = {
        "project_id": model.project_id,
        "project_name": model.project_name,
        "model_id": model.model_id,
        "generated_at": str(datetime.now()),
        "resolutions": [],
    }
    for e in model.errors_resolved:
        chosen_label = next(
            (o.label for o in e.options if o.option_id == e.chosen_option_id), None
        )
        log["resolutions"].append({
            "error_id": e.error_id,
            "category": e.category.value,
            "sub_type": e.sub_type,
            "severity": e.severity.value,
            "affected_table": e.affected_table,
            "affected_column": e.affected_column,
            "affected_row_count": e.affected_row_count,
            "affected_measure_value": e.affected_measure_value,
            "resolution_method": e.resolution_method.value,
            "chosen_option": chosen_label,
            "rows_dropped": e.rows_dropped,
            "rows_quarantined": e.rows_quarantined,
            "rows_modified": e.rows_modified,
            "resolution_notes": e.resolution_notes,
            "detected_at": str(e.detected_at),
            "resolved_at": str(e.resolved_at) if e.resolved_at else None,
        })
    return json.dumps(log, indent=2, default=str)


def _map_dtype(pandas_dtype: str) -> str:
    """Map pandas dtype string to TMDL data type."""
    dtype = pandas_dtype.lower()
    if 'int' in dtype:
        return "int64"
    if 'float' in dtype:
        return "double"
    if 'bool' in dtype:
        return "boolean"
    if 'datetime' in dtype:
        return "dateTime"
    return "string"


# ── Power BI export (BIM + Report) ────────────────────────────────────────

def export_powerbi_package(model: SemanticModel) -> bytes:
    """
    Generate a ZIP containing:
      - model.bim        (Analysis Services / Power BI BIM semantic model)
      - report.json      (Power BI report layout with auto-selected visuals)
      - README_IMPORT.txt (step-by-step import guide for Power BI Desktop)

    Import via Tabular Editor → Power BI Desktop (see README for full guide).
    Returns raw ZIP bytes ready for HTTP download or disk write.
    """
    from .pbi_exporter import export_powerbi_package as _do_export
    return _do_export(model)


def export_bim(model: SemanticModel) -> str:
    """Return the BIM JSON string for the semantic model (model.bim)."""
    from .pbi_exporter import export_bim as _do_bim
    return _do_bim(model)


def export_report_json(model: SemanticModel) -> str:
    """Return the report layout JSON string (report.json)."""
    from .pbi_exporter import export_report_json as _do_report
    return _do_report(model)

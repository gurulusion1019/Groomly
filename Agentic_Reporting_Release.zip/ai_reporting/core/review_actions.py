"""Apply review decisions to actual data and invalidate dependent outputs."""
from datetime import datetime
import pandas as pd
from .models import ResolutionMethod, IntakeState
from .validation import refresh_metadata

def invalidate(ctx):
    ctx.semantic_model = None
    ctx.excel_bytes = ctx.pbi_zip = None
    ctx.tmdl_json = ctx.audit_json = None
    ctx.validation = []

def recheck_mappings(ctx):
    """Re-measure every chosen relationship, including user edits, on current data."""
    from .chat_agent import _get_df
    from .automapper import _value_overlap, check_orphan_fks
    from .file_processor import _check_duplicates
    existing = {(e.sub_type, e.affected_table, e.affected_column, e.affected_row_count) for e in ctx.errors}
    for mapping in ctx.mapping_decisions:
        fact, dim = _get_df(ctx, mapping.source_table), _get_df(ctx, mapping.target_table)
        if fact is None or dim is None or mapping.source_column not in fact or mapping.target_column not in dim:
            raise ValueError('A relationship points to a missing field. Correct it in the review panel.')
        mapping.value_overlap = _value_overlap(fact[mapping.source_column].dropna().tolist(), dim[mapping.target_column].dropna().tolist())
        errors = [e for e in _check_duplicates(dim, mapping.target_table, [mapping.target_column]) if e.sub_type == 'DUPLICATE_PK']
        orphan = check_orphan_fks(fact, dim, mapping.source_column, mapping.target_column)
        if orphan:
            orphan.affected_table = mapping.source_table
            errors.append(orphan)
        for error in errors:
            key = (error.sub_type, error.affected_table, error.affected_column, error.affected_row_count)
            if key not in existing:
                ctx.errors.append(error)
                existing.add(key)

def resolve(ctx, error, option):
    from .chat_agent import _get_df, _store_df
    from .file_processor import apply_error_resolution
    chosen = next((o for o in error.options if o.option_id == option), None)
    if chosen is None:
        raise ValueError('Unknown resolution option.')
    if 'stop' in chosen.label.lower() or 're-upload' in chosen.label.lower():
        return 'Paused. Upload a corrected file with the same name to replace the source.'
    table = error.affected_table
    df = _get_df(ctx, table)
    if df is None:
        raise ValueError('This decision requires a corrected definition or source file.')
    if error.sub_type == 'ORPHAN_FK':
        mappings = [d for d in ctx.mapping_decisions if d.source_table == table and d.source_column == error.affected_column]
        if len(mappings) != 1:
            raise ValueError('Select one relationship for this column before resolving unmatched keys.')
        mapping = mappings[0]
        dimension = _get_df(ctx, mapping.target_table)
        mask = df[mapping.source_column].notna() & ~df[mapping.source_column].isin(dimension[mapping.target_column])
        if option == 'a':
            error.rows_dropped = int(mask.sum())
            df = df.loc[~mask].copy()
        elif option == 'b':
            raise ValueError('Automatic placeholder creation is not supported in this release. Choose A to exclude or C to retain unmatched rows, or replace the lookup file.')
        elif option != 'c':
            raise ValueError('Choose exclusion, retention, or upload a corrected lookup.')
        error.resolution_method = ResolutionMethod.USER_DECISION
        error.resolution_notes = f'Unmatched keys: {int(mask.sum())} affected rows; option {option} applied.'
    elif error.sub_type == 'JOIN_FANOUT':
        raise ValueError('Correct duplicate lookup keys or reject this relationship before building. A many-to-many model requires an explicit bridge design.')
    else:
        if error.sub_type == 'NULL_JOIN_KEY' and option == 'b':
            raise ValueError('Placeholder creation is not supported. Choose A to exclude, C to retain, or replace the source.')
        if 'quarantine' in chosen.label.lower():
            subset = None if error.sub_type == 'DUPLICATE_ROWS' else [error.affected_column]
            quarantined = df[df.duplicated(subset=subset, keep='first')].copy()
            previous = _get_df(ctx, table + '_quarantine')
            if previous is not None:
                quarantined = pd.concat([previous, quarantined], ignore_index=True)
            _store_df(ctx, table + '_quarantine', quarantined)
        df, error = apply_error_resolution(df, error, option)
        if error.resolution_method == ResolutionMethod.PENDING:
            raise ValueError('This action has not been applied. Correct the source or definition.')
    error.chosen_option_id = option
    error.user_confirmed = True
    error.resolved_at = datetime.now()
    _store_df(ctx, table, df)
    for meta in ctx.raw_files + ctx.mapping_files:
        if meta.table_name == table:
            refresh_metadata(meta, df)
    invalidate(ctx)
    return error.resolution_notes

def replace_upload(ctx, attached_file):
    from .chat_agent import _store_df
    from .file_processor import process_file
    from .automapper import run_automapping
    from .chat_agent import _build_file_pairs
    name, content = attached_file[:2]
    candidates = [m for m in ctx.raw_files + ctx.mapping_files if m.file_name == name]
    if len(candidates) != 1:
        raise ValueError('Replacement upload must use the same filename as one existing source.')
    old = candidates[0]
    meta, df, errors = process_file(content, name, old.file_role, ctx.project_id)
    if any(e.sub_type == 'UNREADABLE_FILE' for e in errors):
        raise ValueError(errors[0].detail)
    for group in (ctx.raw_files, ctx.mapping_files):
        for index, item in enumerate(group):
            if item.file_id == old.file_id:
                group[index] = meta
    _store_df(ctx, meta.table_name, df)
    ctx.errors = [e for e in ctx.errors if e.affected_table != old.table_name and e.category.value != 'REFERENTIAL_INTEGRITY'] + errors
    if len(attached_file) > 2:
        ctx.file_paths[meta.table_name] = attached_file[2]
    decisions, errors = run_automapping(_build_file_pairs(ctx, ctx.raw_files), _build_file_pairs(ctx, ctx.mapping_files))
    ctx.mapping_decisions = decisions
    ctx.errors.extend(errors)
    invalidate(ctx)
    ctx.intake_state = IntakeState.MAPPING_REVIEW
    return 'Source replaced and reprofiled. Relationships must be reviewed again; existing measure fields will be checked before build.'

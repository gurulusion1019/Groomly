"""
core/models.py
All shared dataclasses for the AI Reporting Automation pipeline.
"""
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Optional
from datetime import datetime
import uuid


# ── Enums ──────────────────────────────────────────────────────────────────

class FileRole(str, Enum):
    RAW_DATA = "RAW_DATA"
    MAPPING  = "MAPPING"
    PROTOCOL = "PROTOCOL"

class MappingMethod(str, Enum):
    EXACT      = "EXACT"
    FUZZY      = "FUZZY"
    AI_INFERRED = "AI_INFERRED"
    USER_DEFINED = "USER_DEFINED"
    UNMAPPED   = "UNMAPPED"

class JoinType(str, Enum):
    INNER        = "INNER"
    LEFT         = "LEFT"
    MANY_TO_ONE  = "MANY_TO_ONE"
    ONE_TO_ONE   = "ONE_TO_ONE"

class AggregationType(str, Enum):
    SUM    = "SUM"
    COUNT  = "COUNT"
    COUNTD = "COUNTD"
    AVG    = "AVG"
    MIN    = "MIN"
    MAX    = "MAX"
    RATIO  = "RATIO"
    CUSTOM = "CUSTOM"

class ErrorCategory(str, Enum):
    DATA_QUALITY         = "DATA_QUALITY"
    REFERENTIAL_INTEGRITY = "REFERENTIAL_INTEGRITY"
    SCHEMA               = "SCHEMA"
    PROTOCOL             = "PROTOCOL"
    MAPPING              = "MAPPING"
    SYSTEM               = "SYSTEM"

class ErrorSeverity(str, Enum):
    CRITICAL = "CRITICAL"
    HIGH     = "HIGH"
    MEDIUM   = "MEDIUM"
    LOW      = "LOW"
    BLOCKER  = "BLOCKER"

class ResolutionMethod(str, Enum):
    AUTO             = "AUTO"
    USER_DECISION    = "USER_DECISION"
    USER_SKIP        = "USER_SKIP"
    BLOCKER_RESOLVED = "BLOCKER_RESOLVED"
    PENDING          = "PENDING"

class IntakeState(str, Enum):
    PROJECT_INIT   = "PROJECT_INIT"
    RAW_DATA       = "RAW_DATA"
    MAPPING_FILES  = "MAPPING_FILES"
    PROTOCOL       = "PROTOCOL"
    CLARIFY        = "CLARIFY"
    MAPPING_REVIEW = "MAPPING_REVIEW"
    ERROR_REVIEW   = "ERROR_REVIEW"
    MODEL_BUILD    = "MODEL_BUILD"
    EXPORT         = "EXPORT"
    COMPLETE       = "COMPLETE"

class ExportTarget(str, Enum):
    EXCEL   = "EXCEL"
    POWERBI = "POWERBI"
    TMDL    = "TMDL"
    JSON    = "JSON"


# ── Column and file metadata ───────────────────────────────────────────────

@dataclass
class ColumnMeta:
    name: str
    dtype: str                        # inferred pandas dtype as string
    null_count: int
    null_pct: float
    unique_count: int
    cardinality_pct: float            # unique / total rows
    sample_values: list[Any]          # first 10 non-null values
    is_pk_candidate: bool = False     # 100% unique, 0 nulls
    is_numeric: bool = False
    is_date: bool = False
    mixed_types: bool = False         # column has mixed parseable types


@dataclass
class FileMeta:
    file_id: str = field(default_factory=lambda: str(uuid.uuid4())[:8])
    file_name: str = ""
    table_name: str = ""              # snake_case cleaned name
    file_role: FileRole = FileRole.RAW_DATA
    row_count: int = 0
    col_count: int = 0
    file_size_mb: float = 0.0
    columns: list[ColumnMeta] = field(default_factory=list)
    pk_candidates: list[str] = field(default_factory=list)
    sheet_name: str = ""              # for Excel multi-sheet
    errors_detected: list[str] = field(default_factory=list)
    loaded_at: datetime = field(default_factory=datetime.now)


# ── Mapping ────────────────────────────────────────────────────────────────

@dataclass
class MappingDecision:
    decision_id: str = field(default_factory=lambda: str(uuid.uuid4())[:8])
    source_table: str = ""
    source_column: str = ""
    target_table: str = ""
    target_column: str = ""
    confidence: float = 0.0
    method: MappingMethod = MappingMethod.UNMAPPED
    join_type: JoinType = JoinType.MANY_TO_ONE
    ai_reasoning: Optional[str] = None
    string_similarity: float = 0.0
    value_overlap: float = 0.0
    user_confirmed: bool = False
    user_override: bool = False
    created_at: datetime = field(default_factory=datetime.now)
    confirmed_at: Optional[datetime] = None


# ── Measures ───────────────────────────────────────────────────────────────

@dataclass
class FilterCondition:
    column: str
    operator: str   # =, !=, >, <, IN, NOT IN, IS NULL, IS NOT NULL
    value: Any


@dataclass
class MeasureDefinition:
    measure_id: str = field(default_factory=lambda: str(uuid.uuid4())[:8])
    name: str = ""
    display_name: str = ""
    description: str = ""
    aggregation: AggregationType = AggregationType.SUM
    numerator: Optional[str] = None
    denominator: Optional[str] = None
    base_column: Optional[str] = None
    base_table: Optional[str] = None
    filter_conditions: list[FilterCondition] = field(default_factory=list)
    time_intelligence: Optional[str] = None   # YTD, MTD, ROLLING_12M, PRIOR_PERIOD
    dimensions: list[str] = field(default_factory=list)
    format_string: str = "#,##0"
    is_kpi: bool = False
    kpi_target: Optional[str] = None
    dependencies: list[str] = field(default_factory=list)
    dax_formula: Optional[str] = None
    confidence: float = 0.0
    source_excerpt: str = ""
    needs_clarification: bool = False
    clarification_questions: list[str] = field(default_factory=list)
    clarification_answers: dict = field(default_factory=dict)


# ── Error handling ─────────────────────────────────────────────────────────

@dataclass
class ResolutionOption:
    option_id: str          # 'a', 'b', 'c' …
    label: str
    description: str
    impact_summary: str
    rows_affected: int = 0
    measure_value_affected: float = 0.0
    is_safe: bool = True
    is_recommended: bool = False


@dataclass
class DataError:
    error_id: str = field(default_factory=lambda: str(uuid.uuid4())[:8])
    project_id: str = ""
    category: ErrorCategory = ErrorCategory.DATA_QUALITY
    sub_type: str = ""
    severity: ErrorSeverity = ErrorSeverity.MEDIUM
    affected_table: str = ""
    affected_column: str = ""
    affected_row_count: int = 0
    affected_measure_value: float = 0.0
    detail: str = ""
    sample_data: list[dict] = field(default_factory=list)
    options: list[ResolutionOption] = field(default_factory=list)
    recommended_option_id: Optional[str] = None
    chosen_option_id: Optional[str] = None
    resolution_method: ResolutionMethod = ResolutionMethod.PENDING
    resolution_notes: str = ""
    rows_dropped: int = 0
    rows_quarantined: int = 0
    rows_modified: int = 0
    user_confirmed: bool = False
    detected_at: datetime = field(default_factory=datetime.now)
    resolved_at: Optional[datetime] = None
    model_built_with_warning: bool = False


# ── Semantic model ─────────────────────────────────────────────────────────

@dataclass
class Relationship:
    from_table: str
    from_column: str
    to_table: str
    to_column: str
    join_type: JoinType = JoinType.MANY_TO_ONE
    is_active: bool = True
    cross_filter: str = "SINGLE"   # SINGLE or BOTH


@dataclass
class SemanticModel:
    model_id: str = field(default_factory=lambda: str(uuid.uuid4())[:8])
    project_id: str = ""
    project_name: str = ""
    tables: list[FileMeta] = field(default_factory=list)
    relationships: list[Relationship] = field(default_factory=list)
    measures: list[MeasureDefinition] = field(default_factory=list)
    errors_resolved: list[DataError] = field(default_factory=list)
    mapping_decisions: list[MappingDecision] = field(default_factory=list)
    built_at: Optional[datetime] = None
    build_warnings: list[str] = field(default_factory=list)
    total_rows: int = 0
    validation: list[dict] = field(default_factory=list)


# ── Project context (single source of truth) ───────────────────────────────

@dataclass
class ProjectContext:
    project_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    project_name: str = ""
    project_description: str = ""
    intake_state: IntakeState = IntakeState.PROJECT_INIT
    raw_files: list[FileMeta] = field(default_factory=list)
    mapping_files: list[FileMeta] = field(default_factory=list)
    protocol_text: str = ""
    protocol_file_name: str = ""
    measures: list[MeasureDefinition] = field(default_factory=list)
    mapping_decisions: list[MappingDecision] = field(default_factory=list)
    errors: list[DataError] = field(default_factory=list)
    semantic_model: Optional[SemanticModel] = None
    chat_history: list[dict] = field(default_factory=list)  # {role, content}
    clarification_log: list[dict] = field(default_factory=list)
    export_targets: list[ExportTarget] = field(default_factory=list)
    created_at: datetime = field(default_factory=datetime.now)
    last_updated: datetime = field(default_factory=datetime.now)

    # ── Typed fields for in-memory dataframe + export storage ──────────────
    # (Replaces the old dynamic attributes like ctx._dataframes, ctx._excel_bytes.
    #  dataframe_store holds serialized (parquet/pickle) bytes per table_name.)
    dataframe_store: dict[str, bytes] = field(default_factory=dict)
    excel_bytes: Optional[bytes] = None
    tmdl_json: Optional[str] = None
    audit_json: Optional[str] = None
    pbi_zip: Optional[bytes] = None
    file_paths: dict[str, str] = field(default_factory=dict)
    owner_id: str = ""
    validation: list[dict] = field(default_factory=list)

    def add_message(self, role: str, content: str):
        self.chat_history.append({"role": role, "content": content})
        self.last_updated = datetime.now()

    def pending_errors(self) -> list[DataError]:
        return [e for e in self.errors
                if e.resolution_method == ResolutionMethod.PENDING]

    def all_errors_resolved(self) -> bool:
        return all(e.resolution_method != ResolutionMethod.PENDING
                   for e in self.errors)
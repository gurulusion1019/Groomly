"""
core/automapper.py
Three-pass automapping engine.
Pass 1: exact name match
Pass 2: fuzzy name similarity + value overlap
Pass 3: AI semantic inference (Claude API via requests)
"""
import os
import re
import json
import time
import logging
from difflib import SequenceMatcher
from typing import Optional
import pandas as pd
import numpy as np
import requests

from .models import (
    FileMeta, ColumnMeta, MappingDecision, MappingMethod, JoinType,
    DataError, ErrorCategory, ErrorSeverity, ResolutionOption, ResolutionMethod
)

logger = logging.getLogger(__name__)

ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY", "")
CLAUDE_MODEL = os.getenv('CLAUDE_MODEL', 'claude-sonnet-4-5')
MIN_CONFIDENCE_THRESHOLD = 0.70
FUZZY_NAME_THRESHOLD = 0.70
VALUE_OVERLAP_THRESHOLD = 0.55
VALUE_SAMPLE_SIZE = 50


# ── Utilities ──────────────────────────────────────────────────────────────

def _normalise(name: str) -> str:
    """Lowercase, replace separators with underscore, strip edges."""
    return re.sub(r'[^a-z0-9]', '_', name.lower()).strip('_')


def _jaro_winkler(s1: str, s2: str) -> float:
    """
    Jaro-Winkler similarity (pure Python, no external dep needed).
    Falls back to SequenceMatcher if strings are short.
    """
    if s1 == s2:
        return 1.0
    if not s1 or not s2:
        return 0.0

    # Jaro
    max_dist = max(len(s1), len(s2)) // 2 - 1
    if max_dist < 0:
        max_dist = 0

    s1_matches = [False] * len(s1)
    s2_matches = [False] * len(s2)
    matches = 0
    transpositions = 0

    for i, c1 in enumerate(s1):
        lo = max(0, i - max_dist)
        hi = min(i + max_dist + 1, len(s2))
        for j in range(lo, hi):
            if s2_matches[j] or c1 != s2[j]:
                continue
            s1_matches[i] = True
            s2_matches[j] = True
            matches += 1
            break

    if matches == 0:
        return 0.0

    k = 0
    for i, matched in enumerate(s1_matches):
        if not matched:
            continue
        while not s2_matches[k]:
            k += 1
        if s1[i] != s2[k]:
            transpositions += 1
        k += 1

    jaro = (matches / len(s1) + matches / len(s2) +
            (matches - transpositions / 2) / matches) / 3

    # Winkler prefix bonus
    prefix = 0
    for c1, c2 in zip(s1[:4], s2[:4]):
        if c1 == c2:
            prefix += 1
        else:
            break

    return jaro + prefix * 0.1 * (1 - jaro)


def _value_overlap(src_values: list, tgt_values: list) -> float:
    """What fraction of src sample values appear in the target set?"""
    if not src_values or not tgt_values:
        return 0.0
    tgt_set = {str(v).strip().lower() for v in tgt_values}
    hits = sum(
        1 for v in src_values
        if str(v).strip().lower() in tgt_set
    )
    return hits / len(src_values)


def _contains_table_name(col_name: str, table_name: str) -> bool:
    """Check if col_name contains the table's base name as a substring."""
    base = re.sub(r'^(dim_|fact_|tbl_)', '', table_name.lower())
    parts = re.split(r'[_\s]', base)
    col_lower = col_name.lower()
    return any(len(p) >= 3 and p in col_lower for p in parts)


# ── Pass 1: Exact ──────────────────────────────────────────────────────────

def pass1_exact(
    raw_files: list[tuple[FileMeta, pd.DataFrame]],
    map_files: list[tuple[FileMeta, pd.DataFrame]],
) -> list[MappingDecision]:
    """Exact normalised name match. Returns 1.0 confidence decisions."""
    decisions = []

    # Build lookup: normalised_pk_name -> (table_name, original_col_name, sample_values)
    pk_lookup: dict[str, list[tuple]] = {}
    for meta, df in map_files:
        for pk_col in dict.fromkeys(meta.pk_candidates + [c.name for c in meta.columns if re.search(r'(id|key|code)$', c.name, re.I)]):
            key = _normalise(pk_col)
            entry = (meta.table_name, pk_col,
                     df[pk_col].dropna().head(VALUE_SAMPLE_SIZE).tolist())
            pk_lookup.setdefault(key, []).append(entry)

    resolved = set()

    for raw_meta, raw_df in raw_files:
        for col_meta in raw_meta.columns:
            norm = _normalise(col_meta.name)
            if norm not in pk_lookup:
                continue

            matches = pk_lookup[norm]
            # If multiple DIM tables have the same PK name, pick highest cardinality match
            for tgt_table, tgt_col, tgt_samples in matches:
                key = (raw_meta.table_name, col_meta.name, tgt_table, tgt_col)
                if key in resolved:
                    continue
                resolved.add(key)

                d = MappingDecision(
                    source_table=raw_meta.table_name,
                    source_column=col_meta.name,
                    target_table=tgt_table,
                    target_column=tgt_col,
                    confidence=1.0,
                    method=MappingMethod.EXACT,
                    join_type=JoinType.MANY_TO_ONE,
                    string_similarity=1.0,
                    value_overlap=_value_overlap(raw_df[col_meta.name].dropna().tolist(),
                        next(df for meta, df in map_files if meta.table_name == tgt_table)[tgt_col].dropna().tolist()),
                    user_confirmed=False,   # name equality is a proposal, not approval
                )
                decisions.append(d)

    return decisions


# ── Pass 2: Fuzzy ──────────────────────────────────────────────────────────

def pass2_fuzzy(
    raw_files: list[tuple[FileMeta, pd.DataFrame]],
    map_files: list[tuple[FileMeta, pd.DataFrame]],
    already_mapped: set[tuple],
) -> list[MappingDecision]:
    """
    Fuzzy name + value overlap. Returns decisions with confidence 0.70–0.99.
    Does NOT auto-confirm — all presented to user for review.
    """
    decisions = []

    # Flatten all PK columns from map files
    pk_entries = []
    for meta, df in map_files:
        for pk_col in dict.fromkeys(meta.pk_candidates + [c.name for c in meta.columns if re.search(r'(id|key|code)$', c.name, re.I)]):
            pk_entries.append({
                'table': meta.table_name,
                'col': pk_col,
                'norm': _normalise(pk_col),
                'samples': df[pk_col].dropna().head(VALUE_SAMPLE_SIZE).tolist(),
            })

    for raw_meta, raw_df in raw_files:
        for col_meta in raw_meta.columns:
            src_key = (raw_meta.table_name, col_meta.name)
            # Skip already mapped
            if any(k[0] == raw_meta.table_name and k[1] == col_meta.name
                   for k in already_mapped):
                continue

            norm_src = _normalise(col_meta.name)
            src_samples = [str(v) for v in col_meta.sample_values[:VALUE_SAMPLE_SIZE]]

            candidates = []
            for pk in pk_entries:
                tgt_key = (raw_meta.table_name, col_meta.name,
                           pk['table'], pk['col'])
                if tgt_key in already_mapped:
                    continue

                # Name similarity
                name_sim = _jaro_winkler(norm_src, pk['norm'])
                contains_tbl = _contains_table_name(col_meta.name, pk['table'])

                if name_sim < FUZZY_NAME_THRESHOLD and not contains_tbl:
                    continue

                # Value overlap
                overlap = _value_overlap(src_samples, pk['samples'])
                if overlap < VALUE_OVERLAP_THRESHOLD:
                    continue

                # Combined confidence
                conf = (name_sim * 0.5) + (overlap * 0.5)
                if contains_tbl and conf < 0.75:
                    conf = 0.75

                if conf >= MIN_CONFIDENCE_THRESHOLD:
                    candidates.append({
                        'entry': pk,
                        'conf': conf,
                        'name_sim': name_sim,
                        'overlap': overlap,
                    })

            # Sort by confidence, keep top 3 candidates
            candidates.sort(key=lambda x: x['conf'], reverse=True)
            for cand in candidates[:3]:
                pk = cand['entry']
                d = MappingDecision(
                    source_table=raw_meta.table_name,
                    source_column=col_meta.name,
                    target_table=pk['table'],
                    target_column=pk['col'],
                    confidence=round(cand['conf'], 3),
                    method=MappingMethod.FUZZY,
                    join_type=JoinType.MANY_TO_ONE,
                    string_similarity=round(cand['name_sim'], 3),
                    value_overlap=round(cand['overlap'], 3),
                    user_confirmed=False,
                )
                decisions.append(d)

    return decisions


# ── Pass 3: AI ─────────────────────────────────────────────────────────────

def _call_claude(prompt: str, retries: int = 3, max_tokens: int = 4096) -> Optional[str]:
    """Call Claude API via raw HTTP. Returns text content or None."""
    if not ANTHROPIC_API_KEY:
        logger.warning("ANTHROPIC_API_KEY not set — AI pass skipped")
        return None

    headers = {
        "x-api-key": ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01",
        "content-type": "application/json",
    }
    payload = {
        "model": CLAUDE_MODEL,
        "max_tokens": max_tokens,
        "messages": [{"role": "user", "content": prompt}],
    }

    for attempt in range(retries):
        try:
            resp = requests.post(
                "https://api.anthropic.com/v1/messages",
                headers=headers,
                json=payload,
                timeout=120,
            )
            if resp.status_code == 200:
                return resp.json()["content"][0]["text"]
            elif resp.status_code == 529:   # overloaded
                time.sleep(2 ** attempt)
            else:
                logger.error("Claude API error %s: %s",
                             resp.status_code, resp.text[:200])
                break
        except requests.RequestException as exc:
            logger.error("Claude API request failed: %s", exc)
            if attempt < retries - 1:
                time.sleep(2 ** attempt)

    return None


def pass3_ai(
    raw_files: list[tuple[FileMeta, pd.DataFrame]],
    map_files: list[tuple[FileMeta, pd.DataFrame]],
    already_mapped: set[tuple],
    project_context: str = "",
) -> list[MappingDecision]:
    """
    AI semantic inference for columns that remain unresolved after passes 1+2.
    All unresolved columns are batched into a single API call.
    """
    # Collect unresolved columns
    unresolved = []
    for raw_meta, raw_df in raw_files:
        for col_meta in raw_meta.columns:
            if any(k[0] == raw_meta.table_name and k[1] == col_meta.name
                   for k in already_mapped):
                continue
            if col_meta.is_pk_candidate:
                continue   # likely a PK itself, not an FK
            unresolved.append((raw_meta, col_meta, raw_df))

    if not unresolved:
        return []

    # Build PK candidate list for context
    pk_catalog = []
    for meta, df in map_files:
        for pk_col in dict.fromkeys(meta.pk_candidates + [c.name for c in meta.columns if re.search(r'(id|key|code)$', c.name, re.I)]):
            samples = df[pk_col].dropna().head(10).tolist()
            pk_catalog.append({
                "table": meta.table_name,
                "column": pk_col,
                "sample_values": [str(v) for v in samples],
            })

    # Build the prompt
    columns_json = json.dumps([
        {
            "source_table": raw_meta.table_name,
            "source_column": col.name,
            "dtype": col.dtype,
            "sample_values": [str(v) for v in col.sample_values[:10]],
            "null_pct": round(col.null_pct, 3),
        }
        for raw_meta, col, _ in unresolved
    ], indent=2)

    pk_json = json.dumps(pk_catalog, indent=2)

    prompt = f"""You are a data modelling expert. Your job is to determine which columns in
raw data tables should be joined (as foreign keys) to primary key columns in dimension tables.

Project context: {project_context or 'BI reporting project'}

UNRESOLVED RAW DATA COLUMNS (need FK mapping):
{columns_json}

AVAILABLE DIMENSION TABLE PRIMARY KEYS:
{pk_json}

For each unresolved column, determine if it is a foreign key to any of the dimension PKs.
Only include a mapping if you are genuinely confident. Do not force matches.

Return ONLY a JSON array, no explanation, no markdown:
[
  {{
    "source_table": "...",
    "source_column": "...",
    "matched_table": "...",      // null if no match
    "matched_column": "...",     // null if no match
    "confidence": 0.85,          // 0.0-1.0
    "reasoning": "brief reason"  // one sentence
  }},
  ...
]"""

    text = _call_claude(prompt)
    if not text:
        return []

    # Parse response
    try:
        # Strip any accidental markdown fences
        text = re.sub(r'```(?:json)?', '', text).strip()
        results = json.loads(text)
    except json.JSONDecodeError as exc:
        logger.error("Could not parse AI mapping response: %s", exc)
        return []

    decisions = []
    for item in results:
        if not item.get("matched_table") or not item.get("matched_column"):
            continue
        if (item.get("confidence") or 0) < MIN_CONFIDENCE_THRESHOLD:
            continue

        d = MappingDecision(
            source_table=item.get("source_table", ""),
            source_column=item.get("source_column", ""),
            target_table=item.get("matched_table", ""),
            target_column=item.get("matched_column", ""),
            confidence=round(float(item.get("confidence", 0)), 3),
            method=MappingMethod.AI_INFERRED,
            join_type=JoinType.MANY_TO_ONE,
            ai_reasoning=item.get("reasoning", ""),
            user_confirmed=False,
        )
        decisions.append(d)

    return decisions


# ── Fan-out check ──────────────────────────────────────────────────────────

def check_join_fanout(
    raw_df: pd.DataFrame,
    dim_df: pd.DataFrame,
    fk_col: str,
    pk_col: str,
    sample_size: int = 5000,
) -> tuple[bool, float]:
    """
    Dry-run a join on a sample. Returns (has_fanout, multiplier).
    A multiplier > 1.05 is considered fan-out.
    """
    sample = raw_df
    try:
        joined = sample.merge(
            dim_df[[pk_col]],
            left_on=fk_col, right_on=pk_col,
            how='left',
        )
        multiplier = len(joined) / len(sample) if len(sample) > 0 else 1.0
        return multiplier > 1.0, multiplier
    except Exception:
        return False, 1.0


def check_orphan_fks(
    raw_df: pd.DataFrame,
    dim_df: pd.DataFrame,
    fk_col: str,
    pk_col: str,
    numeric_measure_col: Optional[str] = None,
) -> Optional[DataError]:
    """
    Check for FK values in raw_df that don't exist in dim_df.
    Returns a DataError if orphans found, else None.
    """
    if fk_col not in raw_df.columns or pk_col not in dim_df.columns:
        return None

    dim_keys = set(dim_df[pk_col].astype(str).str.strip())
    orphan_mask = ~raw_df[fk_col].astype(str).str.strip().isin(dim_keys) & raw_df[fk_col].notna()
    orphan_count = int(orphan_mask.sum())

    if orphan_count == 0:
        return None

    pct = orphan_count / len(raw_df) if len(raw_df) > 0 else 0
    affected_value = 0.0
    if numeric_measure_col and numeric_measure_col in raw_df.columns:
        affected_value = float(raw_df.loc[orphan_mask, numeric_measure_col].sum())

    sample = raw_df[orphan_mask].head(5).to_dict('records')

    return DataError(
        category=ErrorCategory.REFERENTIAL_INTEGRITY,
        sub_type="ORPHAN_FK",
        severity=ErrorSeverity.HIGH,
        affected_table=str(raw_df.columns.name or 'raw_data'),
        affected_column=fk_col,
        affected_row_count=orphan_count,
        affected_measure_value=affected_value,
        detail=(
            f"{orphan_count} rows ({pct:.1%}) have {fk_col} values not found in "
            f"the joined dimension table. "
            + (f"Affected measure value: ${affected_value:,.0f}."
               if affected_value else "")
        ),
        sample_data=sample,
        options=[
            ResolutionOption('a', 'Exclude orphan rows',
                f'Remove {orphan_count} unmatched rows from model.',
                f'{orphan_count} rows excluded'
                + (f', ${affected_value:,.0f} from measures' if affected_value else ''),
                orphan_count, affected_value, True, False),
            ResolutionOption('c', 'Keep with NULL dimension values',
                'Orphan rows stay. Dimension columns will be NULL. Totals complete, breakdowns partial.',
                'No rows removed, partial breakdown', 0, 0.0, True, False),
            ResolutionOption('d', 'Stop — fix the dimension table',
                'Pause. Add missing keys to the dimension table and re-upload.',
                'Processing paused', 0, 0.0, False, False),
        ],
        recommended_option_id='c',
    )


# ── Circular relationship check ────────────────────────────────────────────

def check_circular_joins(decisions: list[MappingDecision]) -> list[list[str]]:
    """
    Detect cycles in the confirmed mapping graph.
    Returns list of cycles (each cycle is a list of table names).
    """
    # Build adjacency list: source_table -> target_tables
    graph: dict[str, set[str]] = {}
    for d in decisions:
        if not d.user_confirmed:
            continue
        graph.setdefault(d.source_table, set()).add(d.target_table)

    cycles = []
    visited = set()
    rec_stack = set()

    def dfs(node: str, path: list[str]):
        visited.add(node)
        rec_stack.add(node)
        path.append(node)
        for neighbour in graph.get(node, []):
            if neighbour not in visited:
                dfs(neighbour, path)
            elif neighbour in rec_stack:
                cycle_start = path.index(neighbour)
                cycles.append(path[cycle_start:] + [neighbour])
        path.pop()
        rec_stack.discard(node)

    for node in list(graph.keys()):
        if node not in visited:
            dfs(node, [])

    return cycles


# ── Main orchestrator ──────────────────────────────────────────────────────

def run_automapping(
    raw_files: list[tuple[FileMeta, pd.DataFrame]],
    map_files: list[tuple[FileMeta, pd.DataFrame]],
    project_context: str = "",
) -> tuple[list[MappingDecision], list[DataError]]:
    """
    Run all three passes. Returns (all_decisions, referential_errors).
    Decisions are split by confidence tier for the UI to present appropriately.
    """
    errors: list[DataError] = []

    # Pass 1
    p1 = pass1_exact(raw_files, map_files)
    logger.info("Pass 1 (exact): %d mappings", len(p1))

    mapped_keys = {
        (d.source_table, d.source_column, d.target_table, d.target_column)
        for d in p1
    }
    mapped_src = {(d.source_table, d.source_column) for d in p1}

    # Pass 2
    p2 = pass2_fuzzy(raw_files, map_files, mapped_keys)
    logger.info("Pass 2 (fuzzy): %d candidates", len(p2))

    # Add pass2 confirmed sources
    for d in p2:
        mapped_keys.add((d.source_table, d.source_column,
                         d.target_table, d.target_column))

    # Pass 3
    p3 = pass3_ai(raw_files, map_files, mapped_src, project_context)
    logger.info("Pass 3 (AI): %d candidates", len(p3))

    all_decisions = p1 + p2 + p3

    # Fan-out and orphan checks on confirmed pass-1 mappings
    raw_lookup = {m.table_name: df for m, df in raw_files}
    dim_lookup  = {m.table_name: df for m, df in map_files}

    for d in all_decisions:
        raw_df = raw_lookup.get(d.source_table)
        dim_df = dim_lookup.get(d.target_table)
        if raw_df is None or dim_df is None:
            continue

        # Fan-out
        has_fanout, multiplier = check_join_fanout(
            raw_df, dim_df, d.source_column, d.target_column
        )
        if has_fanout:
            from .file_processor import _check_duplicates
            errors.extend(e for e in _check_duplicates(dim_df, d.target_table, [d.target_column]) if e.sub_type == 'DUPLICATE_PK')

        # Orphan FKs
        numeric_cols = raw_df.select_dtypes(include='number').columns
        measure_col = None  # impact requires an approved business metric
        orphan_error = check_orphan_fks(
            raw_df, dim_df, d.source_column, d.target_column, measure_col
        )
        if orphan_error:
            orphan_error.affected_table = d.source_table
            errors.append(orphan_error)

    return all_decisions, errors

"""SQLite persistence using a restricted JSON codec, never unpickling projects."""
import base64
from collections.abc import MutableMapping
from contextlib import closing
from dataclasses import fields, is_dataclass
from datetime import datetime, date
from enum import Enum
import json
import sqlite3
import pandas as pd
import math
from . import models

TYPES = {name: cls for name, cls in vars(models).items()
         if isinstance(cls, type) and (is_dataclass(cls) or issubclass(cls, Enum))}

def encode(value):
    if value is pd.NaT or value is pd.NA:
        return None
    if isinstance(value, float) and not math.isfinite(value):
        return None
    if isinstance(value, Enum):
        return {'$enum': type(value).__name__, 'value': value.value}
    if is_dataclass(value):
        return {'$type': type(value).__name__, 'fields': {f.name: encode(getattr(value, f.name)) for f in fields(value)}}
    if isinstance(value, bytes):
        return {'$bytes': base64.b64encode(value).decode('ascii')}
    if isinstance(value, (datetime, date)):
        return {'$date': value.isoformat()}
    if isinstance(value, dict):
        return {'$dict': [[str(k), encode(v)] for k, v in value.items()]}
    if isinstance(value, (tuple, list)):
        return [encode(v) for v in value]
    if hasattr(value, 'item'):
        return encode(value.item())
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    return str(value)

def decode(value):
    if isinstance(value, list):
        return [decode(v) for v in value]
    if not isinstance(value, dict):
        return value
    if '$dict' in value:
        return {k: decode(v) for k, v in value['$dict']}
    if '$bytes' in value:
        return base64.b64decode(value['$bytes'])
    if '$date' in value:
        if value['$date'] == 'NaT':
            return None  # Recover projects saved by older versions with blank date samples.
        return datetime.fromisoformat(value['$date'])
    if '$enum' in value:
        return TYPES[value['$enum']](value['value'])
    if '$type' in value:
        return TYPES[value['$type']](**{k: decode(v) for k, v in value['fields'].items()})
    raise ValueError('Invalid saved project format.')

class ProjectStore(MutableMapping):
    def __init__(self, path):
        self.path = str(path)
        with closing(sqlite3.connect(self.path)) as conn, conn:
            conn.execute('CREATE TABLE IF NOT EXISTS projects (id TEXT PRIMARY KEY, body TEXT NOT NULL)')

    def __getitem__(self, key):
        with closing(sqlite3.connect(self.path)) as conn, conn:
            row = conn.execute('SELECT body FROM projects WHERE id=?', (key,)).fetchone()
        if row is None:
            raise KeyError(key)
        return decode(json.loads(row[0]))

    def __setitem__(self, key, value):
        body = json.dumps(encode(value))
        with closing(sqlite3.connect(self.path)) as conn, conn:
            conn.execute('INSERT OR REPLACE INTO projects VALUES (?, ?)', (key, body))

    def __delitem__(self, key):
        with closing(sqlite3.connect(self.path)) as conn, conn:
            result = conn.execute('DELETE FROM projects WHERE id=?', (key,))
            if not result.rowcount:
                raise KeyError(key)

    def __iter__(self):
        with closing(sqlite3.connect(self.path)) as conn, conn:
            rows = conn.execute('SELECT id FROM projects').fetchall()
        return iter([r[0] for r in rows])

    def __len__(self):
        with closing(sqlite3.connect(self.path)) as conn, conn:
            return conn.execute('SELECT COUNT(*) FROM projects').fetchone()[0]

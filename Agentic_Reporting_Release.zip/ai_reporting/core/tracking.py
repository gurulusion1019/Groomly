"""Durable metadata-only audit journal with idempotent SQL Server delivery."""
from contextlib import closing
from datetime import datetime, timezone
import json
import logging
import os
from pathlib import Path
import sqlite3
import threading
import uuid

log = logging.getLogger(__name__)


def utcnow():
    return datetime.now(timezone.utc).isoformat()


def sql_connection():
    import pyodbc
    def quoted(value):
        return '{' + value.replace('}', '}}') + '}'
    settings = [('DRIVER', os.getenv('TRACKING_SQL_DRIVER', 'ODBC Driver 17 for SQL Server')),
                ('SERVER', os.environ['TRACKING_SQL_SERVER']),
                ('DATABASE', os.getenv('TRACKING_SQL_DATABASE', 'AgenticReporting')),
                ('Encrypt', 'yes'),
                ('TrustServerCertificate', os.getenv('TRACKING_SQL_TRUST_CERTIFICATE', 'no'))]
    if os.getenv('TRACKING_SQL_AUTH', 'windows').lower() == 'windows':
        settings.append(('Trusted_Connection', 'yes'))
    elif os.getenv('TRACKING_SQL_AUTH', '').lower() == 'sql':
        settings.extend([('UID', os.environ['TRACKING_SQL_USER']), ('PWD', os.environ['TRACKING_SQL_PASSWORD'])])
    else:
        raise ValueError('TRACKING_SQL_AUTH must be windows or sql')
    return pyodbc.connect(';'.join(k + '=' + quoted(v) for k,v in settings), timeout=5)


class TrackingStore:
    def __init__(self, path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.boot_id = str(uuid.uuid4())
        self.sync_lock = threading.Lock()
        self.worker = None
        self.last_sync = None
        self.sync_error = None
        self.write_errors = 0
        with closing(self.connect()) as connection, connection:
            connection.execute('PRAGMA journal_mode=WAL')
            connection.execute('''CREATE TABLE IF NOT EXISTS tracking_events (
                sequence INTEGER PRIMARY KEY AUTOINCREMENT, event_id TEXT UNIQUE NOT NULL,
                request_id TEXT NOT NULL, owner_id TEXT NOT NULL, project_id TEXT,
                occurred_at TEXT NOT NULL, phase TEXT NOT NULL, payload TEXT NOT NULL,
                delivered INTEGER NOT NULL DEFAULT 0)''')
            connection.execute('CREATE INDEX IF NOT EXISTS tracking_owner ON tracking_events(owner_id, sequence)')

    def connect(self):
        return sqlite3.connect(self.path, timeout=10)

    def append(self, record):
        record = dict(record, event_id=str(uuid.uuid4()), occurred_at=utcnow(), boot_id=self.boot_id)
        with closing(self.connect()) as connection, connection:
            connection.execute('INSERT INTO tracking_events(event_id,request_id,owner_id,project_id,occurred_at,phase,payload) VALUES(?,?,?,?,?,?,?)',
                (record['event_id'], record['request_id'], record['owner_id'], record.get('project_id'),
                 record['occurred_at'], record['phase'], json.dumps(record, ensure_ascii=False)))
        return record

    def safe_append(self, record):
        try:
            return self.append(record)
        except Exception:
            self.write_errors += 1
            log.error('Tracking journal write failed; event metadata was not recorded.')

    def records(self, owner_id):
        with closing(self.connect()) as connection:
            return [json.loads(row[0]) for row in connection.execute(
                'SELECT payload FROM tracking_events WHERE owner_id=? ORDER BY sequence', (owner_id,))]

    def history(self, owner_id, project_id=None, offset=0, limit=50):
        latest = {}
        for record in self.records(owner_id):
            if project_id and record.get('project_id') != project_id:
                continue
            latest[record['request_id']] = record
        runs = list(latest.values())
        finished = [r for r in runs if r['phase'] == 'Finished']
        projects = {}
        for record in runs:
            if record.get('project_id') and record.get('project_name'):
                projects[record['project_id']] = record
        uploads = [r for r in finished if r.get('file_name') and r['outcome'] == 'Succeeded']
        totals = dict(actions=len(runs), failed=sum(r['outcome'] in ('Failed','Blocked','Interrupted') for r in runs),
                      upload_events=len(uploads), raw_uploads=sum(r.get('file_role')=='RAW_DATA' for r in uploads),
                      mapping_uploads=sum(r.get('file_role')=='MAPPING' for r in uploads),
                      protocol_uploads=sum(r.get('file_role')=='PROTOCOL' for r in uploads),
                      processing_ms=sum(r.get('elapsed_ms',0) for r in finished),
                      projects=len(projects), completed_projects=sum(r.get('state_after')=='COMPLETE' for r in projects.values()))
        with closing(self.connect()) as connection:
            pending = connection.execute('SELECT COUNT(*) FROM tracking_events WHERE owner_id=? AND delivered=0',(owner_id,)).fetchone()[0]
        return dict(totals=totals, runs=list(reversed(runs))[offset:offset+limit], offset=offset, limit=limit,
                    total=len(runs), projects=list(projects.values()),
                    identity='Browser session; shared-password access is not a named employee account.',
                    sql_enabled=os.getenv('TRACKING_SQL_ENABLED','false').lower()=='true',
                    pending_events=pending, last_sync=self.last_sync, sync_error=self.sync_error,
                    journal_write_errors=self.write_errors)

    def recover_interrupted(self):
        with closing(self.connect()) as connection:
            rows = connection.execute('SELECT payload FROM tracking_events ORDER BY sequence').fetchall()
        latest = {}
        for row in rows:
            record = json.loads(row[0]); latest[record['request_id']] = record
        for record in latest.values():
            if record['phase'] == 'Started' and record.get('boot_id') != self.boot_id:
                self.append(dict(record, phase='Finished', outcome='Interrupted',
                                 detail='Server restarted before completion was recorded.', elapsed_ms=0))

    def flush(self, connector=sql_connection):
        if not self.sync_lock.acquire(blocking=False):
            return 0
        try:
            with closing(self.connect()) as local:
                rows = local.execute('SELECT event_id,payload FROM tracking_events WHERE delivered=0 ORDER BY sequence LIMIT 200').fetchall()
            if not rows:
                return 0
            with closing(connector()) as remote:
                remote.timeout = 15
                cursor = remote.cursor()
                for event_id, payload in rows:
                    r = json.loads(payload)
                    cursor.execute('''IF NOT EXISTS (SELECT 1 FROM reporting.Events WITH (UPDLOCK,HOLDLOCK) WHERE event_id=?)
                        INSERT reporting.Events(event_id,request_id,owner_id,project_id,occurred_at,phase,operation,outcome,payload)
                        VALUES(?,?,?,?,?,?,?,?,?)''',
                        event_id, event_id,r['request_id'],r['owner_id'],r.get('project_id'),
                        datetime.fromisoformat(r['occurred_at']).replace(tzinfo=None),r['phase'],r['operation'],r['outcome'],payload)
                remote.commit()
            with closing(self.connect()) as local, local:
                local.executemany('UPDATE tracking_events SET delivered=1 WHERE event_id=?',[(r[0],) for r in rows])
            self.last_sync = utcnow(); self.sync_error = None
            return len(rows)
        except Exception as exc:
            # Do not expose ODBC connection strings, SQL credentials or private payloads.
            self.sync_error = 'SQL Server sync unavailable; events remain queued locally.'
            log.warning('Tracking sync unavailable (%s)', type(exc).__name__)
            return 0
        finally:
            self.sync_lock.release()

    def start_worker(self):
        if self.worker or os.getenv('TRACKING_SQL_ENABLED','false').lower() != 'true':
            return
        def work():
            stop = threading.Event()
            while True:
                self.flush()
                stop.wait(10)
        self.worker = threading.Thread(target=work, name='tracking-sync', daemon=True)
        self.worker.start()

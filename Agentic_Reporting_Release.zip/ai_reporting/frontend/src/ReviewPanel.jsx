import React, { useEffect, useState } from 'react';
import { API, apiFetch } from './api';

function MeasureEditor({ measure, tables, save, busy, onDraft, pending }) {
  const draft = pending || measure;
  const change = (key, value) => onDraft({...draft, [key]:value});
  const fields = tables.find(t=>t.table === draft.base_table)?.columns || [];
  const saveChanges = () => {
    const changes = {};
    for (const key of ['display_name','description','base_table','base_column','aggregation','format_string','dax_formula']) {
      if ((draft[key] || '') !== (measure[key] || '')) changes[key] = draft[key] || '';
    }
    save({kind:'measure',id:measure.measure_id,changes});
  };
  const control = {width:'100%', boxSizing:'border-box', padding:7, margin:'4px 0 10px'};
  const input = (key, label) => <label>{label}<input aria-label={label} style={control} value={draft[key] || ''} onChange={e=>change(key,e.target.value)}/></label>;
  return <details style={{padding:'9px 0', borderBottom:'1px solid #ddd'}}>
    <summary>{measure.display_name} {measure.needs_clarification ? '— needs clarification' : ''}</summary>
    <fieldset disabled={busy} style={{paddingTop:12,border:0,minWidth:0}}>
      {input('display_name','Measure name')}{input('description','Business definition')}
      <label>Source table<select aria-label="Source table" style={control} value={draft.base_table || ''} onChange={e=>change('base_table',e.target.value)}><option value="">Select table</option>{tables.map(t=><option key={t.table}>{t.table}</option>)}</select></label>
      <label>Source column<select aria-label="Source column" style={control} value={draft.base_column || ''} onChange={e=>change('base_column',e.target.value)}><option value="">Select column</option>{fields.map(c=><option key={c}>{c}</option>)}</select></label>
      <label>Calculation<select aria-label="Calculation" style={control} value={draft.aggregation} onChange={e=>change('aggregation',e.target.value)}>{['SUM','COUNT','COUNTD','AVG','MIN','MAX','RATIO','CUSTOM'].map(a=><option key={a}>{a}</option>)}</select></label>
      {input('format_string','Display format')}
      <label>DAX formula (leave empty to regenerate)<textarea aria-label="DAX formula" style={{...control,minHeight:85}} value={draft.dax_formula || ''} onChange={e=>change('dax_formula',e.target.value)}/></label>
      <p>Filters: {(draft.filter_conditions || []).map(f=>`${f.column} ${f.operator} ${String(f.value)}`).join('; ') || 'None'}</p>
      <button disabled={busy} onClick={saveChanges}>Save measure</button>
    </fieldset>
  </details>;
}

function MappingEditor({ mapping, tables, save, busy, onDraft, pending }) {
  const draft = pending || mapping;
  const table = draft.target_table, column = draft.target_column;
  const setTable = value => onDraft({...draft,target_table:value,target_column:tables.find(t=>t.table===value)?.columns[0] || ''});
  const setColumn = value => onDraft({...draft,target_column:value});
  return <details style={{padding:'8px 0'}}><summary>{mapping.source_table}.{mapping.source_column} → {mapping.target_table}.{mapping.target_column}</summary>
    <p>Measured/proposed overlap: {Math.round(mapping.value_overlap * 100)}%. Confirm that both fields identify the same business entity.</p>
    <fieldset disabled={busy} style={{border:0,minWidth:0}}>
    <label>Lookup table<select aria-label="Lookup table" value={table} onChange={e=>setTable(e.target.value)}>{tables.map(t=><option key={t.table}>{t.table}</option>)}</select></label>
    <label>Lookup key<select aria-label="Lookup key" value={column} onChange={e=>setColumn(e.target.value)}>{(tables.find(t=>t.table===table)?.columns || []).map(c=><option key={c}>{c}</option>)}</select></label>
    <button disabled={busy} onClick={()=>save({kind:'mapping',id:mapping.decision_id,changes:{target_table:table,target_column:column}})}>Save relationship</button>
    <button disabled={busy} onClick={()=>save({kind:'mapping',id:mapping.decision_id,reject:true})}>Reject relationship</button>
    </fieldset>
  </details>;
}

export default function ReviewPanel({ sessionId, version, onSaved, busy, onPendingChange }) {
  const [data,setData] = useState(null);
  const [error,setError] = useState('');
  const [saving,setSaving] = useState(false);
  const [drafts,setDrafts] = useState({});
  const [notice,setNotice] = useState('');
  useEffect(()=>{
    const measureFields=['display_name','description','base_table','base_column','aggregation','format_string','dax_formula'];
    const pending=(data?.measures || []).some(m=>drafts[m.measure_id] && measureFields.some(k=>(drafts[m.measure_id][k]||'')!==(m[k]||''))) ||
      (data?.mappings || []).some(m=>drafts[m.decision_id] && ['target_table','target_column'].some(k=>drafts[m.decision_id][k]!==m[k]));
    onPendingChange?.(saving || pending);
  },[drafts,data,saving,onPendingChange]);
  useEffect(()=>{setDrafts({});setNotice('');},[sessionId]);
  useEffect(()=>{ apiFetch(`${API}/review/${sessionId}`).then(setData).catch(e=>setError(e.message)); },[sessionId,version]);
  async function save(payload) {
    if (!payload.reject && !Object.keys(payload.changes || {}).length) {
      setError(''); setNotice('Already saved. Select Review complete — confirm all in Next steps, then Build / retry report.'); return;
    }
    setSaving(true); setError(''); setNotice('');
    try {
      const result=await apiFetch(`${API}/review/${sessionId}`,{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});
      setDrafts(old=>{const next={...old};delete next[payload.id];return next;});
      onSaved(result); setData(await apiFetch(`${API}/review/${sessionId}`));
      setNotice('Saved. Select Review complete — confirm all in Next steps, then Build / retry report.');
    } catch(e){setError(e.message);} finally{setSaving(false);}
  }
  async function saveAll(kind = 'all') {
    if (!data) return;
    const payloads=[];
    for (const m of data.measures) {
      if (kind === 'mapping') continue;
      const d=drafts[m.measure_id]; if (!d) continue;
      const changes={};
      for (const key of ['display_name','description','base_table','base_column','aggregation','format_string','dax_formula']) if ((d[key]||'') !== (m[key]||'')) changes[key]=d[key]||'';
      if (Object.keys(changes).length) payloads.push({kind:'measure',id:m.measure_id,changes});
    }
    for (const m of data.mappings) {
      if (kind === 'measure') continue;
      const d=drafts[m.decision_id];
      if (d && (d.target_table!==m.target_table || d.target_column!==m.target_column)) payloads.push({kind:'mapping',id:m.decision_id,changes:{target_table:d.target_table,target_column:d.target_column}});
    }
    if (!payloads.length) { setError(''); setNotice('All current definitions are already saved. Select Review complete — confirm all in Next steps, then Build / retry report.'); return; }
    setSaving(true); setError(''); setNotice('');
    try { let result;
      for (const payload of payloads) {
        result=await apiFetch(`${API}/review/${sessionId}`,{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});
        setDrafts(old=>{const next={...old};delete next[payload.id];return next;});
      }
      onSaved(result); setData(await apiFetch(`${API}/review/${sessionId}`));
      setNotice(`Saved ${payloads.length} changed definitions. Select Review complete — confirm all in Next steps, then Build / retry report.`);
    }
    catch(e){setError(e.message);} finally{setSaving(false);}
  }
  if (!data) return error ? <p role="alert">{error}</p> : null;
  return <>
  <div style={{display:'flex',flexWrap:'wrap',gap:6,marginTop:12}}>
    <button disabled={busy||saving} onClick={()=>saveAll()} style={{padding:'9px 14px',fontWeight:600}}>Save all measures &amp; relationships</button>
    <button disabled={busy||saving} onClick={()=>saveAll('measure')}>Save all measures</button>
    <button disabled={busy||saving} onClick={()=>saveAll('mapping')}>Save all relationships</button>
  </div>
  {notice && <p role="status">{notice}</p>}
  {error && <p role="alert" style={{color:'#a00'}}>Save failed: {error}. Any unsaved edits remain available; retry saving.</p>}
  <details style={{padding:12, margin:'6px 0 12px', border:'1px solid #ddd', borderRadius:8, fontSize:12}}>
    <summary>Review and edit definitions</summary>
    <p>Saving changes clears previous exports. Review, confirm, and rebuild to produce updated downloads.</p>
    <h3>Measures</h3>{data.measures.map(m=><MeasureEditor key={m.measure_id} measure={m} pending={drafts[m.measure_id]} tables={data.tables} save={save} onDraft={d=>setDrafts(x=>({...x,[m.measure_id]:d}))} busy={busy||saving}/>)}
    <h3>Relationships</h3>{data.mappings.map(m=><MappingEditor key={m.decision_id} mapping={m} pending={drafts[m.decision_id]} tables={data.tables} save={save} onDraft={d=>setDrafts(x=>({...x,[m.decision_id]:d}))} busy={busy||saving}/>)}
  </details></>;
}

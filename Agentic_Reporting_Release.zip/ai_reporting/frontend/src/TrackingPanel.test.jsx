import React from 'react';
import {render,screen,fireEvent} from '@testing-library/react';
import TrackingPanel from './TrackingPanel';

test('history loads only on request and labels session identity and queued delivery',async()=>{
  global.fetch=jest.fn().mockResolvedValue({ok:true,json:async()=>({totals:{projects:1,completed_projects:0,upload_events:2,raw_uploads:1,mapping_uploads:1,protocol_uploads:0,failed:1,processing_ms:1234},sql_enabled:true,pending_events:2,runs:[],offset:0,limit:50,total:0})});
  render(<TrackingPanel projectId="project-1"/>);
  expect(fetch).not.toHaveBeenCalled();
  fireEvent.click(screen.getByRole('button',{name:'Processing & login history'}));
  expect(await screen.findByText(/Uploads accepted: 2/)).toBeInTheDocument();
  expect(screen.getByText(/Employee identities are not verified/)).toBeInTheDocument();
  expect(screen.getByText(/Queued events: 2/)).toBeInTheDocument();
  expect(fetch.mock.calls[0][0]).toContain('project_id=project-1');
});

import React from 'react';
import TrackingPanel from './TrackingPanel';
import './LandingPage.css';

function Icon({kind = 0}) {
  const paths = ['M12 16V3m-5 5 5-5 5 5M4 15v5h16v-5', 'M4 6c0-4 16-4 16 0s-16 4-16 0m0 0v12c0 4 16 4 16 0V6M4 12c0 4 16 4 16 0', 'M6 3h8l4 4v14H6V3m8 0v5h4M9 12h6m-6 4h6', 'M5 20V10m7 10V4m7 16v-7'];
  return <svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><path d={paths[kind % 4]}/></svg>;
}

export default function LandingPage({projectName, setProjectName, loading, startProject, pageError, savedProjects, openProject, deleteProject, facts, steps}) {
  return <main className="reporting-landing">
    <div className="landing-shell">
      <header className="landing-brand">ACCENTURE <span>›</span> SYNOPS <span className="landing-brand-note">Your reporting workspace</span></header>
      <div className="landing-grid">
        <section className="landing-primary" aria-label="Project workspace">
          <div className="landing-hero">
            <div className="landing-hero-copy"><h1>Agentic <span>Reporting</span></h1>
              <p className="landing-tagline">Describe the dashboard. Get the Power BI file.</p>
              <p className="landing-description">Upload your data and a plain-English protocol. The agent extracts your measures, writes the DAX, plans the visuals and hands back a ready-to-open <code>.pbip</code> project.</p>
            </div>
            <div className="landing-art" aria-hidden="true">
              <div className="art-chart art-back"><span/><svg viewBox="0 0 120 60"><path d="M5 52 28 38 48 43 70 21 92 28 115 6" fill="none" stroke="#51d5ff" strokeWidth="3"/></svg></div>
              <div className="art-chart art-front"><span/><div className="art-bars"><i/><i/><i/><i/><i/></div></div>
              <div className="art-orbit"/>
            </div>
          </div>
          <form className="landing-create" onSubmit={e => {e.preventDefault(); startProject();}}>
            <label htmlFor="projectName">Project name</label>
            <div className="landing-input-row"><input id="projectName" value={projectName} onChange={e=>setProjectName(e.target.value)} placeholder="Q2 Sales Performance" autoComplete="off" maxLength={200}/>
              <button className="landing-cta" disabled={loading || !projectName.trim()} type="submit">{loading ? 'Creating…' : 'Create project'} <span aria-hidden="true">→</span></button></div>
            {pageError && <p role="alert" className="landing-error">{pageError}</p>}
          </form>
          <section className="landing-projects" aria-label="Saved projects"><div className="landing-section-title"><h2>Saved projects</h2><span>{savedProjects.length} {savedProjects.length === 1 ? 'project' : 'projects'}</span></div>
            {savedProjects.length === 0 ? <p className="landing-empty">Your projects will appear here. Create your first project above to get started.</p> : <div className="landing-project-list">{savedProjects.map(p => <div className="landing-project-row" key={p.session_id}>
              <Icon kind={2}/><div className="landing-project-name"><strong>{p.project_name || 'Untitled project'}</strong><small>{p.last_updated && !Number.isNaN(Date.parse(p.last_updated)) ? `Updated ${new Date(p.last_updated).toLocaleString()}` : `Project ${p.session_id.slice(0,8)}`}</small></div>
              <span className={`landing-badge ${p.state === 'COMPLETE' ? 'is-complete' : ''}`}>{p.state.replace(/_/g,' ')}</span>
              <button disabled={loading} aria-label={`Open ${p.project_name || 'Untitled project'}`} onClick={()=>openProject(p.session_id)}>Open <span aria-hidden="true">↗</span></button>
              <button className="landing-delete" disabled={loading} aria-label={`Delete ${p.project_name}`} title="Delete project" onClick={()=>deleteProject(p)}><svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><path d="M4 6h16M9 6V3h6v3M6 6l1 15h10l1-15M10 10v7m4-7v7"/></svg></button>
            </div>)}</div>}
          </section>
          <div className="landing-history"><TrackingPanel/></div>
          <dl className="landing-facts">{facts.map((f,i)=><div key={f.k} className="landing-fact"><Icon kind={i+1}/><dt>{f.k}</dt><dd>{f.v}</dd></div>)}</dl>
        </section>
        <aside className="landing-how" aria-label="How it works"><h2>How it works</h2><ol>{steps.map((s,i)=><li key={s.n}><span className="landing-step-number">{s.n}</span><div className="landing-step-card"><div className="landing-step-icon"><Icon kind={i}/></div><div><h3>{s.title}</h3><p>{s.body}</p></div></div></li>)}</ol>
          <div className="landing-tip"><span aria-hidden="true">✦</span><p><strong>Tip</strong>No protocol document? Say <b>generate</b> and the agent will propose measures from your data for you to approve.</p></div>
        </aside>
      </div>
    </div>
  </main>;
}

import React, {useState} from 'react';
import {API, apiFetch} from './api';

export default function TrackingPanel({projectId}) {
  const [open,setOpen]=useState(false), [data,setData]=useState(null);
  const [busy,setBusy]=useState(false), [error,setError]=useState('');
  async function load(offset=0) {
    setBusy(true);setError('');
    try { setData(await apiFetch(`${API}/tracking?offset=${offset}${projectId?`&project_id=${encodeURIComponent(projectId)}`:''}`)); }
    catch(e) {setError(e.message);} finally {setBusy(false);}
  }
  return <section aria-label="Processing history" style={{background:'#fff',color:'#1B1526',padding:12,border:'1px solid #ddd',borderRadius:8,flexShrink:0}}>
    <button disabled={busy} onClick={()=>{setOpen(!open);if(!open) load();}}>{open?'Close history':'Processing & login history'}</button>
    {open && <div>
      <p>History for this browser session{projectId?' and project':''}. Employee identities are not verified by shared-password sign-in.</p>
      <button disabled={busy} onClick={()=>load(data?.offset || 0)}>{busy?'Loading…':'Refresh history'}</button>
      {error && <p role="alert">{error}</p>}
      {data && <>
        <p>Projects: {data.totals.projects} · Completed: {data.totals.completed_projects}<br/>
        Uploads accepted: {data.totals.upload_events} (raw {data.totals.raw_uploads}, mapping {data.totals.mapping_uploads}, protocol {data.totals.protocol_uploads})<br/>
        Failed / blocked / interrupted: {data.totals.failed}<br/>Processing: {(data.totals.processing_ms/1000).toFixed(2)} seconds</p>
        <p>SQL tracking: {data.sql_enabled?'Enabled':'Not enabled'} · Queued events: {data.pending_events}<br/>
        Last sync: {data.last_sync?new Date(data.last_sync).toLocaleString():'Not recorded in this server session'}</p>
        {data.sync_error && <p role="status">{data.sync_error}</p>}
        {data.journal_write_errors>0 && <p role="alert">Some tracking records could not be saved. Contact the application administrator.</p>}
        <p>Uploads include replacements. Active file counts are recorded per action. Waiting time is the gap between user-driven workflow requests, including time away from the app. Processing time covers each server action, not individual AI calls. Download events mean the server returned a file, not proof the browser saved it.</p>
        {data.runs.length===0 && <p>No history recorded yet. Earlier activity is not reconstructed.</p>}
        {data.runs.map(r=><details key={r.request_id} style={{borderTop:'1px solid #ddd',padding:'8px 0'}}>
          <summary>{r.project_name || 'Access'} · {r.operation} · {r.outcome}</summary>
          <p>{new Date(r.started_at || r.occurred_at).toLocaleString()}<br/>Session: {r.owner_id}<br/>{r.identity_type}</p>
          <p>Processing: {((r.elapsed_ms || 0)/1000).toFixed(2)} s · Waiting before: {((r.waiting_ms || 0)/1000).toFixed(1)} s<br/>
          State: {r.state_before || '—'} → {r.state_after || '—'}</p>
          {r.file_name && <p>{r.file_name} · {r.file_role} · {r.file_bytes || 0} bytes{r.replacement?' · replacement':''}</p>}
          {r.raw_files!==undefined && <p>Active files: {r.raw_files} raw / {r.mapping_files} mapping / {r.protocol_files} protocol<br/>
          Fact rows included: {r.rows_included}; excluded: {r.rows_excluded}; quarantined: {r.rows_quarantined}<br/>
          Available outputs: {(r.exports || []).join(', ') || 'None'}</p>}
          {r.detail && <p>{r.detail}</p>}
        </details>)}
        <button disabled={busy || data.offset===0} onClick={()=>load(Math.max(0,data.offset-data.limit))}>Newer</button>
        <button disabled={busy || data.offset+data.limit>=data.total} onClick={()=>load(data.offset+data.limit)}>Older</button>
      </>}
    </div>}
  </section>;
}

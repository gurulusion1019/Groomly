import React, { useEffect, useState } from 'react';
import { API, apiFetch } from './api';

export default function AuthGate({ children }) {
  const [auth, setAuth] = useState(null);
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  useEffect(() => { apiFetch(`${API}/auth`).then(setAuth).catch(e => setError(e.message)); }, []);
  async function login(e) {
    e.preventDefault(); setBusy(true); setError('');
    try {
      await apiFetch(`${API}/login`, { method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({password}) });
      setAuth(await apiFetch(`${API}/auth`)); setPassword('');
    } catch(e) { setError(e.message); }
    finally { setBusy(false); }
  }
  if (!auth || auth.login_required) return <main style={{padding:48, maxWidth:440, margin:'auto', fontFamily:'Segoe UI, sans-serif'}}>
    <h1>Agentic Reporting</h1>
    {!auth ? <p>{error || 'Connecting to the server…'}</p> : <form onSubmit={login}>
      <label htmlFor="password">Application password</label>
      <input id="password" type="password" autoComplete="current-password" value={password} onChange={e=>setPassword(e.target.value)} style={{display:'block', padding:12, margin:'12px 0', width:'100%'}}/>
      <button disabled={busy}>{busy ? 'Signing in…' : 'Sign in'}</button>
      {error && <p role="alert">{error}</p>}
    </form>}
  </main>;
  return <>{auth.authenticated && <div style={{padding:'6px 18px'}}><span>Shared-password session </span><button onClick={async()=>{try{await apiFetch(`${API}/logout`,{method:'POST'});setAuth(await apiFetch(`${API}/auth`));}catch(e){setError(e.message);}}}>Sign out</button>{error && <span role="alert">{error}</span>}</div>}{!auth.ai_configured && <div role="status" style={{padding:'8px 18px', background:'#fff0c2', fontSize:12}}>
    AI provider is not configured. Use “generate” for basic data-based suggestions. Protocol extraction requires a server API key.
  </div>}{children}</>;
}

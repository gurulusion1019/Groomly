import React, {useState} from 'react';

export default function WorkflowPanel({context={},state,busy,onAction}) {
  const [answers,setAnswers]=useState({});
  const questions=context.clarification_questions || [];
  const checks=context.validation || [];
  const failures=checks.filter(v=>v.status==='Failed');
  const warnings=checks.filter(v=>['Warning','Needs clarification','Not checked'].includes(v.status));
  const pending=context.pending_issues || [];
  const rows=context.data_summary;
  const button=(label,message)=><button disabled={busy} onClick={()=>onAction(message)}>{label}</button>;
  return <section aria-label="Next steps" style={{padding:12,border:'1px solid #ddd',borderRadius:8,marginBottom:12,fontSize:12}}>
    <h3>Next steps</h3>
    <div style={{display:'flex',gap:8,flexWrap:'wrap'}}>
      {['RAW_DATA','MAPPING_FILES'].includes(state) && button('Uploads complete','done')}
      {state==='MAPPING_REVIEW' && button('Review complete — confirm all','confirm all')}
      {state==='MODEL_BUILD' && button('Build / retry report','build')}
      {state==='EXPORT' && button('Generate all downloads','all')}
      {state==='COMPLETE' && <p>{context.exports_available?.length ? 'Open Downloads & completion report at the top of this panel.' : 'No stored downloads are available. Check the download panel and latest build status.'}</p>}
    </div>
    {state==='MAPPING_REVIEW' && <p>Save any edits first, then confirm the reviewed definitions.</p>}
    {state==='CLARIFY' && questions.length>0 && <form onSubmit={e=>{
      e.preventDefault();
      const message=questions.filter(q=>answers[q.measure_id]?.trim()).map(q=>`${q.number}: ${answers[q.measure_id].trim()}`).join('\n');
      if (message) onAction(message);
    }}>
      <h4>Answer questions together</h4>
      <p>Specify the intended calculation or choice. You can submit some answers and finish the rest later.</p>
      <fieldset disabled={busy} style={{border:0,padding:0,minWidth:0}}>
        {questions.map(q=><div key={q.measure_id} style={{marginBottom:12}}>
          <strong>{q.number}. {q.name}</strong>
          {q.questions.map((text,i)=><p key={i}>{text}</p>)}
          <label>Answer for {q.name}<textarea aria-label={`Answer for ${q.name}`} value={answers[q.measure_id] || ''} onChange={e=>setAnswers({...answers,[q.measure_id]:e.target.value})} style={{width:'100%',boxSizing:'border-box',minHeight:65}}/></label>
        </div>)}
        <button disabled={!questions.some(q=>answers[q.measure_id]?.trim())} type="submit">Submit answers together</button>
      </fieldset>
    </form>}
    {state==='ERROR_REVIEW' && pending.length>0 && <div>
      <h4>Choose how to handle this issue</h4><p>{pending[0].detail}</p>
      <div style={{display:'flex',gap:6,flexWrap:'wrap'}}>{pending[0].options.map(o=><React.Fragment key={o.id}>{button(o.label,o.id)}</React.Fragment>)}</div>
    </div>}
    {rows && <p>Fact rows included: <strong>{rows.rows_included}</strong><br/>Excluded: {rows.rows_excluded} · Quarantined: {rows.rows_quarantined}</p>}
    <p>Open data issues: {context.errors_pending || 0} · Definition checks needing attention: {failures.length}</p>
    {failures.length>0 && <details><summary>Definitions needing attention</summary>{failures.map((v,i)=><p key={i}><strong>{v.scope}</strong>: {v.detail}</p>)}</details>}
    {failures.length>0 && <p>Resolve the listed definitions in Review and edit definitions, save your edits, then confirm the review before building again.</p>}
    <p>Warnings or checks still to review: {warnings.length}</p>
    {warnings.length>0 && <details open><summary>Warnings and unchecked results</summary>{warnings.map((v,i)=><p key={i}><strong>{v.scope} ({v.status})</strong>: {v.detail}</p>)}</details>}
    <p>Power BI refresh and calculated values require verification in Power BI Desktop.</p>
  </section>;
}

import React from 'react';
import {render, screen, fireEvent, waitFor} from '@testing-library/react';
import RootApp, {App} from './App';
import ReviewPanel from './ReviewPanel';
import {apiFetch} from './api';

beforeEach(()=> { global.fetch=jest.fn(); });
const reply=(body,ok=true,status=200)=>Promise.resolve({ok,status,json:async()=>body});

test('unchanged save-all gives visible feedback without invalidating exports',async()=>{
  fetch.mockImplementation(()=>reply({tables:[],measures:[],mappings:[]}));
  render(<ReviewPanel sessionId="existing" onSaved={jest.fn()}/>);
  fireEvent.click(await screen.findByRole('button',{name:'Save all measures & relationships'}));
  expect(await screen.findByRole('status')).toHaveTextContent('already saved');
  expect(fetch.mock.calls.filter(([,o])=>o?.method==='PATCH')).toHaveLength(0);
});

test('saving measures preserves pending relationship edits for the next save',async()=>{
  const data={tables:[{table:'dim',columns:['id','code']}],measures:[{measure_id:'m',display_name:'Revenue',aggregation:'SUM'}],mappings:[{decision_id:'r',source_table:'sales',source_column:'id',target_table:'dim',target_column:'id',value_overlap:1}]};
  fetch.mockImplementation((url,opts)=>reply(opts?.method==='PATCH'?{reply:'Saved'}:data));
  render(<ReviewPanel sessionId="existing" onSaved={jest.fn()}/>);
  fireEvent.change(await screen.findByLabelText('Measure name'),{target:{value:'New revenue'}});
  fireEvent.change(screen.getByLabelText('Lookup key'),{target:{value:'code'}});
  fireEvent.click(screen.getByRole('button',{name:'Save all measures',exact:true}));
  await waitFor(()=>expect(screen.getByRole('status')).toHaveTextContent('Saved 1'));
  expect(screen.getByLabelText('Lookup key')).toHaveValue('code');
  fireEvent.click(screen.getByRole('button',{name:'Save all relationships',exact:true}));
  await waitFor(()=>expect(fetch.mock.calls.filter(([,o])=>o?.method==='PATCH')).toHaveLength(2));
  const updates=fetch.mock.calls.filter(([,o])=>o?.method==='PATCH').map(([,o])=>JSON.parse(o.body));
  expect(updates.map(u=>u.kind)).toEqual(['measure','mapping']);
  expect(updates[1].changes.target_column).toBe('code');
});

test('shows offline mode and saved project controls',async()=>{
  fetch.mockImplementation(url=>reply(url.endsWith('/auth')?{login_required:false,ai_configured:false}:{sessions:[{session_id:'existing',project_name:'Saved report',state:'COMPLETE'}]}));
  render(<RootApp/>);
  expect(await screen.findByText(/AI provider is not configured/)).toBeInTheDocument();
  expect(await screen.findByRole('button',{name:/Saved report ·/})).toBeInTheDocument();
  expect(screen.getByLabelText('Project name')).toBeInTheDocument();
});

test('shows server errors instead of reporting success',async()=>{
  fetch.mockImplementation((url,options)=>reply(url.endsWith('/sessions')?{sessions:[]}:{error:'Cannot create project'},url.endsWith('/sessions'),500));
  render(<App/>);
  fireEvent.change(screen.getByLabelText('Project name'),{target:{value:'Example'}});
  fireEvent.click(screen.getByRole('button',{name:'Start'}));
  expect(await screen.findByRole('alert')).toHaveTextContent('Cannot create project');
});

test('chat markup escapes injected HTML',async()=>{
  fetch.mockImplementation(url=>{
    if(url.endsWith('/sessions')) return reply({sessions:[{session_id:'existing',project_name:'Saved',state:'RAW_DATA'}]});
    return reply({project_name:'Saved',state:'RAW_DATA',raw_files:[],mapping_files:[],chat_history:[{role:'assistant',content:'<img src=x onerror=alert(1)> **Safe bold**'}],exports_available:[]});
  });
  const {container}=render(<App/>);
  fireEvent.click(await screen.findByRole('button',{name:/Saved ·/}));
  expect(await screen.findByText(/<img src=x/)).toBeInTheDocument();
  expect(container.querySelector('img[src="x"]')).toBeNull();
  expect(screen.getByText('Safe bold').tagName).toBe('STRONG');
});

test('only generated downloads are shown',async()=>{
  fetch.mockImplementation(url=>url.endsWith('/sessions')?reply({sessions:[{session_id:'existing',project_name:'Saved',state:'COMPLETE'}]}):reply({project_name:'Saved',state:'COMPLETE',raw_files:[],mapping_files:[],chat_history:[],exports_available:['excel']}));
  render(<App/>);
  fireEvent.click(await screen.findByRole('button',{name:/Saved ·/}));
  expect(await screen.findByRole('link',{name:/Excel workbook/})).toBeInTheDocument();
  expect(screen.queryByRole('link',{name:/Power BI package/})).toBeNull();
});

test('login errors are visible',async()=>{
  fetch.mockImplementation(url=>reply(url.endsWith('/auth')?{login_required:true}:{error:'Incorrect password'},url.endsWith('/auth'),401));
  render(<RootApp/>);
  fireEvent.change(await screen.findByLabelText('Application password'),{target:{value:'wrong'}});
  fireEvent.click(screen.getByRole('button',{name:'Sign in'}));
  expect(await screen.findByRole('alert')).toHaveTextContent('Incorrect password');
});

test('unreadable server response produces an actionable error',async()=>{
  fetch.mockResolvedValue({ok:false,status:502,json:async()=>{throw new Error('HTML');}});
  await expect(apiFetch('/api/session')).rejects.toThrow('502');
});

test('measure editor submits a real update',async()=>{
  const data={tables:[{table:'sales',columns:['amount']}],mappings:[],measures:[{measure_id:'m1',display_name:'Revenue',base_table:'sales',base_column:'amount',aggregation:'SUM',format_string:'#,##0',filter_conditions:[]}]};
  fetch.mockImplementation((url,opts)=>reply(opts?.method==='PATCH'?{state:'MAPPING_REVIEW',reply:'Saved'}:data));
  const saved=jest.fn();
  render(<ReviewPanel sessionId="existing" version="1" onSaved={saved}/>);
  const field=await screen.findByLabelText('Measure name');
  fireEvent.change(field,{target:{value:'Net revenue'}});
  fireEvent.click(screen.getByRole('button',{name:'Save measure',hidden:true}));
  await waitFor(()=>expect(saved).toHaveBeenCalled());
  const request=fetch.mock.calls.find(([,opts])=>opts?.method==='PATCH');
  expect(JSON.parse(request[1].body).changes.display_name).toBe('Net revenue');
});

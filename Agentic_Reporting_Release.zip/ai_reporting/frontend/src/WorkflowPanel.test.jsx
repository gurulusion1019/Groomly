import React from 'react';
import {render,screen,fireEvent} from '@testing-library/react';
import WorkflowPanel from './WorkflowPanel';

test.each([['MAPPING_REVIEW','Review complete — confirm all','confirm all'],['MODEL_BUILD','Build / retry report','build'],['EXPORT','Generate all downloads','all']])('action for %s uses existing workflow', (state,label,message)=>{
  const action=jest.fn(); render(<WorkflowPanel state={state} onAction={action}/>);
  fireEvent.click(screen.getByRole('button',{name:label})); expect(action).toHaveBeenCalledWith(message);
});

test('submits several answers together and keeps stable measure numbers',()=>{
  const action=jest.fn();
  render(<WorkflowPanel state="CLARIFY" onAction={action} context={{clarification_questions:[{measure_id:'a',number:2,name:'Rate',questions:['Lines or orders?']},{measure_id:'b',number:9,name:'Top',questions:['Name or value?']}]}}/>);
  fireEvent.change(screen.getByLabelText('Answer for Rate'),{target:{value:'Count lines'}});
  fireEvent.change(screen.getByLabelText('Answer for Top'),{target:{value:'Revenue value'}});
  fireEvent.click(screen.getByRole('button',{name:'Submit answers together'}));
  expect(action).toHaveBeenCalledWith('2: Count lines\n9: Revenue value');
});

test('busy prevents duplicate build actions and summary shows exclusions',()=>{
  render(<WorkflowPanel state="MODEL_BUILD" busy context={{data_summary:{rows_included:92,rows_excluded:8,rows_quarantined:0}}}/>);
  expect(screen.getByRole('button',{name:'Build / retry report'})).toBeDisabled();
  expect(screen.getByText(/Excluded: 8/)).toBeInTheDocument();
});

test('shows failed definitions and nonblocking warnings with recovery guidance',()=>{
  render(<WorkflowPanel state="MAPPING_REVIEW" context={{validation:[
    {status:'Failed',scope:'Revenue',detail:'Unknown source column: Amount'},
    {status:'Needs clarification',scope:'Returns',detail:'Filter matches no current rows.'},
    {status:'Passed',scope:'Orders',detail:'Fields exist.'}
  ]}}/>);
  expect(screen.getByText(/Definition checks needing attention: 1/)).toBeInTheDocument();
  expect(screen.getByText('Warnings or checks still to review: 1')).toBeInTheDocument();
  expect(screen.getByText(/Filter matches no current rows/)).toBeInTheDocument();
  expect(screen.getByText(/save your edits, then confirm the review/)).toBeInTheDocument();
});

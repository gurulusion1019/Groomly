"""One process, threaded Waitress server. Use a TLS proxy for remote access."""
from api.app import app, main

if __name__ == '__main__':
    main()

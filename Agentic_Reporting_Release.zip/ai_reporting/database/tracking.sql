-- Additive, repeatable migration. Run only in the dedicated application database.
IF SCHEMA_ID(N'reporting') IS NULL EXEC(N'CREATE SCHEMA reporting');
GO
IF OBJECT_ID(N'reporting.Events', N'U') IS NULL
BEGIN
 CREATE TABLE reporting.Events (
  event_id uniqueidentifier NOT NULL PRIMARY KEY,
  request_id uniqueidentifier NOT NULL,
  owner_id nvarchar(100) NOT NULL,
  project_id nvarchar(100) NULL,
  occurred_at datetime2(7) NOT NULL,
  phase nvarchar(20) NOT NULL,
  operation nvarchar(40) NOT NULL,
  outcome nvarchar(30) NOT NULL,
  payload nvarchar(max) NOT NULL CHECK (ISJSON(payload)=1)
 );
 CREATE INDEX IX_TrackingOwnerTime ON reporting.Events(owner_id,occurred_at);
 CREATE INDEX IX_TrackingRequest ON reporting.Events(request_id,occurred_at);
END;
GO
CREATE OR ALTER VIEW reporting.ProcessingRuns AS
WITH latest AS (
 SELECT *, ROW_NUMBER() OVER(PARTITION BY request_id ORDER BY CASE WHEN phase='Finished' THEN 1 ELSE 0 END DESC, occurred_at DESC) AS n
 FROM reporting.Events
)
SELECT request_id, owner_id, project_id, occurred_at, operation, outcome,
 JSON_VALUE(payload,'$.project_name') AS project_name,
 JSON_VALUE(payload,'$.identity_type') AS identity_type,
 JSON_VALUE(payload,'$.processing_mode') AS processing_mode,
 JSON_VALUE(payload,'$.state_before') AS state_before,
 JSON_VALUE(payload,'$.state_after') AS state_after,
 TRY_CONVERT(bigint,JSON_VALUE(payload,'$.elapsed_ms')) AS processing_ms,
 TRY_CONVERT(bigint,JSON_VALUE(payload,'$.waiting_ms')) AS waiting_before_ms,
 JSON_VALUE(payload,'$.file_name') AS file_name,
 JSON_VALUE(payload,'$.file_role') AS file_role,
 TRY_CONVERT(bigint,JSON_VALUE(payload,'$.file_bytes')) AS file_bytes,
 TRY_CONVERT(bigint,JSON_VALUE(payload,'$.file_rows')) AS file_rows,
 TRY_CONVERT(int,JSON_VALUE(payload,'$.file_columns')) AS file_columns,
 TRY_CONVERT(int,JSON_VALUE(payload,'$.raw_files')) AS active_raw_files,
 TRY_CONVERT(int,JSON_VALUE(payload,'$.mapping_files')) AS active_mapping_files,
 TRY_CONVERT(int,JSON_VALUE(payload,'$.protocol_files')) AS active_protocol_files,
 TRY_CONVERT(bigint,JSON_VALUE(payload,'$.rows_included')) AS rows_included,
 TRY_CONVERT(bigint,JSON_VALUE(payload,'$.rows_excluded')) AS rows_excluded,
 TRY_CONVERT(bigint,JSON_VALUE(payload,'$.rows_quarantined')) AS rows_quarantined,
 JSON_VALUE(payload,'$.detail') AS detail
FROM latest WHERE n=1;
GO
CREATE OR ALTER VIEW reporting.UploadHistory AS
 SELECT * FROM reporting.ProcessingRuns WHERE file_name IS NOT NULL;
GO
CREATE OR ALTER VIEW reporting.LoginHistory AS
 SELECT * FROM reporting.ProcessingRuns WHERE operation IN ('login','logout','browser_session');
GO
CREATE OR ALTER VIEW reporting.ProjectStatus AS
WITH latest AS (
 SELECT *,ROW_NUMBER() OVER(PARTITION BY project_id ORDER BY occurred_at DESC) AS project_rank
 FROM reporting.ProcessingRuns WHERE project_id IS NOT NULL AND project_name IS NOT NULL
)
SELECT * FROM latest WHERE project_rank=1;

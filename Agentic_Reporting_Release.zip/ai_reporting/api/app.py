"""Application entry point: python -m api.app from the project directory."""
import os
from api.server import app
from waitress import serve


def main():
    host = os.environ.get('HOST', '127.0.0.1')
    if host not in ('127.0.0.1', '::1', 'localhost') and len(app.config['APP_PASSWORD']) < 16:
        raise SystemExit('Set APP_PASSWORD to at least 16 characters before enabling remote access.')
    serve(app, host=host, port=int(os.environ.get('PORT', '5000')), threads=8,
          max_request_body_size=app.config['MAX_CONTENT_LENGTH'], channel_timeout=600)


if __name__ == '__main__':
    main()

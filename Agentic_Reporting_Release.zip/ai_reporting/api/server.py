"""Same-origin Flask application with persistent, browser-owned projects."""
import io
import logging
import os
from pathlib import Path
import secrets
import shutil
import threading
import time
import uuid
import zipfile
from urllib.parse import urlparse
from dataclasses import asdict
from flask import Flask, request, jsonify, Response, session, send_from_directory, g
from werkzeug.utils import secure_filename
from werkzeug.exceptions import HTTPException
from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parents[1]
load_dotenv(ROOT / '.env')
load_dotenv(ROOT / '.env.tracking')
from core.models import ProjectContext, IntakeState, AggregationType, FilterCondition
from core.chat_agent import process_message
from core.project_store import ProjectStore
from core.tracking import TrackingStore, utcnow
from datetime import datetime
import hashlib

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)
DATA_ROOT = Path(os.environ.get('DATA_ROOT', ROOT / 'runtime')).resolve()
DATA_ROOT.mkdir(parents=True, exist_ok=True)
UPLOAD_ROOT = DATA_ROOT / 'uploads'
UPLOAD_ROOT.mkdir(exist_ok=True)
secret_path = DATA_ROOT / 'session.key'
if not secret_path.exists():
    secret_path.write_text(secrets.token_hex(32), encoding='ascii')
app = Flask(__name__, static_folder=None)
app.config.update(SECRET_KEY=os.environ.get('SECRET_KEY') or secret_path.read_text().strip(),
    MAX_CONTENT_LENGTH=int(os.environ.get('MAX_UPLOAD_MB', '50')) * 1024 * 1024,
    SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE='Strict',
    SESSION_COOKIE_SECURE=os.environ.get('COOKIE_SECURE', 'false').lower() == 'true',
    PERMANENT_SESSION_LIFETIME=60 * 60 * 24 * 30,
    APP_PASSWORD=os.environ.get('APP_PASSWORD', ''))
SESSIONS = ProjectStore(DATA_ROOT / 'projects.sqlite3')
TRACKER = TrackingStore(DATA_ROOT / 'tracking.sqlite3')
_locks = {}
_guard = threading.Lock()
_login_failures = {}


@app.before_request
def access_control():
    if request.method in ('POST', 'PUT', 'PATCH', 'DELETE'):
        origin = request.headers.get('Origin')
        if (origin and urlparse(origin).netloc != request.host) or request.headers.get('Sec-Fetch-Site') == 'cross-site':
            return jsonify(error='Cross-site requests are not allowed.'), 403
    if not request.path.startswith('/api/') or request.path in ('/api/health', '/api/auth', '/api/login'):
        return None
    if app.config['APP_PASSWORD'] and not session.get('authenticated'):
        return jsonify(error='Sign in to continue.'), 401
    if not app.config['APP_PASSWORD'] and request.remote_addr not in ('127.0.0.1', '::1'):
        return jsonify(error='Remote access requires APP_PASSWORD.'), 403
    if 'owner_id' not in session:
        session['owner_id'] = str(uuid.uuid4())
        session.permanent = True
        TRACKER.safe_append(dict(request_id=str(uuid.uuid4()), owner_id=session['owner_id'],
            operation='browser_session', phase='Finished', outcome='Succeeded',
            identity_type='browser_session', detail='New browser session; no employee identity verified.'))
    sid = (request.view_args or {}).get('session_id')
    if sid:
        try:
            if str(uuid.UUID(sid)) != sid:
                raise ValueError()
        except ValueError:
            return jsonify(error='Project not found.'), 404
        with _guard:
            lock = _locks.setdefault(sid, threading.Lock())
        if not lock.acquire(blocking=False):
            return jsonify(error='This project is processing another request. Please wait.'), 409
        g.project_lock = lock
        ctx = SESSIONS.get(sid)
        if ctx is None or ctx.owner_id != session['owner_id']:
            return jsonify(error='Project not found.'), 404
        g.project = ctx


@app.before_request
def begin_tracking():
    if request.endpoint not in ('chat','edit_review','download','create_session','delete_session','login','logout'):
        return
    session.setdefault('owner_id', str(uuid.uuid4()))
    ctx = getattr(g, 'project', None)
    before = ctx.intake_state.value if ctx else None
    operation = {'chat':'workflow','edit_review':'review_edit','download':'download',
                 'create_session':'project_create','delete_session':'project_delete',
                 'login':'login','logout':'logout'}[request.endpoint]
    info = dict(request_id=str(uuid.uuid4()), owner_id=session['owner_id'],
                project_id=(request.view_args or {}).get('session_id'),
                project_name=ctx.project_name if ctx else None, state_before=before, state_after=before,
                operation=operation, phase='Started', outcome='Running', started_at=utcnow(),
                processing_mode='ai_available' if os.environ.get('ANTHROPIC_API_KEY') else 'rules_only',
                identity_type='shared_password_session' if session.get('authenticated') else 'browser_session', elapsed_ms=0)
    if request.endpoint == 'chat':
        info['operation'] = {'MODEL_BUILD':'model_build','EXPORT':'export', 'CLARIFY':'clarification',
                             'ERROR_REVIEW':'data_review','MAPPING_REVIEW':'mapping_review'}.get(before,'workflow')
    try:
        if info['project_id']:
            previous = next((r for r in reversed(TRACKER.records(session['owner_id']))
                             if r.get('project_id')==info['project_id'] and r['phase']=='Finished'
                             and r['operation']!='download'), None)
            if previous and operation!='download' and previous.get('state_after') in ('CLARIFY','MAPPING_REVIEW','ERROR_REVIEW','RAW_DATA','MAPPING_FILES','PROTOCOL','MODEL_BUILD','EXPORT'):
                info['waiting_ms'] = max(0, int((datetime.fromisoformat(utcnow())-datetime.fromisoformat(previous['occurred_at'])).total_seconds()*1000))
    except Exception:
        logger.warning('Tracking wait duration unavailable')
    g.tracking = info
    g.tracking_started = time.monotonic()
    TRACKER.safe_append(info)


@app.after_request
def finish_tracking(response):
    if not hasattr(g, 'tracking'):
        return response
    info = dict(g.tracking, phase='Finished', elapsed_ms=round((time.monotonic()-g.tracking_started)*1000),
                outcome='Succeeded' if response.status_code < 400 else 'Failed', http_status=response.status_code)
    ctx = getattr(g, 'project', None)
    if ctx:
        info.update(project_name=ctx.project_name, state_after=ctx.intake_state.value,
                    raw_files=len(ctx.raw_files), mapping_files=len(ctx.mapping_files),
                    protocol_files=int(bool(ctx.protocol_file_name)),
                    rows_included=sum(f.row_count for f in ctx.raw_files),
                    rows_excluded=sum(e.rows_dropped for e in ctx.errors),
                    rows_quarantined=sum(e.rows_quarantined for e in ctx.errors),
                    pending_issues=len(ctx.pending_errors()),
                    exports=[k for k,v in [('excel',ctx.excel_bytes),('powerbi',ctx.pbi_zip),('tmdl',ctx.tmdl_json),('audit',ctx.audit_json),('report',ctx.semantic_model)] if v])
        if info.get('file_name'):
            uploaded=next((f for f in ctx.raw_files+ctx.mapping_files if f.file_name==info['file_name']),None)
            if uploaded and response.status_code<400:
                info.update(file_rows=uploaded.row_count,file_columns=uploaded.col_count)
        if info['operation']=='model_build' and response.status_code<400 and ctx.intake_state==IntakeState.MODEL_BUILD:
            info.update(outcome='Blocked', detail='Model build did not complete; review the project definition checks.')
    if request.endpoint == 'login':
        info['identity_type']='shared_password_session' if response.status_code<400 else 'unverified_browser_session'
    if response.status_code>=400:
        info['detail']=f'Request failed (HTTP {response.status_code}); inspect the project error and server logs.'
    if request.endpoint=='delete_session' and response.status_code<400:
        info['state_after']='DELETED'
    TRACKER.safe_append(info)
    return response


@app.get('/api/tracking')
def tracking_history():
    try:
        offset=max(0,int(request.args.get('offset','0')))
    except ValueError:
        raise ValueError('Invalid history offset')
    return jsonify(TRACKER.history(session['owner_id'], request.args.get('project_id'), offset=offset))


@app.teardown_request
def release_lock(error=None):
    lock = g.pop('project_lock', None)
    if lock:
        lock.release()


@app.after_request
def headers(response):
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['Referrer-Policy'] = 'same-origin'
    response.headers['X-Frame-Options'] = 'DENY'
    response.headers['Content-Security-Policy'] = "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'self'; frame-ancestors 'none'"
    if request.path.startswith('/api/'):
        response.headers['Cache-Control'] = 'no-store'
    return response


@app.errorhandler(Exception)
def handle_error(exc):
    if isinstance(exc, HTTPException):
        return jsonify(error=exc.description), exc.code
    if isinstance(exc, (ValueError, KeyError, TypeError)):
        return jsonify(error=str(exc)), 400
    logger.exception('Request failed')
    return jsonify(error='Processing failed. The previous saved project is unchanged; inspect server logs.'), 500


@app.get('/api/health')
def health():
    return jsonify(status='ok')


@app.get('/api/auth')
def auth():
    return jsonify(login_required=bool(app.config['APP_PASSWORD']) and not session.get('authenticated'),
        authenticated=bool(session.get('authenticated')),
        ai_configured=bool(os.environ.get('ANTHROPIC_API_KEY')),
        max_upload_mb=app.config['MAX_CONTENT_LENGTH'] // (1024 * 1024))


@app.post('/api/login')
def login():
    ip = request.remote_addr
    now = time.monotonic()
    with _guard:
        failures = [t for t in _login_failures.get(ip, []) if now - t < 300]
        if len(failures) >= 10:
            return jsonify(error='Too many login attempts. Retry in five minutes.'), 429
        password = (request.get_json(silent=True) or {}).get('password', '')
        if not isinstance(password, str) or not secrets.compare_digest(password, app.config['APP_PASSWORD']):
            _login_failures[ip] = failures + [now]
            return jsonify(error='Incorrect password.'), 401
        _login_failures.pop(ip, None)
    session['authenticated'] = True
    session.setdefault('owner_id', str(uuid.uuid4()))
    session.permanent = True
    return jsonify(ok=True)


@app.post('/api/logout')
def logout():
    session.pop('authenticated', None)
    return jsonify(ok=True)


def summary(ctx):
    from core.validation import validate_model
    from core.models import SemanticModel
    from core.chat_agent import _get_all_dfs
    checks = ctx.validation
    if ctx.measures and not ctx.semantic_model:
        checks = validate_model(SemanticModel(tables=ctx.raw_files + ctx.mapping_files, measures=ctx.measures), _get_all_dfs(ctx))
    exports = [name for name, value in [('excel', ctx.excel_bytes), ('tmdl', ctx.tmdl_json),
               ('audit', ctx.audit_json), ('powerbi', ctx.pbi_zip), ('report', ctx.semantic_model)] if value]
    return dict(project_id=ctx.project_id, project_name=ctx.project_name, state=ctx.intake_state.value,
        raw_files=[f.file_name for f in ctx.raw_files], mapping_files=[f.file_name for f in ctx.mapping_files],
        protocol=ctx.protocol_file_name, measures_count=len(ctx.measures), mappings_count=len(ctx.mapping_decisions),
        errors_count=len(ctx.errors), errors_pending=len(ctx.pending_errors()), model_built=ctx.semantic_model is not None,
        last_updated=str(ctx.last_updated), exports_available=exports, validation=checks,
        clarification_questions=[dict(number=i, measure_id=m.measure_id, name=m.display_name,
            questions=m.clarification_questions or ['Describe the intended calculation.'])
            for i,m in enumerate(ctx.measures,1) if m.needs_clarification],
        data_summary=dict(rows_included=sum(f.row_count for f in ctx.raw_files),
            rows_excluded=sum(e.rows_dropped for e in ctx.errors),
            rows_quarantined=sum(e.rows_quarantined for e in ctx.errors)),
        pending_issues=[dict(id=e.error_id, detail=e.detail, options=[dict(id=o.option_id,label=o.label) for o in e.options]) for e in ctx.pending_errors()])


@app.post('/api/session')
def create_session():
    sid = str(uuid.uuid4())
    ctx = ProjectContext(owner_id=session['owner_id'])
    SESSIONS[sid] = ctx
    g.project = ctx
    g.tracking['project_id'] = sid
    return jsonify(session_id=sid, state=ctx.intake_state.value)


@app.get('/api/session/<session_id>')
def get_session(session_id):
    return jsonify(**summary(g.project), chat_history=g.project.chat_history)


@app.get('/api/sessions')
def list_sessions():
    return jsonify(sessions=[dict(session_id=sid, **summary(ctx)) for sid, ctx in SESSIONS.items()
                              if ctx.owner_id == session['owner_id']])


@app.delete('/api/session/<session_id>')
def delete_session(session_id):
    target = (UPLOAD_ROOT / session_id).resolve()
    if target.parent != UPLOAD_ROOT.resolve():
        raise ValueError('Invalid project path.')
    if target.exists():
        shutil.rmtree(target)
    del SESSIONS[session_id]
    return jsonify(deleted=session_id)


@app.post('/api/chat/<session_id>')
def chat(session_id):
    ctx = g.project
    attached = None
    saved = None
    if request.mimetype == 'multipart/form-data':
        message = request.form.get('message', '')
        file = request.files.get('file')
        if file and file.filename:
            name = secure_filename(file.filename)
            role = 'PROTOCOL' if ctx.intake_state==IntakeState.PROTOCOL else 'MAPPING' if ctx.intake_state==IntakeState.MAPPING_FILES else 'RAW_DATA'
            previous_file=next((m for m in ctx.raw_files+ctx.mapping_files if m.file_name==name),None)
            if previous_file:
                role=previous_file.file_role.value
            g.tracking.update(operation='upload', file_name=name, file_role=role, replacement=bool(previous_file))
            extension = Path(name).suffix.lower()
            g.tracking['file_format'] = extension
            formats = {'.xlsx', '.xls', '.csv', '.tsv'}
            if ctx.intake_state == IntakeState.PROTOCOL:
                formats = {'.xlsx', '.xls', '.docx', '.pdf', '.txt', '.md'}
            elif ctx.intake_state == IntakeState.PROJECT_INIT:
                raise ValueError('Enter a project name before uploading files.')
            if extension not in formats:
                raise ValueError('Accepted in this step: ' + ', '.join(sorted(formats)))
            content = file.read()
            g.tracking.update(file_bytes=len(content), file_sha256=hashlib.sha256(content).hexdigest())
            if not content:
                raise ValueError('The uploaded file is empty.')
            if zipfile.is_zipfile(io.BytesIO(content)):
                with zipfile.ZipFile(io.BytesIO(content)) as zf:
                    if sum(i.file_size for i in zf.infolist()) > 256 * 1024 * 1024:
                        raise ValueError('Workbook/document expands beyond the 256 MB processing limit.')
            folder = UPLOAD_ROOT / session_id / uuid.uuid4().hex
            folder.mkdir(parents=True, exist_ok=True)
            saved = folder / name
            saved.write_bytes(content)
            attached = (name, content, str(saved))
    else:
        data = request.get_json(silent=True)
        if not isinstance(data, dict):
            raise ValueError('Send a JSON object containing message.')
        message = data.get('message', '')
    if not isinstance(message, str) or len(message) > 20000:
        raise ValueError('Message must be text, at most 20,000 characters.')
    if not message.strip() and attached is None:
        raise ValueError('No message or file provided.')
    try:
        reply, ctx = process_message(ctx, message, attached)
        SESSIONS[session_id] = ctx
    except Exception:
        if saved and saved.exists():
            saved.unlink()
        raise
    return jsonify(reply=reply, state=ctx.intake_state.value, context=summary(ctx), exports_available=summary(ctx)['exports_available'])


@app.get('/api/review/<session_id>')
def review(session_id):
    ctx = g.project
    return jsonify(measures=[asdict(m) for m in ctx.measures], mappings=[asdict(d) for d in ctx.mapping_decisions],
                   tables=[{'table': t.table_name, 'columns': [c.name for c in t.columns]} for t in ctx.raw_files + ctx.mapping_files])


@app.patch('/api/review/<session_id>')
def edit_review(session_id):
    from core.review_actions import invalidate
    ctx = g.project
    data = request.get_json()
    if not isinstance(data, dict):
        raise ValueError('Send an object with kind, id, and changes.')
    kind, changes = data.get('kind'), data.get('changes', {})
    if kind == 'measure':
        measure = next((m for m in ctx.measures if m.measure_id == data.get('id')), None)
        if not measure:
            raise ValueError('Measure not found.')
        allowed = {'display_name', 'description', 'aggregation', 'base_table', 'base_column', 'dax_formula', 'format_string', 'filter_conditions', 'dependencies'}
        if not isinstance(changes, dict) or set(changes) - allowed:
            raise ValueError('Unsupported measure fields.')
        old_names = {measure.name, measure.display_name}
        for key, value in changes.items():
            if key == 'aggregation':
                value = AggregationType(value)
            elif key == 'filter_conditions':
                value = [FilterCondition(**f) for f in value]
            elif key == 'dependencies':
                if not isinstance(value, list) or not all(isinstance(v, str) for v in value):
                    raise ValueError('Dependencies must be a list of measure names.')
            elif not isinstance(value, str):
                raise ValueError(f'{key} must be text.')
            setattr(measure, key, value)
        if 'dax_formula' not in changes:
            measure.dax_formula = None
        measure.needs_clarification = False
        changed_names = {name.casefold() for name in old_names | {measure.name, measure.display_name}}
        for _ in ctx.measures:
            for dependent in ctx.measures:
                if dependent is not measure and {name.casefold() for name in dependent.dependencies} & changed_names:
                    dependent.dax_formula = None
                    changed_names.update((dependent.name.casefold(), dependent.display_name.casefold()))
    elif kind == 'mapping':
        mapping = next((m for m in ctx.mapping_decisions if m.decision_id == data.get('id')), None)
        if not mapping:
            raise ValueError('Mapping not found.')
        if data.get('reject'):
            ctx.mapping_decisions.remove(mapping)
            ctx.errors = [e for e in ctx.errors if not (e.category.value == 'REFERENTIAL_INTEGRITY' and e.affected_table == mapping.source_table and e.affected_column == mapping.source_column)]
        else:
            allowed = {'source_table', 'source_column', 'target_table', 'target_column'}
            if not isinstance(changes, dict) or set(changes) - allowed or not all(isinstance(v, str) for v in changes.values()):
                raise ValueError('Unsupported mapping fields.')
            ctx.errors = [e for e in ctx.errors if not (e.category.value == 'REFERENTIAL_INTEGRITY' and e.affected_table == mapping.source_table and e.affected_column == mapping.source_column)]
            for key, value in changes.items():
                setattr(mapping, key, value)
            mapping.user_confirmed = False
            mapping.user_override = True
            from core.review_actions import recheck_mappings
            recheck_mappings(ctx)
    else:
        raise ValueError('Choose measure or mapping.')
    invalidate(ctx)
    ctx.intake_state = IntakeState.MAPPING_REVIEW
    SESSIONS[session_id] = ctx
    return jsonify(context=summary(ctx), state=ctx.intake_state.value, reply='Definition saved. Previous exports were invalidated; review and confirm to rebuild.')


@app.get('/api/export/<session_id>/<kind>')
def download(session_id, kind):
    ctx = g.project
    name = secure_filename(ctx.project_name) or 'Report'
    formats = {'excel': (ctx.excel_bytes, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'xlsx'),
               'tmdl': (ctx.tmdl_json, 'application/json', 'summary.json'),
               'audit': (ctx.audit_json, 'application/json', 'audit.json'),
               'powerbi': (ctx.pbi_zip, 'application/zip', 'zip')}
    if kind == 'report' and ctx.semantic_model:
        from core.report_generator import generate_completion_report
        payload, mime, extension = generate_completion_report(ctx), 'application/pdf', 'pdf'
    else:
        payload, mime, extension = formats.get(kind, (None, '', ''))
    if not payload:
        return jsonify(error='This export has not been generated.'), 404
    return Response(payload, mimetype=mime, headers={'Content-Disposition': f'attachment; filename="{name}.{extension}"'})


@app.get('/')
@app.get('/<path:path>')
def frontend(path='index.html'):
    if path.startswith('api/'):
        return jsonify(error='Endpoint not found.'), 404
    return send_from_directory(ROOT / 'frontend' / 'build', path)

$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
if (-not (Test-Path -LiteralPath '.venv\Scripts\python.exe')) {
    throw 'Run .\setup.ps1 first.'
}
if (-not (Test-Path -LiteralPath 'frontend\build\index.html')) {
    throw 'Built frontend missing. From frontend, run npm ci and npm run build.'
}
Write-Host 'Starting Agentic Reporting. Default address: http://127.0.0.1:5000'
& .\.venv\Scripts\python.exe run_server.py

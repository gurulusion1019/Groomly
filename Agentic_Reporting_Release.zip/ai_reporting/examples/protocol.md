# Example sales report

Revenue: sum sales.amount over all rows. Format to two decimal places.
Orders: distinct count of sales.order_id. This counts orders, not order lines.
Units: sum sales.quantity.
Average order value: Revenue divided by Orders; blank if Orders is zero.

Show Revenue and Orders cards, Revenue by customer_name as a bar chart, and
Revenue over order_date as a line chart.

Independent full-data acceptance values:
- Revenue: 61.50
- Orders: 2
- Units: 7
- Average order value: 30.75

Protocol extraction requires an Anthropic API key. Without one, use generate
and review its basic suggestions; these may differ from this protocol.

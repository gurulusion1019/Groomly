# Agentic Reporting — single-server release

A Flask/React application that turns CSV/Excel inputs and reviewed metric
definitions into an editable Power BI project, Excel workbook, model summary,
audit log and PDF summary.

This release is prepared for private Windows use or a small internal deployment.
It is not a public SaaS release: account registration, organization membership,
distributed workers and cloud deployment have not been implemented.

## Start on Windows

1. Extract the entire release ZIP to a normal local folder, such as
   `C:\Reporting\ai_reporting`. Avoid running the application from inside a ZIP.
2. Install Python 3.11 if it is not already available.
3. In PowerShell in that folder, run `./setup.ps1`.
4. Edit `.env`. Set `ANTHROPIC_API_KEY` to enable protocol extraction and AI
   generation. Keep the key on the server; never enter it in a project/chat.
5. Run `./start.ps1`, then open [Agentic Reporting](http://127.0.0.1:5000).

The frontend is already built. Node.js is needed only to change/rebuild it.
If local policy prevents running PowerShell scripts, use these equivalent commands:

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
Copy-Item .env.example .env
.\.venv\Scripts\python.exe run_server.py
```

Copy `.env.example` only when `.env` does not already exist.

## First end-to-end check

1. Create a project.
2. Upload `examples/sales.csv`; send **done**.
3. Upload `examples/customers.csv`; send **done**.
4. Send **generate** for deterministic suggestions without an API key, or upload
   `examples/protocol.md` with the AI provider configured.
5. Open **Review and edit definitions**. Review measures and proposed joins.
6. Send **confirm all**, resolve any displayed data issues, then send **build**.
7. Send **all** to generate every export. Download buttons appear only for
   available artifacts.
8. Extract the Power BI ZIP. Open its `.pbip` in Power BI Desktop, set the
   `SourceDataFolder` parameter to the extracted `source_data` folder and refresh.
9. Compare the results with the example baselines: amount sum **61.50**, two
   distinct orders, seven units. Protocol AOV is **30.75**. The no-protocol
   suggestions may contain different measure names and do not claim to satisfy
   the example protocol.

The generated project uses the enhanced PBIR report format and a BIM semantic
model. Desktop may require the relevant project/PBIR preview options for the
installed version. See Microsoft's [PBIR documentation](https://learn.microsoft.com/en-us/power-bi/developer/embedded/projects-enhanced-report-format)
and [semantic-model project documentation](https://learn.microsoft.com/en-us/power-bi/developer/projects/projects-dataset).

## What changed

- Full approved data snapshots are exported, including cleaning decisions.
  Original raw uploads are not substituted for the reviewed data.
- Literal codes and leading-zero identifiers are preserved; common date and
  numeric columns are converted without coercing mixed currency values.
- Exact-name mappings require approval and report measured overlap.
- Duplicate lookup keys, missing fields and invalid basic definitions block export.
- Orphan exclusion updates data; quarantined duplicates are included separately.
- Basic generation normalizes aggregation names and avoids the old custom/SUM
  placeholder for distinct counts. Protocol-provider failure is an explicit error.
- Planned visuals flow onto additional pages, with a coverage manifest.
- Review edits invalidate exports; source replacement uses the same filename and
  requires another relationship review.
- Projects persist in SQLite. DataFrames use JSON serialization rather than pickle.
- Same-origin requests, safe chat formatting, browser ownership checks, optional
  password access, upload limits, safe download names and available-only exports.
- Production static files and API are served together by Waitress.

## Validation and limitations

Read `verification/TEST_REPORT.md` for the actual release evidence. Backend
definition checks, PBIR JSON-schema checks, Desktop execution and business
acceptance are separate statuses. A generated ZIP never means every DAX formula
has been executed or every business rule has been verified.

- Live AI calls require a valid Anthropic key. Tests use synthetic data and a
  controlled provider response for the protocol path.
- Arbitrary DAX remains subject to Power BI execution and business review.
  Backend validation is deliberately described as basic definition checking.
- Protocols over 12,000 characters fail explicitly instead of being truncated.
  Scanned PDFs without extractable text require a text protocol.
- Data ingestion defaults to the first workbook sheet. There is no worksheet
  picker in this release. Protocol workbooks include all sheets.
- Composite-key and intentional many-to-many modeling require explicit modeling
  support. Automatic unknown-dimension creation is not offered as a completed action.
- Visual coverage compares rendered visuals with the generated plan, not with
  every sentence of the original protocol. Review the result against requirements.
- Refresh reads approved snapshots. Source transformations are not automatically
  replayed against arbitrary replacement raw files. Upload replacements through
  the application and regenerate when the source changes.
- The 50 MB upload limit is configurable; it is not a tested memory/capacity
  guarantee. Generation is synchronous, with one active request per project.
- Text-based decisions that cannot be applied are reported explicitly. Use the
  review panel for supported definition/relationship edits.

## Internal server configuration

Keep `HOST=127.0.0.1` for private use. Remote binding requires `APP_PASSWORD` of
at least 16 characters. For access over a network, put the server behind your
organization's HTTPS reverse proxy, set `COOKIE_SECURE=true`, preserve the Host
header and configure the proxy timeout for report generation. Do not expose an
unencrypted password login directly to the internet.

Use one application process. Threaded Waitress serializes requests per project;
multiple processes/distributed workers are not supported by the request lock.

Projects belong to the signed browser cookie. The optional password gates app
access; it is not a named-user account system. Keep the same browser profile to
reopen projects. Clearing cookies loses that browser's project access.

Back up the entire `runtime` folder, including `session.key` and
`projects.sqlite3`, while the server is stopped. This folder contains uploaded
business data and generated artifacts. Restrict filesystem access appropriately.
The Projects screen supports deleting a project and its stored upload files.
There is no automatic retention schedule in this release.

## Development and checks

```powershell
.\.venv\Scripts\python.exe -m pytest tests -q
.\.venv\Scripts\python.exe -m pip check
cd frontend
npm ci
$env:CI='true'
npm test -- --watchAll=false --runInBand
npm run build
```

For frontend development, `npm start` proxies `/api` to port 5000. Production
uses a same-origin API. No provider key belongs in a `REACT_APP_*` variable.

`tools/smoke_http.py` exercises a running private server with synthetic inputs.
`tools/validate_package.py <export.zip>` validates declared Microsoft report
schemas locally, downloading only public schema files when not cached.

After configuring `.env`, run `python tools/live_acceptance.py` with the project
virtual environment to test real Anthropic generation using only the synthetic
examples. This makes billable provider calls. Results and exports are saved in
`verification/live-acceptance`; the test stops if definitions need clarification.
It checks generation and downloads, not DAX execution in Power BI Desktop.

The live example passed extraction of Revenue, Orders, Units and Average Order
Value, model building and all five exports. Its 15 declared report-schema files
passed validation. Desktop refresh and result acceptance remain pending.

Active API implementation: `api/server.py`; compatibility import: `api/app.py`.
Start the application with `run_server.py`.

import io
import json
import hashlib
import zipfile
from unittest.mock import patch
import pandas as pd
import pytest
from core.models import *
from core.file_processor import process_file
from core.chat_agent import _get_df, _store_df
from core.model_builder import assemble_model
from core.pbi_exporter import export_powerbi_package, build_pbir_modern_files

FACT = b'line_id,order_id,customer_id,amount,quantity,order_date\n001,A,C1,10.5,1,2026-01-01\n002,A,C2,20.25,2,2026-01-02\n003,B,C1,30.75,4,2026-01-03\n'
DIM = b'customer_id,customer_name\nC1,Alice\nC2,Bob\n'

def post(client, sid, text):
    result=client.post(f'/api/chat/{sid}', json={'message':text})
    assert result.status_code == 200, result.get_json()
    return result.get_json()

def upload(client, sid, name, data):
    result=client.post(f'/api/chat/{sid}', data={'file':(io.BytesIO(data),name),'message':f'Upload {name}'})
    assert result.status_code == 200, result.get_json()
    return result.get_json()

def start(client, fact=FACT):
    sid=client.post('/api/session').get_json()['session_id']
    post(client,sid,'Release Test')
    upload(client,sid,'sales.csv',fact)
    post(client,sid,'done')
    upload(client,sid,'customers.csv',DIM)
    post(client,sid,'done')
    return sid

def finish(client,sid):
    data=post(client,sid,'confirm all')
    assert data['state']=='MODEL_BUILD',data
    data=post(client,sid,'build')
    assert data['state']=='EXPORT',data
    data=post(client,sid,'all')
    assert data['state']=='COMPLETE',data
    return data

def test_no_protocol_full_api_workflow_and_every_download(client):
    sid=start(client)
    post(client,sid,'generate')
    finish(client,sid)
    for kind, magic in [('excel',b'PK'),('powerbi',b'PK'),('report',b'%PDF'),('tmdl',b'{'),('audit',b'{')]:
        response=client.get(f'/api/export/{sid}/{kind}')
        assert response.status_code==200,response.get_json()
        assert response.data.startswith(magic)
    with zipfile.ZipFile(io.BytesIO(client.get(f'/api/export/{sid}/powerbi').data)) as zf:
        manifest=json.loads(zf.read('validation_manifest.json'))
        fact=next(t for t in manifest['tables'] if t['table']=='sales')
        raw=zf.read(fact['file'])
        assert hashlib.sha256(raw).hexdigest()==fact['sha256']
        df=pd.read_csv(io.BytesIO(raw),dtype={'line_id':str})
        assert df['line_id'].tolist()==['001','002','003']
        assert df.amount.sum()==61.5
        assert df.order_id.nunique()==2
        assert manifest['validation'][-2]['status']=='Not checked'
        bim=json.loads(zf.read('model.bim'))
        cols=next(t for t in bim['model']['tables'] if t['name']=='sales')['columns']
        assert next(c for c in cols if c['name']=='order_date')['dataType']=='dateTime'
        for name in zf.namelist():
            if name.endswith(('.json','.pbip','.pbir','.pbism','.bim')):
                json.loads(zf.read(name))

def test_protocol_workflow_with_controlled_provider_response(client,monkeypatch):
    from core import protocol_parser
    sid=start(client)
    provider=[dict(name='revenue',display_name='Revenue',aggregation='SUM',base_table='sales',base_column='amount',format_string='#,##0.00',needs_clarification=False)]
    monkeypatch.setattr(protocol_parser,'_call_claude',lambda *a,**k:json.dumps(provider))
    post(client,sid,'Sum amount as Revenue for all rows. Show a Revenue card.')
    finish(client,sid)
    review=client.get(f'/api/review/{sid}').get_json()
    assert review['measures'][0]['dax_formula']=="Revenue = SUM('sales'[amount])"

def test_protocol_provider_unavailable_is_not_success(client):
    sid=start(client)
    result=client.post(f'/api/chat/{sid}',json={'message':'Sum amount as revenue and show it as a KPI card.'})
    assert result.status_code==400
    assert 'unavailable' in result.get_json()['error']
    assert client.get(f'/api/session/{sid}').get_json()['state']=='PROTOCOL'


def test_blank_date_samples_survive_project_reload(client):
    from core.project_store import encode, decode
    assert decode(encode(pd.NaT)) is None
    assert decode({'$date':'NaT'}) is None
    sid = client.post('/api/session').json['session_id']
    post(client, sid, 'Blank date regression')
    upload(client, sid, 'events.csv', b'event_id,ShipDate,amount\n01,2026-01-01,3\n02,,4\n03,,5\n')
    assert post(client, sid, 'done')['state'] == 'MAPPING_FILES'


def test_internal_dependency_names_build_and_display_alias_cycles_are_detected(client, monkeypatch):
    from core import protocol_parser
    sid = start(client)
    definitions = [
        dict(name='revenue', display_name='Revenue', aggregation='SUM', base_table='sales', base_column='amount'),
        dict(name='orders', display_name='Orders', aggregation='COUNTD', base_table='sales', base_column='order_id'),
        dict(name='average_order_value', display_name='Average Order Value', aggregation='RATIO', base_table='SALES',
             dependencies=['REVENUE', 'orders'], numerator='revenue', denominator='orders')]
    monkeypatch.setattr(protocol_parser, '_call_claude', lambda *a, **k: json.dumps(definitions))
    post(client, sid, 'Revenue is sum amount; Orders is distinct orders; average is Revenue divided by Orders.')
    result = client.get(f'/api/review/{sid}').json
    ratio = next(m for m in result['measures'] if m['aggregation'] == 'RATIO')
    changed = client.patch(f'/api/review/{sid}', json={'kind':'measure', 'id':ratio['measure_id'],
        'changes':{'dax_formula':'Average Order Value = DIVIDE([Revenue], [Orders])'}})
    assert changed.status_code == 200, changed.json
    finish(client, sid)
    measures = [MeasureDefinition(name='a', display_name='Alpha', dependencies=['BETA']),
                MeasureDefinition(name='b', display_name='Beta', dependencies=['a'])]
    assert protocol_parser.detect_dependency_cycles(measures)

def test_cleaned_data_is_packaged_and_quarantine_preserved(client):
    duplicate=FACT+FACT.splitlines(keepends=True)[1]
    sid=start(client,duplicate)
    post(client,sid,'generate')
    result=post(client,sid,'confirm all')
    assert result['state']=='ERROR_REVIEW'
    result=post(client,sid,'c')
    assert result['state']=='MODEL_BUILD',result
    post(client,sid,'build'); post(client,sid,'all')
    with zipfile.ZipFile(io.BytesIO(client.get(f'/api/export/{sid}/powerbi').data)) as zf:
        manifest=json.loads(zf.read('validation_manifest.json'))
        fact=next(t for t in manifest['tables'] if t['table']=='sales')
        assert fact['rows']==3
        assert pd.read_csv(io.BytesIO(zf.read(fact['file']))).amount.sum()==61.5
        assert len(pd.read_csv(io.BytesIO(zf.read('quarantine/sales_quarantine.csv'))))==1

def test_orphan_exclusion_really_removes_rows(client):
    sid=start(client,FACT.replace(b'003,B,C1',b'003,B,C9'))
    post(client,sid,'generate'); post(client,sid,'confirm all')
    result=post(client,sid,'a')
    assert result['state']=='MODEL_BUILD',result
    from api import server
    ctx=server.SESSIONS[sid]
    assert _get_df(ctx,'sales').amount.sum()==30.75
    assert ctx.raw_files[0].row_count==2

def test_owner_isolation_missing_download_and_restart(client,tmp_path,monkeypatch):
    from api import server
    from core.project_store import ProjectStore
    sid=start(client)
    assert client.get(f'/api/export/{sid}/powerbi').status_code==404
    other=server.app.test_client()
    assert other.get(f'/api/session/{sid}').status_code==404
    assert other.delete(f'/api/session/{sid}').status_code==404
    assert other.get('/api/sessions').get_json()['sessions']==[]
    monkeypatch.setattr(server,'SESSIONS',ProjectStore(server.SESSIONS.path))
    assert client.get(f'/api/session/{sid}').get_json()['raw_files']==['sales.csv']
    assert _get_df(server.SESSIONS[sid],'sales').line_id.tolist()==['001','002','003']

def test_authentication_and_csrf(client):
    from api import server
    server.app.config['APP_PASSWORD']='a-long-test-password'
    assert client.post('/api/session').status_code==401
    assert client.post('/api/login',json={'password':'wrong'}).status_code==401
    assert client.post('/api/login',json={'password':'a-long-test-password'}).status_code==200
    assert client.post('/api/session',headers={'Origin':'https://evil.example'}).status_code==403
    assert client.post('/api/session').status_code==200
    assert client.post('/api/logout').status_code==200
    assert client.get('/api/sessions').status_code==401

def test_invalid_upload_json_and_project_delete(client):
    sid=client.post('/api/session').get_json()['session_id']
    assert client.post(f'/api/chat/{sid}',json=[]).status_code==400
    post(client,sid,'Example')
    assert client.post(f'/api/chat/{sid}',data={'file':(io.BytesIO(b'{}'),'data.json')}).status_code==400
    upload(client,sid,'sales.csv',FACT)
    from api import server
    assert (server.UPLOAD_ROOT/sid).exists()
    assert client.delete(f'/api/session/{sid}').status_code==200
    assert not (server.UPLOAD_ROOT/sid).exists()
    assert client.get(f'/api/session/{sid}').status_code==404

def test_review_edit_invalidates_existing_exports(client):
    sid=start(client);post(client,sid,'generate');finish(client,sid)
    review=client.get(f'/api/review/{sid}').get_json()
    measure=next(m for m in review['measures'] if m['base_column']=='amount')
    result=client.patch(f'/api/review/{sid}',json={'kind':'measure','id':measure['measure_id'],'changes':{'display_name':'Revenue revised'}})
    assert result.status_code==200,result.get_json()
    assert result.get_json()['context']['exports_available']==[]
    assert client.get(f'/api/export/{sid}/powerbi').status_code==404
    finish(client,sid)
    assert any(m['display_name']=='Revenue revised' for m in client.get(f'/api/review/{sid}').get_json()['measures'])

@pytest.mark.parametrize('extension,delimiter',[('csv',','),('tsv','\t'),('csv',';')])
def test_identifiers_codes_and_delimiters(extension,delimiter):
    text=delimiter.join(['customer_id','reason_code','amount'])+'\n'+delimiter.join(['001','N/A','12.50'])+'\n'
    meta,df,errors=process_file(text.encode(),'input.'+extension,FileRole.RAW_DATA)
    assert df.customer_id.iloc[0]=='001'
    assert df.reason_code.iloc[0]=='N/A'
    assert df.amount.iloc[0]==12.5

def test_nonstandard_worksheet_and_dates():
    buf=io.BytesIO()
    pd.DataFrame({'item_id':['001','002'],'amount':[10.,20.],'order_date':['2026-01-01','2026-02-01']}).to_excel(buf,index=False,sheet_name='Transactions')
    meta,df,errors=process_file(buf.getvalue(),'orders.xlsx',FileRole.RAW_DATA)
    assert df.item_id.iloc[0]=='001'
    assert pd.api.types.is_datetime64_any_dtype(df.order_date)

def test_full_join_fanout_and_measured_exact_overlap():
    from core.automapper import check_join_fanout,pass1_exact
    raw=pd.DataFrame({'customer_id':['a']*5001+['b']})
    dim=pd.DataFrame({'customer_id':['a','b','b']})
    assert check_join_fanout(raw,dim,'customer_id','customer_id')[0]
    rm,rf,_=process_file(b'customer_id,amount\na,1\nb,2\n','fact.csv',FileRole.RAW_DATA)
    dm,df,_=process_file(b'customer_id,label\na,First\nc,Second\n','dim.csv',FileRole.MAPPING)
    decision=pass1_exact([(rm,rf)],[(dm,df)])[0]
    assert decision.value_overlap==0.5
    assert not decision.user_confirmed

def model_fixture(rows=3):
    data=pd.DataFrame({'row_id':[f'{i:05}' for i in range(rows)],'amount':[float(i)+0.5 for i in range(rows)],'category':['A']*rows})
    meta,df,_=process_file(data.to_csv(index=False).encode(),'sales.csv',FileRole.RAW_DATA)
    ctx=ProjectContext(project_name='Fixture',raw_files=[meta],measures=[MeasureDefinition(name='revenue',display_name='Revenue',base_table='sales',base_column='amount')])
    _store_df(ctx,'sales',df)
    return assemble_model(ctx),df

def test_export_contains_more_than_ten_thousand_rows():
    model,df=model_fixture(10003)
    with zipfile.ZipFile(io.BytesIO(export_powerbi_package(model,{'sales':df}))) as zf:
        manifest=json.loads(zf.read('validation_manifest.json'))
        assert manifest['tables'][0]['rows']==10003
        assert len(pd.read_csv(io.BytesIO(zf.read(manifest['tables'][0]['file']))))==10003

def test_multi_page_visuals_preserve_wide_tables_and_stay_in_bounds():
    model,df=model_fixture()
    plan=[{'type':'card','measure':'Revenue'} for _ in range(7)] + [{'type':'matrix','row_table':'sales','row_column':'category','measures':['Revenue']} for _ in range(8)] + [{'type':'slicer','table':'sales','column':'category'} for _ in range(6)]
    with patch('core.visual_planner.build_visual_plan',return_value=plan):
        files=build_pbir_modern_files(model,'Fixture.Report')
    coverage=json.loads(files['visual_coverage.json'])
    assert coverage['rendered']==21 and coverage['pages']>=3
    for name,content in files.items():
        if name.endswith('/page.json'):
            page=json.loads(content)
            folder=name.rsplit('/',1)[0]
            positions=[json.loads(v)['position'] for k,v in files.items() if k.startswith(folder+'/visuals/')]
            for pos in positions:
                assert pos['x']>=0 and pos['y']>=0
                assert pos['x']+pos['width']<=page['width']
                assert pos['y']+pos['height']<=page['height']
            for i,a in enumerate(positions):
                for b in positions[i+1:]:
                    assert not (a['x']<b['x']+b['width'] and b['x']<a['x']+a['width'] and a['y']<b['y']+b['height'] and b['y']<a['y']+a['height'])

def test_invalid_measure_reference_blocks_export():
    model,df=model_fixture()
    model.measures[0].dax_formula="Revenue = SUM('sales'[missing])"
    with pytest.raises(ValueError,match='missing field'):
        export_powerbi_package(model,{'sales':df})

def test_typed_filter_template_and_zero_denominator():
    from core.protocol_parser import _template_dax
    m=MeasureDefinition(display_name='Flag Revenue',base_table='sales',base_column='amount',filter_conditions=[FilterCondition('is_returned','=','Y'),FilterCondition('quantity','>',1)])
    formula=_template_dax(m)
    assert "'sales'[is_returned] = \"Y\"" in formula
    assert "'sales'[quantity] > 1" in formula
    m.aggregation=AggregationType.RATIO;m.numerator='amount';m.denominator='quantity';m.filter_conditions=[]
    assert ', 0)' in _template_dax(m)

def test_duplicate_lookup_resolution_can_complete(client):
    sid=client.post('/api/session').get_json()['session_id']
    post(client,sid,'Duplicate lookup test')
    upload(client,sid,'sales.csv',FACT);post(client,sid,'done')
    upload(client,sid,'customers.csv',DIM+b'C1,Alice changed\n');post(client,sid,'done')
    post(client,sid,'generate')
    result=post(client,sid,'confirm all')
    assert result['state']=='ERROR_REVIEW'
    result=post(client,sid,'a')
    assert result['state']=='MODEL_BUILD',result
    assert post(client,sid,'build')['state']=='EXPORT'

def test_replacement_upload_updates_snapshot_and_invalidates_download(client):
    sid=start(client);post(client,sid,'generate');finish(client,sid)
    result=upload(client,sid,'sales.csv',FACT.replace(b'10.5',b'11.5'))
    assert result['state']=='MAPPING_REVIEW'
    assert result['context']['exports_available']==[]
    finish(client,sid)
    from api import server
    assert _get_df(server.SESSIONS[sid],'sales').amount.sum()==62.5

def test_mapping_edit_rechecks_values_and_missing_fields(client):
    sid=start(client);post(client,sid,'generate')
    mapping=client.get(f'/api/review/{sid}').get_json()['mappings'][0]
    response=client.patch(f'/api/review/{sid}',json={'kind':'mapping','id':mapping['decision_id'],'changes':{'target_column':'missing'}})
    assert response.status_code==400
    response=client.patch(f'/api/review/{sid}',json={'kind':'mapping','id':mapping['decision_id'],'changes':{'target_column':'customer_name'}})
    assert response.status_code==200,response.get_json()
    assert response.get_json()['context']['errors_pending']==1

def test_no_confirmation_by_substring(client):
    sid=start(client);post(client,sid,'generate')
    response=post(client,sid,'not good, do not confirm')
    assert response['state']=='MAPPING_REVIEW'

def test_long_protocol_rejected_without_truncation():
    from core.protocol_parser import extract_measures
    with pytest.raises(ValueError,match='12,000'):
        extract_measures('x'*12001,['amount'])

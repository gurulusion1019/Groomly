from core.file_processor import process_file
from core.models import FileRole
from core.pbi_exporter import _build_file_path_partition


def test_csv_refresh_normalizes_iso_dates_and_blanks_without_changing_text_codes():
    meta,frame,_=process_file(b'code,event_date,amount\n001,2026-01-02,12.50\nN/A,,\n', 'events.csv',FileRole.RAW_DATA,'test')
    query='\n'.join(_build_file_path_partition(meta,'001_events.csv')['source']['expression'])
    assert 'Date.From(DateTime.FromText(_, [Culture="en-US"]))' in query
    assert '{"event_date", each if _ = "" then null' in query
    assert '{"amount", each if _ = "" then null' in query
    assert '{"code", each' not in query
    assert 'Table.TransformColumnTypes(Normalized,' in query and ', "en-US")' in query
    assert frame.code.tolist()==['001','N/A']

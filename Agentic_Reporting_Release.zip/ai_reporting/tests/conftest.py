"""Tests never send data to the provider or reuse live application state."""
import os
import sys
import tempfile
from pathlib import Path
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
os.environ['ANTHROPIC_API_KEY'] = ''
_runtime = tempfile.TemporaryDirectory(prefix='report_test_')
os.environ['DATA_ROOT'] = _runtime.name

@pytest.fixture(autouse=True)
def offline(monkeypatch):
    from core import automapper, protocol_parser, visual_planner, chat_agent
    monkeypatch.setattr(automapper, 'ANTHROPIC_API_KEY', '')
    monkeypatch.setattr(protocol_parser, 'ANTHROPIC_API_KEY', '')
    monkeypatch.setattr(visual_planner, '_call_claude_stream', lambda *a, **k: None)
    monkeypatch.setenv('ANTHROPIC_API_KEY', '')

@pytest.fixture
def client(tmp_path, monkeypatch):
    from api import server
    from core.project_store import ProjectStore
    monkeypatch.setattr(server, 'SESSIONS', ProjectStore(tmp_path / 'projects.sqlite3'))
    uploads = tmp_path / 'uploads'
    uploads.mkdir()
    monkeypatch.setattr(server, 'UPLOAD_ROOT', uploads)
    server.app.config.update(TESTING=True, APP_PASSWORD='', SESSION_COOKIE_SECURE=False)
    return server.app.test_client()

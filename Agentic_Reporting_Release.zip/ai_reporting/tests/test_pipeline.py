"""
tests/test_pipeline.py
Full test suite for the AI Reporting Automation pipeline.
Run with: python -m pytest tests/ -v
or:        python tests/test_pipeline.py
"""
import sys
import io
import json
import unittest
from pathlib import Path
from datetime import datetime
import os

# Make sure core is importable
sys.path.insert(0, str(Path(__file__).parent.parent))

import pandas as pd
import numpy as np


# ── Helpers to create test data ────────────────────────────────────────────

def make_csv(rows: list[dict]) -> bytes:
    df = pd.DataFrame(rows)
    buf = io.StringIO()
    df.to_csv(buf, index=False)
    return buf.getvalue().encode('utf-8')


def make_clean_dim() -> bytes:
    return make_csv([
        {'customer_id': f'C-{i:04d}', 'customer_name': f'Customer {i}',
         'region': ['NSW', 'VIC', 'QLD'][i % 3]}
        for i in range(1, 101)
    ])


def make_dirty_dim_duplicates() -> bytes:
    rows = [
        {'customer_id': f'C-{i:04d}', 'customer_name': f'Customer {i}',
         'region': ['NSW', 'VIC', 'QLD'][i % 3]}
        for i in range(1, 51)
    ]
    # Add duplicates
    rows += [
        {'customer_id': 'C-0001', 'customer_name': 'Customer 1',    'region': 'NSW'},
        {'customer_id': 'C-0001', 'customer_name': 'Customer 1 Ltd', 'region': 'NSW'},
        {'customer_id': 'C-0010', 'customer_name': 'Customer 10',   'region': 'VIC'},
    ]
    return make_csv(rows)


def make_raw_data(with_orphans=False, with_nulls=False) -> bytes:
    rows = []
    for i in range(1, 201):
        cid = f'C-{(i % 50) + 1:04d}'
        if with_orphans and i <= 10:
            cid = f'C-LEGACY-{i:04d}'   # orphan FK
        if with_nulls and i <= 5:
            cid = None                   # null FK
        rows.append({
            'sale_id': f'S-{i:05d}',
            'customer_id': cid,
            'product_id': f'P-{(i % 20) + 1:03d}',
            'sale_amount': round(100 + i * 10.5, 2),
            'sale_date': f'2024-0{(i % 9) + 1}-15',
        })
    return make_csv(rows)


def make_product_dim() -> bytes:
    return make_csv([
        {'product_id': f'P-{i:03d}', 'product_name': f'Product {i}',
         'category': ['Electronics', 'Clothing', 'Food'][i % 3]}
        for i in range(1, 21)
    ])


def make_protocol_text() -> str:
    return """
Q2 Sales Performance Report — Protocol

METRICS REQUIRED:

1. Total Revenue
   Sum of all sale_amount values across all transactions.
   Format: currency, 2 decimal places.
   KPI: yes.

2. Unique Customers
   Count of distinct customer_id values.
   Format: integer with comma separator.
   KPI: yes.

3. Average Order Value
   Total Revenue divided by number of transactions.
   Format: currency.

4. Revenue YTD
   Year-to-date sum of sale_amount using calendar year.
   Format: currency.
   KPI: yes.

5. Gross Margin Percentage
   (Revenue - Cost) / Revenue * 100.
   Format: percentage.
   KPI: yes.
"""


# ═══════════════════════════════════════════════════════════════════════════
# TEST CASES
# ═══════════════════════════════════════════════════════════════════════════

class TestFileProcessor(unittest.TestCase):

    def setUp(self):
        from core.file_processor import process_file
        from core.models import FileRole
        self.process_file = process_file
        self.FileRole = FileRole

    def test_clean_csv_loads(self):
        content = make_clean_dim()
        meta, df, errors = self.process_file(
            content, 'dim_customer.csv', self.FileRole.MAPPING
        )
        self.assertEqual(meta.row_count, 100)
        self.assertIn('customer_id', [c.name for c in meta.columns])
        self.assertIn('customer_id', meta.pk_candidates)
        self.assertEqual(len(errors), 0)
        print(f"  ✓ Clean CSV: {meta.row_count} rows, {meta.col_count} cols, "
              f"PKs: {meta.pk_candidates}")

    def test_duplicate_pk_detected(self):
        content = make_dirty_dim_duplicates()
        meta, df, errors = self.process_file(
            content, 'dim_customer.csv', self.FileRole.MAPPING
        )
        dup_errors = [e for e in errors if 'DUPLICATE' in e.sub_type]
        self.assertGreater(len(dup_errors), 0,
                           "Should detect duplicate PK errors")
        e = dup_errors[0]
        self.assertGreater(e.affected_row_count, 0)
        self.assertGreater(len(e.options), 1)
        print(f"  ✓ Duplicate detection: {e.affected_row_count} dup rows, "
              f"{len(e.options)} resolution options")

    def test_null_key_detected(self):
        content = make_raw_data(with_nulls=True)
        meta, df, errors = self.process_file(
            content, 'sales.csv', self.FileRole.RAW_DATA
        )
        null_errors = [e for e in errors if e.sub_type == 'NULL_JOIN_KEY']
        self.assertGreater(len(null_errors), 0,
                           "Should detect null join key errors")
        print(f"  ✓ Null key detection: {null_errors[0].affected_row_count} null rows")

    def test_whitespace_auto_resolved(self):
        content = make_csv([
            {'  customer_id  ': '  C-001  ', 'name': '  Alice  '},
            {'  customer_id  ': '  C-002  ', 'name': '  Bob  '},
        ])
        meta, df, errors = self.process_file(
            content, 'test.csv', self.FileRole.RAW_DATA
        )
        # Whitespace auto-resolved — should be in errors_detected notes
        self.assertTrue(
            any('whitespace' in n.lower() or 'strip' in n.lower()
                for n in meta.errors_detected),
            "Whitespace stripping should be noted in auto-resolved"
        )
        print(f"  ✓ Auto-resolve: whitespace stripped, noted in errors_detected")

    def test_resolution_keep_first(self):
        from core.file_processor import apply_error_resolution
        content = make_dirty_dim_duplicates()
        meta, df, errors = self.process_file(
            content, 'dim_customer.csv', self.FileRole.MAPPING
        )
        dup_error = next(
            (e for e in errors if e.sub_type in ("DUPLICATE_PK", "DUPLICATE_ROWS")), None
        )
        self.assertIsNotNone(dup_error)
        original_len = len(df)
        df2, updated = apply_error_resolution(df, dup_error, 'a')
        self.assertLess(len(df2), original_len,
                        "Keeping first should reduce row count")
        self.assertGreater(updated.rows_dropped, 0)
        print(f"  ✓ Resolution 'keep first': {updated.rows_dropped} rows dropped")

    def test_resolution_merge(self):
        from core.file_processor import apply_error_resolution
        content = make_dirty_dim_duplicates()
        meta, df, errors = self.process_file(
            content, 'dim_customer.csv', self.FileRole.MAPPING
        )
        dup_error = next(
            (e for e in errors if e.sub_type in ("DUPLICATE_PK", "DUPLICATE_ROWS")), None
        )
        if dup_error:
            df2, updated = apply_error_resolution(df, dup_error, 'c')
            self.assertEqual(updated.rows_dropped, 0,
                             "Merge should not drop rows")
            print(f"  ✓ Resolution 'merge': {updated.rows_modified} rows modified, "
                  f"0 dropped")


class TestAutomapper(unittest.TestCase):

    def setUp(self):
        from core.file_processor import process_file
        from core.models import FileRole
        from core.automapper import pass1_exact, pass2_fuzzy, check_orphan_fks
        self.process_file = process_file
        self.FileRole = FileRole
        self.pass1 = pass1_exact
        self.pass2 = pass2_fuzzy
        self.check_orphan_fks = check_orphan_fks

    def _load(self, content, name, role):
        meta, df, _ = self.process_file(content, name, role)
        return meta, df

    def test_pass1_exact_match(self):
        raw_meta, raw_df = self._load(
            make_raw_data(), 'sales.csv', self.FileRole.RAW_DATA
        )
        dim_meta, dim_df = self._load(
            make_clean_dim(), 'dim_customer.csv', self.FileRole.MAPPING
        )
        decisions = self.pass1([(raw_meta, raw_df)], [(dim_meta, dim_df)])
        exact = [d for d in decisions if d.confidence == 1.0]
        self.assertGreater(len(exact), 0,
                           "Should find at least one exact match")
        match = exact[0]
        self.assertEqual(match.source_column, 'customer_id')
        self.assertEqual(match.target_column, 'customer_id')
        print(f"  ✓ Pass 1 exact: {len(exact)} match(es) — "
              f"{match.source_table}.{match.source_column} → "
              f"{match.target_table}.{match.target_column}")

    def test_pass1_requires_user_confirmation(self):
        raw_meta, raw_df = self._load(
            make_raw_data(), 'sales.csv', self.FileRole.RAW_DATA
        )
        dim_meta, dim_df = self._load(
            make_clean_dim(), 'dim_customer.csv', self.FileRole.MAPPING
        )
        decisions = self.pass1([(raw_meta, raw_df)], [(dim_meta, dim_df)])
        for d in decisions:
            self.assertFalse(d.user_confirmed,
                             "Exact names must still be reviewed")
        print(f"  ✓ All {len(decisions)} Pass 1 decisions auto-confirmed")

    def test_pass2_fuzzy_match(self):
        # Create raw data with a renamed FK column
        raw = make_csv([
            {'txn_id': f'T-{i}', 'cust_id': f'C-{i:04d}',
             'amount': i * 10.0}
            for i in range(1, 51)
        ])
        raw_meta, raw_df = self._load(raw, 'transactions.csv', self.FileRole.RAW_DATA)
        dim_meta, dim_df = self._load(
            make_clean_dim(), 'dim_customer.csv', self.FileRole.MAPPING
        )
        decisions = self.pass2(
            [(raw_meta, raw_df)], [(dim_meta, dim_df)], set()
        )
        # cust_id should fuzzy-match customer_id with reasonable confidence
        matches = [d for d in decisions
                   if d.source_column == 'cust_id' and
                   d.target_column == 'customer_id']
        if matches:
            m = matches[0]
            self.assertGreaterEqual(m.confidence, 0.70)
            print(f"  ✓ Pass 2 fuzzy: cust_id → customer_id at "
                  f"{m.confidence:.0%} confidence")
        else:
            # Not guaranteed with short column names — acceptable
            print("  ✓ Pass 2 fuzzy: no match (acceptable — short name 'cust_id')")

    def test_orphan_fk_detection(self):
        raw_content = make_raw_data(with_orphans=True)
        _, raw_df = self._load(raw_content, 'sales.csv', self.FileRole.RAW_DATA)
        _, dim_df = self._load(
            make_clean_dim(), 'dim_customer.csv', self.FileRole.MAPPING
        )
        raw_df.name = 'sales'
        error = self.check_orphan_fks(
            raw_df, dim_df, 'customer_id', 'customer_id', 'sale_amount'
        )
        self.assertIsNotNone(error, "Should detect orphan FKs")
        self.assertGreater(error.affected_row_count, 0)
        self.assertGreater(len(error.options), 1)
        print(f"  ✓ Orphan FK detection: {error.affected_row_count} orphan rows, "
              f"affected value ${error.affected_measure_value:,.0f}")

    def test_circular_join_detection(self):
        from core.automapper import check_circular_joins
        from core.models import MappingDecision, MappingMethod

        # A → B → C → A (cycle)
        decisions = [
            MappingDecision(source_table='A', target_table='B',
                            method=MappingMethod.EXACT, user_confirmed=True),
            MappingDecision(source_table='B', target_table='C',
                            method=MappingMethod.EXACT, user_confirmed=True),
            MappingDecision(source_table='C', target_table='A',
                            method=MappingMethod.EXACT, user_confirmed=True),
        ]
        cycles = check_circular_joins(decisions)
        self.assertGreater(len(cycles), 0, "Should detect cycle A→B→C→A")
        print(f"  ✓ Circular join detection: cycle found {' → '.join(cycles[0])}")

    def test_no_cycle_in_clean_graph(self):
        from core.automapper import check_circular_joins
        from core.models import MappingDecision, MappingMethod

        decisions = [
            MappingDecision(source_table='sales', target_table='dim_customer',
                            method=MappingMethod.EXACT, user_confirmed=True),
            MappingDecision(source_table='sales', target_table='dim_product',
                            method=MappingMethod.EXACT, user_confirmed=True),
        ]
        cycles = check_circular_joins(decisions)
        self.assertEqual(len(cycles), 0, "Clean graph should have no cycles")
        print("  ✓ No cycles in clean star schema graph")


class TestProtocolParser(unittest.TestCase):

    def setUp(self):
        from core.protocol_parser import (
            extract_measures, detect_dependency_cycles,
            detect_protocol_conflicts, _stub_extraction
        )
        self.extract_measures = extract_measures
        self.detect_cycles = detect_dependency_cycles
        self.detect_conflicts = detect_protocol_conflicts
        self._stub = _stub_extraction

    def test_stub_extraction_returns_measures(self):
        items = self._stub("any text")
        self.assertGreater(len(items), 0)
        self.assertIn('name', items[0])
        print(f"  ✓ Stub extraction: {len(items)} measure(s) returned")

    def test_extract_returns_measure_definitions(self):
        from unittest.mock import patch
        with patch('core.protocol_parser._call_claude', return_value=json.dumps([{
            'name':'revenue','display_name':'Revenue','aggregation':'SUM',
            'base_column':'sale_amount','base_table':'sales'
        }])):
            measures = self.extract_measures(make_protocol_text(), ['sale_amount'])
        self.assertGreater(len(measures), 0)
        for m in measures:
            self.assertTrue(m.name, "Measure should have a name")
            self.assertIsNotNone(m.aggregation)
        print(f"  ✓ Measure extraction: {len(measures)} measures parsed")

    def test_dependency_cycle_detection(self):
        from core.models import MeasureDefinition, AggregationType
        measures = [
            MeasureDefinition(name='revenue', aggregation=AggregationType.SUM,
                              dependencies=['gross_margin']),
            MeasureDefinition(name='gross_margin', aggregation=AggregationType.RATIO,
                              dependencies=['revenue']),
        ]
        errors = self.detect_cycles(measures)
        self.assertGreater(len(errors), 0,
                           "Should detect dependency cycle")
        print(f"  ✓ Dependency cycle detection: "
              f"found cycle {errors[0].affected_column}")

    def test_no_cycle_in_clean_measures(self):
        from core.models import MeasureDefinition, AggregationType
        measures = [
            MeasureDefinition(name='total_revenue', aggregation=AggregationType.SUM,
                              dependencies=[]),
            MeasureDefinition(name='avg_order', aggregation=AggregationType.AVG,
                              dependencies=['total_revenue']),
        ]
        errors = self.detect_cycles(measures)
        self.assertEqual(len(errors), 0, "Clean dependencies should have no cycle")
        print("  ✓ No cycle in clean measure dependency graph")

    def test_dax_template_generation(self):
        from core.protocol_parser import _template_dax
        from core.models import MeasureDefinition, AggregationType
        m = MeasureDefinition(
            name='total_revenue',
            display_name='Total Revenue',
            aggregation=AggregationType.SUM,
            base_column='sale_amount',
            base_table='sales',
        )
        dax = _template_dax(m)
        self.assertIn('SUM', dax)
        self.assertIn('sale_amount', dax)
        print(f"  ✓ DAX template: {dax[:60]}")

    def test_dax_ratio_template(self):
        from core.protocol_parser import _template_dax
        from core.models import MeasureDefinition, AggregationType
        m = MeasureDefinition(
            name='gross_margin_pct',
            display_name='Gross Margin %',
            aggregation=AggregationType.RATIO,
            numerator='gross_profit',
            denominator='sale_amount',
            base_table='sales',
            format_string='0.0%',
        )
        dax = _template_dax(m)
        self.assertIn('DIVIDE', dax)
        print(f"  ✓ DAX ratio template: {dax[:70]}")


class TestModelBuilder(unittest.TestCase):

    def _build_ctx(self):
        from core.models import ProjectContext, IntakeState
        from core.file_processor import process_file
        from core.models import FileRole
        from core.protocol_parser import extract_measures

        ctx = ProjectContext(
            project_name='Test Project',
            intake_state=IntakeState.MODEL_BUILD,
        )

        raw_content = make_raw_data()
        meta, df, _ = process_file(
            raw_content, 'sales.csv', FileRole.RAW_DATA, ctx.project_id
        )
        ctx.raw_files.append(meta)
        ctx._dataframes = {meta.table_name: df}
        from core.chat_agent import _store_df
        _store_df(ctx, meta.table_name, df)

        dim_content = make_clean_dim()
        dim_meta, dim_df, _ = process_file(
            dim_content, 'dim_customer.csv', FileRole.MAPPING, ctx.project_id
        )
        ctx.mapping_files.append(dim_meta)
        ctx._dataframes[dim_meta.table_name] = dim_df
        _store_df(ctx, dim_meta.table_name, dim_df)

        ctx.protocol_text = make_protocol_text()
        from core.protocol_parser import generate_measures_from_data
        ctx.measures = generate_measures_from_data(ctx.raw_files, ctx.mapping_files)

        from core.automapper import pass1_exact
        decisions = pass1_exact(
            [(meta, df)], [(dim_meta, dim_df)]
        )
        ctx.mapping_decisions = decisions

        return ctx

    def test_model_assembles(self):
        from core.model_builder import assemble_model
        ctx = self._build_ctx()
        model = assemble_model(ctx)
        self.assertIsNotNone(model)
        self.assertGreater(len(model.tables), 0)
        self.assertIsNotNone(model.built_at)
        print(f"  ✓ Model assembled: {len(model.tables)} tables, "
              f"{len(model.relationships)} rels, {len(model.measures)} measures")

    def test_excel_export(self):
        from core.model_builder import assemble_model, export_excel
        ctx = self._build_ctx()
        model = assemble_model(ctx)
        dfs = getattr(ctx, '_dataframes', {})
        xlsx_bytes = export_excel(model, dfs)
        self.assertGreater(len(xlsx_bytes), 0)
        self.assertTrue(xlsx_bytes[:4] == b'PK\x03\x04',
                        "Excel file should start with PK header (ZIP)")
        print(f"  ✓ Excel export: {len(xlsx_bytes):,} bytes, valid XLSX format")

    def test_tmdl_json_export(self):
        from core.model_builder import assemble_model, export_tmdl_json
        ctx = self._build_ctx()
        model = assemble_model(ctx)
        tmdl = export_tmdl_json(model)
        data = json.loads(tmdl)
        self.assertIn('model', data)
        self.assertIn('tables', data['model'])
        self.assertIn('measures', data['model'])
        self.assertIn('relationships', data['model'])
        print(f"  ✓ TMDL JSON: {len(data['model']['tables'])} tables, "
              f"{len(data['model']['measures'])} measures")

    def test_audit_log_export(self):
        from core.model_builder import assemble_model, export_audit_log
        from core.models import DataError, ErrorCategory, ErrorSeverity
        from core.models import ResolutionMethod, ResolutionOption
        ctx = self._build_ctx()

        # Add a sample resolved error
        e = DataError(
            project_id=ctx.project_id,
            category=ErrorCategory.DATA_QUALITY,
            sub_type='DUPLICATE_PK',
            severity=ErrorSeverity.HIGH,
            affected_table='dim_customer',
            affected_column='customer_id',
            affected_row_count=5,
            resolution_method=ResolutionMethod.USER_DECISION,
            chosen_option_id='a',
            options=[ResolutionOption('a', 'Keep first', 'Desc', 'Impact')],
            resolved_at=datetime.now(),
        )
        ctx.errors.append(e)

        model = assemble_model(ctx)
        log = export_audit_log(model)
        data = json.loads(log)
        self.assertIn('resolutions', data)
        print(f"  ✓ Audit log: {len(data['resolutions'])} resolution(s) logged")


class TestReportGenerator(unittest.TestCase):

    def test_pdf_generates(self):
        from core.model_builder import assemble_model
        from core.report_generator import generate_completion_report
        from core.file_processor import process_file
        from core.models import (ProjectContext, IntakeState, FileRole)
        from core.protocol_parser import extract_measures
        from core.automapper import pass1_exact

        ctx = ProjectContext(
            project_name='Unit Test Report',
            intake_state=IntakeState.COMPLETE,
        )

        raw_content = make_raw_data()
        meta, df, _ = process_file(
            raw_content, 'sales.csv', FileRole.RAW_DATA, ctx.project_id
        )
        ctx.raw_files.append(meta)
        ctx._dataframes = {meta.table_name: df}
        from core.chat_agent import _store_df
        _store_df(ctx, meta.table_name, df)

        dim_content = make_clean_dim()
        dim_meta, dim_df, _ = process_file(
            dim_content, 'dim_customer.csv', FileRole.MAPPING, ctx.project_id
        )
        ctx.mapping_files.append(dim_meta)
        ctx._dataframes[dim_meta.table_name] = dim_df
        _store_df(ctx, dim_meta.table_name, dim_df)

        from core.protocol_parser import generate_measures_from_data
        ctx.measures = generate_measures_from_data(ctx.raw_files, ctx.mapping_files)
        ctx.mapping_decisions = pass1_exact([(meta, df)], [(dim_meta, dim_df)])
        ctx.semantic_model = assemble_model(ctx)

        pdf_bytes = generate_completion_report(ctx)
        self.assertGreater(len(pdf_bytes), 0)
        self.assertTrue(pdf_bytes[:4] == b'%PDF',
                        "PDF should start with %PDF header")
        print(f"  ✓ PDF report: {len(pdf_bytes):,} bytes, valid PDF")


class TestChatAgent(unittest.TestCase):

    def setUp(self):
        from core.models import ProjectContext, IntakeState
        from core.chat_agent import process_message
        self.ProjectContext = ProjectContext
        self.IntakeState = IntakeState
        self.process_message = process_message

    def test_project_init_state(self):
        ctx = self.ProjectContext()
        self.assertEqual(ctx.intake_state, self.IntakeState.PROJECT_INIT)
        reply, updated = self.process_message(ctx, 'Q2 Sales Report')
        self.assertEqual(updated.project_name, 'Q2 Sales Report')
        self.assertEqual(updated.intake_state, self.IntakeState.RAW_DATA)
        print(f"  ✓ Chat PROJECT_INIT → RAW_DATA: project '{updated.project_name}'")

    def test_short_name_rejected(self):
        ctx = self.ProjectContext()
        reply, updated = self.process_message(ctx, 'X')
        self.assertEqual(updated.intake_state, self.IntakeState.PROJECT_INIT,
                         "Single char name should stay in PROJECT_INIT")
        print("  ✓ Short project name rejected — stays in PROJECT_INIT")

    def test_raw_data_with_file(self):
        ctx = self.ProjectContext()
        _, ctx = self.process_message(ctx, 'My Test Project')
        raw_content = make_raw_data()
        reply, updated = self.process_message(
            ctx, '', attached_file=('sales.csv', raw_content)
        )
        self.assertGreater(len(updated.raw_files), 0)
        self.assertIn('sales', reply.lower() or updated.raw_files[0].file_name.lower())
        print(f"  ✓ File upload processed: {updated.raw_files[0].file_name}, "
              f"{updated.raw_files[0].row_count} rows")

    def test_skip_mapping_files(self):
        ctx = self.ProjectContext()
        _, ctx = self.process_message(ctx, 'Test Project')
        _, ctx = self.process_message(
            ctx, '', attached_file=('sales.csv', make_raw_data())
        )
        _, ctx = self.process_message(ctx, 'done')
        _, ctx = self.process_message(ctx, 'skip')
        self.assertEqual(ctx.intake_state, self.IntakeState.PROTOCOL,
                         "Skipping mapping files should advance to PROTOCOL")
        print("  ✓ Mapping files skipped → advanced to PROTOCOL state")

    def test_chat_history_recorded(self):
        ctx = self.ProjectContext()
        reply, ctx = self.process_message(ctx, 'Sales Q2')
        self.assertGreater(len(ctx.chat_history), 0)
        user_msgs = [m for m in ctx.chat_history if m['role'] == 'user']
        self.assertGreater(len(user_msgs), 0)
        print(f"  ✓ Chat history: {len(ctx.chat_history)} entries recorded")


# ── Runner ─────────────────────────────────────────────────────────────────

def run_all():
    suites = [
        ('File Processor',  TestFileProcessor),
        ('Automapper',       TestAutomapper),
        ('Protocol Parser',  TestProtocolParser),
        ('Model Builder',    TestModelBuilder),
        ('Report Generator', TestReportGenerator),
        ('Chat Agent',       TestChatAgent),
    ]

    total_pass = total_fail = total_err = 0

    for suite_name, cls in suites:
        print(f'\n{"="*60}')
        print(f'  {suite_name}')
        print(f'{"="*60}')
        loader = unittest.TestLoader()
        suite = loader.loadTestsFromTestCase(cls)
        #runner = unittest.TextTestRunner(verbosity=0, stream=open('/dev/null', 'w'))
        runner = unittest.TextTestRunner(verbosity=0,stream=open(os.devnull, 'w'))
        result = runner.run(suite)

        # Re-run with visible output
        for test in suite:
            if test is None:
                continue
            try:
                test.debug()
                total_pass += 1
            except AssertionError as e:
                total_fail += 1
                print(f"  ✗ FAIL: {test} — {e}")
            except Exception as e:
                total_err += 1
                print(f"  ✗ ERROR: {test} — {type(e).__name__}: {e}")

    print(f'\n{"="*60}')
    print(f'  Results: {total_pass} passed, {total_fail} failed, {total_err} errors')
    print(f'{"="*60}')
    return total_fail + total_err == 0


if __name__ == '__main__':
    success = run_all()
    sys.exit(0 if success else 1)

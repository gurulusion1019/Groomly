"""Exercise both supported launch commands over real local HTTP."""
import os
from pathlib import Path
import socket
import subprocess
import sys
import time
import urllib.request

import pytest


@pytest.mark.parametrize('arguments', [['-m', 'api.app'], ['run_server.py']])
def test_launch_command_serves_configured_port(arguments, tmp_path):
    root = Path(__file__).resolve().parents[1]
    with socket.socket() as listener:
        listener.bind(('127.0.0.1', 0))
        port = listener.getsockname()[1]
    environment = dict(os.environ, HOST='127.0.0.1', PORT=str(port),
                       DATA_ROOT=str(tmp_path / 'runtime'), APP_PASSWORD='',
                       ANTHROPIC_API_KEY='')
    process = subprocess.Popen([sys.executable, *arguments], cwd=root,
                               env=environment, stdout=subprocess.DEVNULL,
                               stderr=subprocess.DEVNULL)
    try:
        deadline = time.monotonic() + 60
        while time.monotonic() < deadline:
            assert process.poll() is None, 'Server exited before becoming ready'
            try:
                with urllib.request.urlopen(f'http://127.0.0.1:{port}/api/health', timeout=1) as response:
                    assert response.status == 200
                    assert b'"ok"' in response.read()
                break
            except OSError:
                time.sleep(0.1)
        else:
            pytest.fail('Server did not serve health on the configured port')
    finally:
        if os.name == 'nt' and process.poll() is None:
            # Windows venv launchers may own a child Python server process.
            subprocess.run(['taskkill', '/PID', str(process.pid), '/T', '/F'],
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                           check=True, timeout=15)
        elif process.poll() is None:
            process.terminate()
        process.wait(timeout=15)

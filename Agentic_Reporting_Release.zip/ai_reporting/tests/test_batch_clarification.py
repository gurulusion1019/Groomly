from unittest.mock import patch
import pytest
from core.models import ProjectContext, MeasureDefinition, IntakeState
from core.chat_agent import process_message, _clarification_prompt, _clarification_answers


def context():
    return ProjectContext(intake_state=IntakeState.CLARIFY, measures=[
        MeasureDefinition(name='ready', display_name='Ready'),
        MeasureDefinition(name='rate', display_name='Return rate', needs_clarification=True,
                          clarification_questions=['Count lines or orders?']),
        MeasureDefinition(name='top', display_name='Top product', needs_clarification=True,
                          clarification_questions=['Name or revenue?'])])


def test_questions_together_and_stable_partial_numbering():
    ctx = context()
    assert '2. Return rate' in _clarification_prompt(ctx)
    assert '3. Top product' in _clarification_prompt(ctx)
    with patch('core.protocol_parser.ANTHROPIC_API_KEY', 'test'), patch('core.protocol_parser.generate_dax', return_value='Rate = 1'):
        reply, ctx = process_message(ctx, '2: Count lines')
    assert ctx.measures[1].clarification_answers['user_response'] == 'Count lines'
    assert not ctx.measures[1].needs_clarification
    assert '3. Top product' in reply
    assert '2. Return rate' not in reply


def test_multiple_answers_advance_once():
    ctx = context()
    with patch('core.protocol_parser.ANTHROPIC_API_KEY', 'test'), patch('core.protocol_parser.generate_dax', side_effect=['Rate = 1', 'Top = 2']) as generate:
        _, ctx = process_message(ctx, '2: Count lines\n3: Revenue value')
    assert generate.call_count == 2
    assert ctx.intake_state == IntakeState.MAPPING_REVIEW
    assert ctx.measures[2].clarification_answers['user_response'] == 'Revenue value'


@pytest.mark.parametrize('text', ['yes', 'yes all', 'confirm all'])
def test_generic_confirmation_keeps_choices_pending(text):
    ctx = context()
    with patch('core.protocol_parser.generate_dax') as generate:
        reply, ctx = process_message(ctx, text)
    generate.assert_not_called()
    assert ctx.intake_state == IntakeState.CLARIFY
    assert '2. Return rate' in reply and '3. Top product' in reply


@pytest.mark.parametrize('text', ['2: Lines\n2: Orders', '7: Lines', '2: yes', '2:'])
def test_bad_batch_rejected_before_mutation(text):
    ctx = context()
    with pytest.raises(ValueError):
        _clarification_answers(ctx, text)
    assert ctx.measures[1].clarification_answers == {}


def test_unfinished_formula_remains_pending():
    ctx = context()
    with patch('core.protocol_parser.ANTHROPIC_API_KEY', 'test'), patch('core.protocol_parser.generate_dax', return_value='Rate = -- TODO'):
        reply, ctx = process_message(ctx, '2: Count lines')
    assert ctx.measures[1].needs_clarification
    assert '2. Return rate' in reply

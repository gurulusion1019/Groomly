from concurrent.futures import ThreadPoolExecutor
from core.models import ProjectContext, MeasureDefinition, IntakeState, DataError, FileMeta


def test_summary_exposes_all_questions_and_row_changes():
    from api.server import summary
    ctx=ProjectContext(intake_state=IntakeState.CLARIFY,
        measures=[MeasureDefinition(display_name='Rate',needs_clarification=True,clarification_questions=['Count lines or orders?'])],
        raw_files=[FileMeta(table_name='sales',row_count=92)],
        errors=[DataError(rows_dropped=8)])
    result=summary(ctx)
    assert result['clarification_questions'][0]['number']==1
    assert result['clarification_questions'][0]['name']=='Rate'
    assert result['data_summary']=={'rows_included':92,'rows_excluded':8,'rows_quarantined':0}
    assert any(v['scope']=='Rate' and v['status']=='Failed' for v in result['validation'])


def test_concurrent_browser_sessions_keep_project_ownership(client):
    from api.server import app, SESSIONS
    def browser(index):
        c=app.test_client()
        sid=c.post('/api/session').get_json()['session_id']
        response=c.post(f'/api/chat/{sid}',json={'message':f'Concurrent project {index}'})
        assert response.status_code==200
        visible=c.get('/api/sessions').get_json()['sessions']
        assert [p['session_id'] for p in visible]==[sid]
        return sid
    with ThreadPoolExecutor(max_workers=4) as pool:
        ids=list(pool.map(browser,range(8)))
    assert len(set(ids))==8
    assert len({SESSIONS[sid].owner_id for sid in ids})==8

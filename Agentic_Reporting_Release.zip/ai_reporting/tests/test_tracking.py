import io
import json
import uuid
from core.tracking import TrackingStore


def test_upload_counts_failures_and_browser_isolation(client):
    from api import server
    sid=client.post('/api/session').json['session_id']
    client.post('/api/chat/'+sid,json={'message':'Tracking fixture'})
    client.post('/api/chat/'+sid,data={'file':(io.BytesIO(b'id,amount\na,10\nb,20\n'),'facts.csv')},content_type='multipart/form-data')
    client.post('/api/chat/'+sid,json={'message':'done'})
    client.post('/api/chat/'+sid,data={'file':(io.BytesIO(b'id,label\na,First\nb,Second\n'),'lookup.csv')},content_type='multipart/form-data')
    bad=client.post('/api/chat/'+sid,data={'file':(io.BytesIO(b'not allowed'),'bad.exe')},content_type='multipart/form-data')
    assert bad.status_code==400
    result=client.get('/api/tracking').json
    assert result['totals']['upload_events']==2
    assert result['totals']['raw_uploads']==1 and result['totals']['mapping_uploads']==1
    assert result['totals']['failed']==1
    assert result['runs'][0]['outcome']=='Failed'
    assert result['runs'][0]['raw_files']==1 and result['runs'][0]['mapping_files']==1
    other=server.app.test_client()
    assert other.get('/api/tracking?project_id='+sid).json['total']==0


def test_login_records_never_include_password(client):
    from api import server
    server.app.config['APP_PASSWORD']='test-secret-long-enough'
    client.post('/api/login',json={'password':'incorrect-secret'})
    client.post('/api/login',json={'password':'test-secret-long-enough'})
    result=client.get('/api/tracking').json
    assert sorted(r['outcome'] for r in result['runs'])==['Failed','Succeeded']
    assert 'test-secret' not in json.dumps(result) and 'incorrect-secret' not in json.dumps(result)
    assert result['runs'][0]['identity_type']=='shared_password_session'
    client.post('/api/logout')
    assert client.get('/api/tracking').status_code==401
    server.app.config['APP_PASSWORD']=''


def test_persistence_outage_and_restart_marking(tmp_path):
    path=tmp_path/'tracking.sqlite3'
    tracker=TrackingStore(path)
    tracker.append(dict(request_id=str(uuid.uuid4()),owner_id='test',phase='Started',
                        operation='model_build',outcome='Running'))
    def unavailable():
        raise RuntimeError('password must never be shown')
    assert tracker.flush(unavailable)==0
    assert 'password' not in tracker.sync_error
    restored=TrackingStore(path)
    restored.recover_interrupted()
    result=restored.history('test')
    assert result['totals']['actions']==1
    assert result['runs'][0]['outcome']=='Interrupted'
    assert result['pending_events']==2
    restored.recover_interrupted()
    assert restored.history('test')['pending_events']==2


def test_blocked_build_not_reported_as_success(client,monkeypatch):
    from api import server
    from core.models import IntakeState
    sid=client.post('/api/session').json['session_id']
    ctx=server.SESSIONS[sid];ctx.intake_state=IntakeState.MODEL_BUILD
    server.SESSIONS[sid]=ctx
    monkeypatch.setattr(server,'process_message',lambda ctx,*args: ('Build blocked',ctx))
    assert client.post('/api/chat/'+sid,json={'message':'build'}).status_code==200
    result=client.get('/api/tracking').json
    assert result['runs'][0]['outcome']=='Blocked'

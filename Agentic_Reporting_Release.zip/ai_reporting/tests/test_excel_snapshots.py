import io
import json
import zipfile

import pandas as pd
from openpyxl import load_workbook

from core.file_processor import process_file
from core.models import FileRole, SemanticModel, MeasureDefinition
from core.pbi_exporter import export_powerbi_package, _write_excel_snapshot


def test_excel_package_preserves_approved_data_and_custom_sheet(monkeypatch):
    monkeypatch.setenv('PBI_SNAPSHOT_FORMAT', 'xlsx')
    meta, frame, _ = process_file(b'code,amount\n001,12.5\nN/A,0\n', 'sales.csv', FileRole.RAW_DATA)
    meta.sheet_name = 'Approved Data'
    model = SemanticModel(project_name='Excel compatibility', tables=[meta], measures=[
        MeasureDefinition(name='Revenue', display_name='Revenue', base_table=meta.table_name,
                          base_column='amount', dax_formula=f'SUM({meta.table_name}[amount])')])
    with zipfile.ZipFile(io.BytesIO(export_powerbi_package(model, {meta.table_name: frame}))) as z:
        manifest = json.loads(z.read('validation_manifest.json'))
        source = manifest['tables'][0]['file']
        assert source.endswith('.xlsx') and manifest['snapshot_format'] == 'xlsx'
        restored = pd.read_excel(io.BytesIO(z.read(source)), sheet_name='Approved Data',
                                 dtype={'code':str}, keep_default_na=False)
        pd.testing.assert_frame_equal(frame, restored, check_dtype=False)
        bim = json.loads(z.read('model.bim'))
        query = '\n'.join(bim['model']['tables'][0]['partitions'][0]['source']['expression'])
        assert 'Excel.Workbook' in query and 'Item="Approved Data"' in query
        assert 'Csv.Document' not in query


def test_excel_snapshot_preserves_literal_formulas_and_dates(tmp_path):
    path = tmp_path / 'snapshot.xlsx'
    frame = pd.DataFrame({'code':['001','N/A','=1+1'],
                          'date':[pd.Timestamp('2026-01-02'),pd.NaT,pd.NaT]})
    _write_excel_snapshot(frame, path)
    book = load_workbook(path, data_only=False)
    try:
        assert book.active['A4'].value == '=1+1'
        assert book.active['A4'].data_type == 's'
        assert book.active['A2'].value == '001'
        assert book.active['B2'].value == pd.Timestamp('2026-01-02')
        assert book.active['B3'].value is None
    finally:
        book.close()
